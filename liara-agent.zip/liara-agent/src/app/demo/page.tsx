import { DemoRunbook } from "@/components/demo/demo-runbook";

export const dynamic = "force-dynamic";

export default function DemoPage() {
  return <DemoRunbook
    liaraTokenConfigured={Boolean(process.env.LIARA_API_TOKEN?.trim())}
    approvalSecretConfigured={Boolean(process.env.APPROVAL_SIGNING_SECRET?.trim())}
    demoGithubRepoConfigured={Boolean(process.env.DEMO_GITHUB_REPO_URL?.trim())}
    spikePlanConfigured={Boolean(process.env.LIARA_TEST_PLAN_ID?.trim())}
  />;
}
