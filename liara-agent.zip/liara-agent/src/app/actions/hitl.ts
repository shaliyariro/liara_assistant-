"use server";

import { revalidatePath } from "next/cache";
import { buildApprovalCard } from "@/lib/approval/cards";
import { approveCostBundle, issueApproval, recordApprovalRejection, type ApprovedEnvelope } from "@/lib/approval/gate";
import { getAuditStore } from "@/lib/audit/sqlite";
import { createLiaraToolRegistry, createReadEnvTool } from "@/lib/tools/liara-tools";
import type { ToolExecutionContext } from "@/lib/tools/types";

export async function approveToolAction(toolName: string, input: unknown, formData: FormData) {
  void formData;
  const registry = createLiaraToolRegistry();
  const tool = registry.get(toolName);
  const parsed = tool.inputSchema.parse(input);
  const projectId = parsed && typeof parsed === "object" && "projectId" in parsed && typeof parsed.projectId === "string" ? parsed.projectId : undefined;
  const savedEnvelope = projectId ? getAuditStore().getApprovedEnvelope<ApprovedEnvelope>(projectId) : undefined;
  const card = buildApprovalCard(tool, parsed, { envelope: savedEnvelope });
  if (!card) throw new Error("This action is in the approved green scope and does not need an approval card.");
  const approval = issueApproval(toolName, parsed);
  await registry.execute(toolName, parsed, { approval, envelope: savedEnvelope } satisfies ToolExecutionContext);
  revalidatePath("/");
}

export async function rejectToolAction(toolName: string, input: unknown, _formData: FormData) {
  void _formData;
  const registry = createLiaraToolRegistry();
  const tool = registry.get(toolName);
  const parsed = tool.inputSchema.parse(input);
  const card = buildApprovalCard(tool, parsed);
  recordApprovalRejection({ toolName, parameters: parsed, alternatives: card?.alternatives ?? ["فقط توضیح بده"] });
  revalidatePath("/");
}

export async function chooseAlternativeAction(toolName: string, _input: unknown, alternative: string, _formData: FormData) {
  void _input;
  void _formData;
  recordApprovalRejection({ toolName: `${toolName}:alternative`, parameters: { alternative }, alternatives: [alternative] });
  revalidatePath("/");
}

export async function approveEnvelopeAction(input: Parameters<typeof approveCostBundle>[0], _formData: FormData) {
  void _formData;
  approveCostBundle(input);
  revalidatePath("/");
}

export async function decideEnvReadAction(projectId: string, workspacePath: string, keys: string[], choice: "once" | "project" | "deny", _formData: FormData) {
  void _formData;
  if (choice === "deny") {
    const { setEnvConsent } = await import("@/lib/approval/env-consent");
    setEnvConsent(projectId, "deny");
    revalidatePath("/");
    return;
  }
  const { setEnvConsent } = await import("@/lib/approval/env-consent");
  setEnvConsent(projectId, choice);
  const tool = createReadEnvTool();
  const input = { projectId, workspacePath, keys };
  await tool.execute(input, { approval: issueApproval(tool.name, input) });
  revalidatePath("/");
}

export async function decideEnvReadFormAction(formData: FormData) {
  const projectId = String(formData.get("projectId") ?? "").trim();
  const workspacePath = String(formData.get("workspacePath") ?? "");
  const choice = String(formData.get("choice") ?? "") as "once" | "project" | "deny";
  let keys: string[];
  try { keys = JSON.parse(String(formData.get("keys") ?? "[]")) as string[]; } catch { throw new Error("Invalid environment key list."); }
  if (!Array.isArray(keys) || keys.some((key) => typeof key !== "string")) throw new Error("Invalid environment key list.");
  await decideEnvReadAction(projectId, workspacePath, keys, choice, formData);
}
