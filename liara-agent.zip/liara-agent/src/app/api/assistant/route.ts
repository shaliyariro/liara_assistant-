import { NextResponse } from "next/server";
import { z } from "zod";
import { AssistantNotConfiguredError, assistantConfig, runAssistant } from "@/lib/agent/assistant";
import { LiaraError } from "@/lib/liara/errors";

export const runtime = "nodejs";

const bodySchema = z.object({
  messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(4_000) }).strict()).min(1).max(20),
}).strict();

export async function GET() {
  const config = assistantConfig();
  return NextResponse.json({ configured: Boolean(config), model: config?.model ?? null }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Expected a JSON request body." }, { status: 400 }); }
  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "پیام معتبر نیست." }, { status: 400 });
  try {
    return NextResponse.json(await runAssistant(parsed.data.messages), { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    if (error instanceof AssistantNotConfiguredError) {
      return NextResponse.json({ error: "دستیار گفت‌وگو هنوز به Liara AI وصل نشده است.", limitation: { title: "Liara AI configured نیست", detail: error.message, manualStep: "در کنسول لیارا بخش هوش مصنوعی، کلید و آدرس endpoint را بردارید و در .env.local سرور قرار دهید، سپس دوباره دیپلوی کنید." } }, { status: 503 });
    }
    const message = error instanceof LiaraError ? error.userMessage : "دستیار نتوانست پاسخ بدهد. جزئیات حساس پنهان شدند.";
    return NextResponse.json({ error: message }, { status: 502, headers: { "Cache-Control": "no-store" } });
  }
}
