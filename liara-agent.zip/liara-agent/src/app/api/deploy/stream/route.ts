import { verifyDeploymentTicket } from "@/lib/deploy/quotes";
import { runDeployment } from "@/lib/deploy/pipeline";

export const runtime = "nodejs";
export const maxDuration = 1800;

const MAX_ZIP_BYTES = 25 * 1024 * 1024;

export async function POST(request: Request) {
  const declaredLength = Number(request.headers.get("content-length") ?? 0);
  if (declaredLength > MAX_ZIP_BYTES + 512 * 1024) return Response.json({ error: "Source ZIPs must be 25 MB or smaller." }, { status: 413 });
  let form: FormData;
  try { form = await request.formData(); } catch { return Response.json({ error: "Expected a multipart deployment request." }, { status: 400 }); }
  const ticketToken = form.get("ticket");
  const consent = form.get("envChoice");
  if (typeof ticketToken !== "string" || typeof consent !== "string" || !["once", "project", "deny"].includes(consent)) return Response.json({ error: "Deployment ticket or environment choice was invalid." }, { status: 400 });
  const ticket = verifyDeploymentTicket(ticketToken);
  if (!ticket) return Response.json({ error: "The approval ticket expired or was modified. Compare the plan and approve again." }, { status: 409 });
  const envelope = ticket.envelope;
  const projectId = String(form.get("projectId") ?? "");
  const appName = String(form.get("appName") ?? "");
  const platform = String(form.get("platform") ?? "");
  const port = Number(form.get("port"));
  if (!envelope.projectIds.includes(projectId) || !envelope.appNames.includes(appName) || projectId !== ticket.projectId || appName !== ticket.appName || platform !== ticket.platform || port !== ticket.port || !Number.isInteger(port) || port < 1 || port > 65535 || !/^[a-z0-9][a-z0-9-]{1,62}$/u.test(appName)) return Response.json({ error: "Deployment details are outside the signed approval." }, { status: 403 });
  const file = form.get("file");
  const githubUrl = form.get("githubUrl");
  if (!(file instanceof File) && typeof githubUrl !== "string") return Response.json({ error: "Attach the analyzed ZIP or its public GitHub URL." }, { status: 400 });
  if (file instanceof File && (file.size > MAX_ZIP_BYTES || !file.name.toLowerCase().endsWith(".zip"))) return Response.json({ error: "Upload a ZIP file no larger than 25 MB." }, { status: file.size > MAX_ZIP_BYTES ? 413 : 400 });
  if (file instanceof File && file.name !== ticket.sourceName) return Response.json({ error: "The uploaded ZIP name differs from the analyzed source. Analyze it again before deploying." }, { status: 409 });
  if (typeof githubUrl === "string") {
    try {
      const url = new URL(githubUrl);
      const source = url.pathname.split("/").filter(Boolean).slice(0, 2).join("/").replace(/\.git$/iu, "");
      if (url.protocol !== "https:" || url.hostname !== "github.com" || source.toLowerCase() !== ticket.sourceName.toLowerCase()) return Response.json({ error: "The GitHub repository differs from the analyzed source." }, { status: 409 });
    } catch { return Response.json({ error: "The GitHub source URL is invalid." }, { status: 400 }); }
  }
  let manualEnv: Record<string, string> = {};
  try {
    const raw = form.get("manualEnv");
    if (typeof raw === "string" && raw) {
      const parsed: unknown = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed) || Object.entries(parsed).some(([key, value]) => !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(key) || typeof value !== "string")) throw new Error("Invalid environment fields.");
      manualEnv = parsed as Record<string, string>;
    }
  } catch { return Response.json({ error: "Environment values must be valid key/value fields." }, { status: 400 }); }
  if (consent !== "deny" && Object.keys(manualEnv).length > 0) return Response.json({ error: "Manual environment values are accepted only after choosing the manual-entry option." }, { status: 400 });

  const sourceZip = file instanceof File ? Buffer.from(await file.arrayBuffer()) : undefined;
  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      let disconnected = false;
      const send = (event: unknown) => {
        if (disconnected) return;
        try { controller.enqueue(encoder.encode(`data: ${JSON.stringify(event)}\n\n`)); }
        catch { disconnected = true; }
      };
      void runDeployment({
        envelope, projectId, appName, platform, port, ticketId: ticket.id,
        environmentKeys: envelope.approvedEnvKeys,
        ...(sourceZip ? { sourceZip } : {}),
        ...(typeof githubUrl === "string" ? { githubUrl } : {}),
        envChoice: consent as "once" | "project" | "deny",
        manualEnv,
      }, send).finally(() => { try { controller.close(); } catch { disconnected = true; } }).catch(() => { try { controller.close(); } catch { disconnected = true; } });
    },
  });
  return new Response(stream, { headers: { "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-transform", Connection: "keep-alive", "X-Accel-Buffering": "no" } });
}
