import { NextResponse } from "next/server";
import { approveCostBundle } from "@/lib/approval/gate";
import { verifyDeploymentQuote, createDeploymentTicket } from "@/lib/deploy/quotes";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: { quoteToken?: unknown };
  try { body = await request.json() as typeof body; } catch { return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 }); }
  if (typeof body.quoteToken !== "string") return NextResponse.json({ error: "A signed quote is required." }, { status: 400 });
  const quote = verifyDeploymentQuote(body.quoteToken);
  if (!quote) return NextResponse.json({ error: "The quote expired or was modified. Request a fresh quote." }, { status: 409 });
  try {
    const envelope = approveCostBundle({
      projectIds: [quote.projectId],
      appNames: [quote.appName],
      planIDs: [quote.plan.id],
      servicePlanIDs: [],
      approvedEnvKeys: quote.environmentKeys,
      items: [{ kind: "plan", name: `Liara ${quote.plan.id} + ${quote.plan.bundlePlanID} bundle`, resourceId: quote.appName, planID: quote.plan.id, bundlePlanID: quote.plan.bundlePlanID, monthlyCost: quote.plan.monthlyToman }],
      approvedMonthlyLimit: quote.plan.monthlyToman,
    });
    return NextResponse.json({ ticket: createDeploymentTicket(envelope, quote), appName: quote.appName, projectId: quote.projectId, platform: quote.platform, port: quote.port, sourceName: quote.sourceName, environmentKeys: quote.environmentKeys }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ error: "The approved cost envelope could not be saved. No deployment was started." }, { status: 500 });
  }
}
