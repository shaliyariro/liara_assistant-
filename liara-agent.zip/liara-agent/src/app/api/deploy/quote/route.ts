import { NextResponse } from "next/server";
import { z } from "zod";
import { getLiaraPlanCatalog } from "@/lib/liara/plan-catalog";
import { planAnswersSchema, recommendPlan } from "@/lib/plan-rules";
import { repoAnalysisSchema } from "@/lib/repo/analyze-repo";
import { createDeploymentQuote, deploymentIdentity, platformForFramework, portForPlatform } from "@/lib/deploy/quotes";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 }); }
  const parsed = z.object({ analysis: repoAnalysisSchema, answers: planAnswersSchema, planID: z.string().min(1).max(80) }).strict().safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Project facts or plan choice were invalid. Analyze and compare plans again." }, { status: 400 });

  try {
    const catalog = await getLiaraPlanCatalog();
    if (catalog.isStale) return NextResponse.json({ error: "Liara's live plan catalog is unavailable. A fresh quote is required before creating a billable app.", limitation: catalog.limitation }, { status: 503 });
    const recommendation = recommendPlan(parsed.data.analysis, parsed.data.answers, catalog);
    const plan = recommendation.options.find((option) => option.plan.id === parsed.data.planID)?.plan;
    if (!plan || !plan.bundlePlanID) return NextResponse.json({ error: "This project plan does not have an available feature bundle. No app was created." }, { status: 409 });
    const identity = deploymentIdentity(parsed.data.analysis.sourceName);
    const platform = platformForFramework(parsed.data.analysis.framework, parsed.data.analysis.hasDockerfile);
    const rationale = [
      `${parsed.data.analysis.framework} project detected${parsed.data.analysis.hasDockerfile ? " with a Dockerfile" : ""}.`,
      parsed.data.analysis.databases.length ? `${parsed.data.analysis.databases.join(", ")} dependency detected.` : "No database dependency was detected.",
      parsed.data.analysis.usesRedis ? "Redis dependency detected." : "No Redis dependency was detected.",
    ].join(" ").slice(0, 400);
    const environmentKeys = new Set(parsed.data.analysis.environmentKeys.slice(0, 100));
    if (platform === "django" && ![...environmentKeys].some((key) => /^(SECRET_KEY|DJANGO_SECRET_KEY)$/iu.test(key))) environmentKeys.add("SECRET_KEY");
    const { quote, token } = createDeploymentQuote({
      ...identity,
      sourceName: parsed.data.analysis.sourceName,
      environmentKeys: [...environmentKeys],
      platform,
      port: portForPlatform(platform),
      plan,
      rationale,
    });
    return NextResponse.json({ token, quote: { id: quote.id, projectId: quote.projectId, appName: quote.appName, platform: quote.platform, port: quote.port, plan: quote.plan, rationale: quote.rationale, expiresAt: quote.expiresAt } }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ error: "A live Liara deployment quote could not be prepared. Check the connection and try again." }, { status: 503 });
  }
}
