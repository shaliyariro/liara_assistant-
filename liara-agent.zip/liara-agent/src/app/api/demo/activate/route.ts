import { NextResponse } from "next/server";
import { activateDemoSlowFailure } from "@/lib/demo/local-slow-scenario";

export const runtime = "nodejs";

export async function POST() {
  try { return NextResponse.json(await activateDemoSlowFailure(), { headers: { "Cache-Control": "no-store" } }); }
  catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Could not activate the local demo." }, { status: 503 }); }
}
