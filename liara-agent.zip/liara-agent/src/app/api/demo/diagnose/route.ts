import { NextResponse } from "next/server";
import { diagnoseDemoSlowFailure } from "@/lib/demo/local-slow-scenario";

export const runtime = "nodejs";

export async function POST() {
  try { return NextResponse.json(await diagnoseDemoSlowFailure(), { headers: { "Cache-Control": "no-store" } }); }
  catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Local demo diagnosis failed." }, { status: 503 }); }
}
