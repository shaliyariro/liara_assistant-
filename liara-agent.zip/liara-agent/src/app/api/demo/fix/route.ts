import { NextResponse } from "next/server";
import { z } from "zod";
import { executeDemoRecommendation } from "@/lib/demo/local-slow-scenario";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 }); }
  const parsed = z.object({ sessionId: z.string().uuid(), recommendationId: z.literal("demo-slow-fix") }).strict().safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "The local demo recommendation is invalid or expired." }, { status: 400 });
  try { return NextResponse.json(await executeDemoRecommendation(parsed.data.sessionId, parsed.data.recommendationId), { headers: { "Cache-Control": "no-store" } }); }
  catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "The local demo fix failed." }, { status: 503 }); }
}
