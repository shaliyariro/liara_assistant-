import { NextResponse } from "next/server";
import { resetDemoService } from "@/lib/demo/local-slow-scenario";

export const runtime = "nodejs";

export async function POST() {
  try { return NextResponse.json(await resetDemoService(), { headers: { "Cache-Control": "no-store" } }); }
  catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Could not reset the local demo." }, { status: 503 }); }
}
