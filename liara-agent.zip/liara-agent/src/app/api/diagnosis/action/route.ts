import { NextResponse } from "next/server";
import { z } from "zod";
import { buildApprovalCard } from "@/lib/approval/cards";
import { issueApproval, isValidEnvelope, type ApprovedEnvelope } from "@/lib/approval/gate";
import { getAuditStore } from "@/lib/audit/sqlite";
import { collectDiagnosis } from "@/lib/diagnosis/collect";
import { verifyFix } from "@/lib/diagnosis/analyze";
import { LiaraClient } from "@/lib/liara/client";
import { createLiaraToolRegistry } from "@/lib/tools/liara-tools";
import { getLiaraPlanCatalog } from "@/lib/liara/plan-catalog";

export const runtime = "nodejs";

const schema = z.object({
  appName: z.string().regex(/^[a-z0-9][a-z0-9-]{1,62}$/u),
  action: z.enum(["restart", "set_env", "redeploy", "change_plan", "rollback"]),
  envKey: z.string().regex(/^[A-Za-z_][A-Za-z0-9_]*$/u).optional(),
  envValue: z.string().max(20_000).optional(),
  planID: z.string().max(80).optional(),
  releaseID: z.string().max(120).optional(),
  approve: z.boolean().optional(),
}).strict();

export async function POST(request: Request) {
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Expected a JSON request body." }, { status: 400 }); }
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "The selected action or input was invalid." }, { status: 400 });
  const { appName, action } = parsed.data;
  const client = new LiaraClient();
  const registry = createLiaraToolRegistry(client);
  const stored = getAuditStore().findApprovedEnvelope<ApprovedEnvelope>((value) => isValidEnvelope(value as ApprovedEnvelope) && (value as ApprovedEnvelope).appNames.includes(appName));
  const envelope = stored && isValidEnvelope(stored) ? stored : undefined;
  const projectId = envelope?.projectIds[0] ?? appName;
  let before: Awaited<ReturnType<typeof collectDiagnosis>> | undefined;
  if (action === "redeploy") {
    before = await collectDiagnosis(appName, registry);
    const target = redeploySource(before);
    if (!target) return NextResponse.json({ limitation: { title: "Redeploy source is unavailable", detail: "Liara did not return a restorable source ID and the app platform/port for any release.", manualStep: "Deploy the corrected source through the deployment flow, then retry the health check." } }, { status: 409 });
  }
  let rollbackEvidence: Awaited<ReturnType<typeof collectDiagnosis>> | undefined;
  if (action === "rollback") {
    rollbackEvidence = await collectDiagnosis(appName, registry);
    const currentReleaseID = String(rollbackEvidence.status?.currentRelease ?? "");
    const releases = (rollbackEvidence.releases ?? []).filter((release) => {
      const id = String(release._id ?? release.id ?? "");
      return id && id !== currentReleaseID && String(release.state ?? "").toUpperCase() === "READY" && release.sourceAvailable === true && typeof release.sourceID === "string";
    });
    if (!parsed.data.releaseID) return releases.length
      ? NextResponse.json({ rollbackOptions: releases.map((release) => ({ id: String(release._id ?? release.id), tag: String(release.tag ?? release._id ?? release.id), createdAt: String(release.createdAt ?? ""), state: String(release.state) })) }, { headers: { "Cache-Control": "no-store" } })
      : NextResponse.json({ limitation: { title: "No restorable source was returned", detail: "Liara did not provide an earlier READY release with an available source ID. No rollback was attempted.", manualStep: "Choose a prior release in the Liara Console or redeploy a source archive from the deployment flow." } }, { status: 409 });
    const selected = releases.find((release) => String(release._id ?? release.id) === parsed.data.releaseID);
    const platform = String(rollbackEvidence.status?.type ?? "");
    const port = rollbackEvidence.status?.port;
    if (!selected || !["node", "next", "django", "flask", "python", "docker", "static", "react", "go", "php", "laravel", "dotnet", "vue", "angular"].includes(platform) || typeof port !== "number") return NextResponse.json({ limitation: { title: "Release source details are incomplete", detail: "The selected earlier release or the app's platform/port could not be verified from Liara's API.", manualStep: "Inspect release details in the Liara Console. No release was changed." } }, { status: 409 });
  }
  let monthlyCost: number | undefined;
  if (action === "change_plan") {
    const catalog = await getLiaraPlanCatalog();
    if (catalog.isStale) return NextResponse.json({ limitation: catalog.limitation ?? { title: "Live plan prices unavailable", detail: "No fresh plan price was returned by Liara.", manualStep: "Check available plans in the Liara Console." } }, { status: 503 });
    const app = await client.getAppStatus(appName).catch(() => undefined);
    const currentPlanID = app?.data.project?.planID;
    const current = catalog.projects.find((item) => item.id === currentPlanID);
    const project = app?.data.project;
    const currentBundleID = typeof project?.bundlePlanID === "string" ? project.bundlePlanID : "";
    if (!current || !currentBundleID) return NextResponse.json({ limitation: { title: "Current app bundle could not be verified", detail: "Liara did not return the current resource and bundle plan IDs, so a safe monthly total cannot be calculated.", manualStep: "Check the current app and bundle in the Liara Console before changing its plan." } }, { status: 409 });
    const candidates = catalog.projects.flatMap((plan) => {
      const bundle = plan.availableBundles?.find((item) => item.id === currentBundleID);
      if (!bundle || plan.id === currentPlanID || (plan.memoryGb <= current.memoryGb && plan.cpuCores <= current.cpuCores) || plan.resourceMonthlyToman === undefined) return [];
      return [{ ...plan, bundlePlanID: currentBundleID, bundleMonthlyToman: bundle.monthlyToman, monthlyToman: plan.resourceMonthlyToman + bundle.monthlyToman }];
    });
    if (!parsed.data.planID) return NextResponse.json({ currentPlanID, planOptions: candidates.map(({ id, monthlyToman, resourceMonthlyToman, bundlePlanID, bundleMonthlyToman, cpuCores, memoryGb, diskGb }) => ({ id, monthlyToman, resourceMonthlyToman, bundlePlanID, bundleMonthlyToman, cpuCores, memoryGb, diskGb })) }, { headers: { "Cache-Control": "no-store" } });
    const selectedPlan = candidates.find((plan) => plan.id === parsed.data.planID);
    if (!selectedPlan) return NextResponse.json({ error: "Select an available Liara plan with a confirmed app bundle." }, { status: 409 });
    monthlyCost = selectedPlan.monthlyToman;
  }
  const toolName = action === "restart" ? "restart_app" : action === "set_env" ? "set_env" : action === "change_plan" ? "change_plan" : "rollback_release";
  const resolvedToolName = action === "redeploy" ? "redeploy" : toolName;
  const priorRelease = action === "rollback" ? rollbackEvidence?.releases?.find((release) => String(release._id ?? release.id) === parsed.data.releaseID) : undefined;
  const deployTarget = action === "redeploy" ? redeploySource(before!) : undefined;
  const input = action === "restart"
    ? { projectId, appName }
    : action === "set_env"
      ? { projectId, appName, variables: [{ key: parsed.data.envKey ?? "", value: parsed.data.envValue ?? "" }] }
      : action === "change_plan"
        ? { projectId, planID: parsed.data.planID, monthlyCost }
        : action === "redeploy"
          ? { projectId, appName, sourceID: deployTarget!.sourceID, platform: deployTarget!.platform, port: deployTarget!.port }
          : {
          projectId, appName, releaseID: parsed.data.releaseID!,
          sourceID: String(priorRelease?.sourceID ?? ""),
          platform: String(rollbackEvidence?.status?.type ?? "node"), port: Number(rollbackEvidence?.status?.port),
        };
  if (action === "set_env" && (!parsed.data.envKey || parsed.data.envValue === undefined)) return NextResponse.json({ error: "Enter a value for the identified environment key." }, { status: 400 });
  const tool = registry.get(resolvedToolName);
  const approvalCard = buildApprovalCard(tool, input, { envelope, rationale: "The action was selected from a finding generated from collected app evidence." });
  if (approvalCard && !parsed.data.approve) return NextResponse.json({ approvalCard }, { status: 409, headers: { "Cache-Control": "no-store" } });

  try {
    before ??= await collectDiagnosis(appName, registry);
    const executionContext = {
      actor: parsed.data.approve ? "user" : "agent",
      ...(envelope ? { envelope } : {}),
      ...(approvalCard ? { approval: issueApproval(resolvedToolName, input) } : {}),
    } as const;
    let operationLimitation: FixResponseLimitation | undefined;
    if (action === "set_env") {
      await registry.execute("set_env", input, executionContext);
      const target = redeploySource(before);
      if (target) {
        const redeployInput = { projectId, appName, sourceID: target.sourceID, platform: target.platform, port: target.port };
        const redeployCard = buildApprovalCard(registry.get("redeploy"), redeployInput, { envelope });
        if (redeployCard && !parsed.data.approve) operationLimitation = { title: "Environment was set; redeploy needs its own approval", detail: "The redeploy is outside the saved approved envelope, so it was not run automatically.", manualStep: "Choose Redeploy in the finding and approve the server-generated ApprovalCard." };
        else if (redeployCard && parsed.data.approve) operationLimitation = { title: "Environment was set; redeploy needs separate approval", detail: "The current confirmation applied only to the environment update; redeploy was not included in that approval.", manualStep: "Choose Redeploy in the finding and approve its separate ApprovalCard." };
        else await registry.execute("redeploy", redeployInput, executionContext);
      } else operationLimitation = { title: "Environment was set, but automatic redeploy is unavailable", detail: "The Liara API did not return an earlier release's source ID and app platform/port.", manualStep: "Deploy the corrected source from the deployment flow, then rerun diagnosis." };
    } else await registry.execute(resolvedToolName, input, executionContext);
    await new Promise((resolveWait) => setTimeout(resolveWait, 2_000));
    const after = await collectDiagnosis(appName, registry);
    return NextResponse.json({ ok: true, action, ...(operationLimitation ? { limitation: operationLimitation } : {}), verification: verifyFix(before, after), evidence: after, finding: (await import("@/lib/diagnosis/analyze")).analyzeEvidence(after).finding }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "The corrective action failed." }, { status: 409 });
  }
}

type FixResponseLimitation = { title: string; detail: string; manualStep: string };
function redeploySource(evidence: Awaited<ReturnType<typeof collectDiagnosis>>) {
  const currentRelease = String(evidence.status?.currentRelease ?? "");
  const release = evidence.releases?.find((item) => String(item._id ?? item.id) === currentRelease && typeof item.sourceID === "string" && typeof item.sourceAvailable === "boolean" && item.sourceAvailable)
    ?? evidence.releases?.find((item) => String(item.state ?? "").toUpperCase() === "READY" && typeof item.sourceID === "string" && item.sourceAvailable === true);
  const platform = String(evidence.status?.type ?? "");
  const port = evidence.status?.port;
  if (!release || !["node", "next", "django", "flask", "python", "docker", "static", "react", "go", "php", "laravel", "dotnet", "vue", "angular"].includes(platform) || typeof port !== "number") return undefined;
  return { sourceID: String(release.sourceID), platform, port };
}
