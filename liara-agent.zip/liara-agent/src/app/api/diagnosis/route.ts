import { NextResponse } from "next/server";
import { z } from "zod";
import { LiaraClient } from "@/lib/liara/client";
import { createLiaraToolRegistry } from "@/lib/tools/liara-tools";
import { collectDiagnosis } from "@/lib/diagnosis/collect";
import { analyzeEvidence } from "@/lib/diagnosis/analyze";
import { recommendForDiagnosis } from "@/lib/recommendations/engine";

export const runtime = "nodejs";

export async function POST(request: Request) {
  const startedAt = Date.now();
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Expected a JSON request body." }, { status: 400 }); }
  const parsed = z.object({ appName: z.string().regex(/^[a-z0-9][a-z0-9-]{1,62}$/u) }).strict().safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Enter a valid Liara app name." }, { status: 400 });

  try {
    const registry = createLiaraToolRegistry(new LiaraClient());
    const evidence = await collectDiagnosis(parsed.data.appName, registry);
    const result = analyzeEvidence(evidence, startedAt);
    return NextResponse.json({ ...result, recommendations: recommendForDiagnosis(result) }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Evidence collection could not be started." }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
