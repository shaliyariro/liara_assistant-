import { NextResponse } from "next/server";
import { createF01ToolRegistry } from "@/lib/tools/f01-tools";
import { planAnswersSchema } from "@/lib/plan-rules";
import { repoAnalysisSchema } from "@/lib/repo/analyze-repo";
import type { LiaraPlanCatalog } from "@/lib/liara/plan-catalog";
import { z } from "zod";
import { recommendForProject } from "@/lib/recommendations/engine";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 }); }
  const parsed = z.object({ analysis: repoAnalysisSchema, answers: planAnswersSchema }).strict().safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Project analysis or answers were invalid. Analyze the repository again." }, { status: 400 });

  try {
    const tools = createF01ToolRegistry();
    const catalog = await tools.execute("list_plans", {}, { actor: "user" }) as LiaraPlanCatalog;
    const recommendation = await tools.execute("recommend_plan", { analysis: parsed.data.analysis, answers: parsed.data.answers, catalog }, { actor: "agent" });
    const result = recommendation as ReturnType<typeof import("@/lib/plan-rules").recommendPlan>;
    const limitations = [] as Array<{ title: string; detail: string; manualStep: string }>;
    if (catalog.limitation) limitations.push(catalog.limitation);
    if (catalog.currentBalance === null) limitations.push({
      title: "Current account balance is not available through the plan response",
      detail: "Liara returned plan prices and resources, but no current balance. This app will not claim whether the balance is sufficient.",
      manualStep: "Check your balance and top up yourself in the Liara console.",
    });
    if (result.missingServices.length) limitations.push({
      title: "One or more detected services are unavailable",
      detail: `No currently available plan matching ${result.missingServices.join(", ")} was returned by Liara. No replacement service is guessed.`,
      manualStep: "Review the service catalog in Liara, or continue without the missing service.",
    });
    if (!result.options.length && !limitations.length) limitations.push({
      title: "Not enough real project plans to compare",
      detail: "Liara returned fewer than three available project plans, so three distinct choices cannot be shown honestly.",
      manualStep: "Review current plans in the Liara console.",
    });

    return NextResponse.json({
      options: result.options,
      reason: result.reason,
      catalog: { source: catalog.source, isStale: catalog.isStale, updatedAt: catalog.updatedAt },
      limitations,
      recommendations: recommendForProject(parsed.data.analysis, catalog, { answers: parsed.data.answers }),
      balance: { current: catalog.currentBalance, rechargeUrl: catalog.rechargeUrl, userMustRecharge: true },
    }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ error: "Liara plan comparison failed. The available cached plans may still be shown after refreshing." }, { status: 500 });
  }
}
