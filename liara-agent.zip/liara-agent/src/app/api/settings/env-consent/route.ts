import { NextResponse } from "next/server";
import { getEnvConsentSettings, setEnvConsent } from "@/lib/approval/env-consent";

export const runtime = "nodejs";

function sameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  return origin === new URL(request.url).origin;
}

export async function GET(request: Request) {
  const projectId = new URL(request.url).searchParams.get("projectId")?.trim();
  if (!projectId || projectId.length > 120) return NextResponse.json({ error: "A valid projectId is required." }, { status: 400 });
  return NextResponse.json(getEnvConsentSettings(projectId), { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  if (!sameOrigin(request)) return NextResponse.json({ error: "Cross-origin requests are not accepted." }, { status: 403 });
  let body: { projectId?: unknown; choice?: unknown };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Expected a JSON request body." }, { status: 400 }); }
  if (typeof body.projectId !== "string" || body.projectId.trim().length === 0 || body.projectId.length > 120) return NextResponse.json({ error: "A valid projectId is required." }, { status: 400 });
  if (body.choice !== "once" && body.choice !== "project" && body.choice !== "deny") return NextResponse.json({ error: "Choice must be once, project, or deny." }, { status: 400 });
  setEnvConsent(body.projectId.trim(), body.choice);
  return NextResponse.json({ ...getEnvConsentSettings(body.projectId.trim()), choice: body.choice, message: body.choice === "deny" ? "Environment read permission declined." : "Environment read permission updated." });
}
