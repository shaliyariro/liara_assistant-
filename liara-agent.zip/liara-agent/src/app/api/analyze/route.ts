import { NextResponse } from "next/server";
import { createF01ToolRegistry } from "@/lib/tools/f01-tools";
import { RepoAnalysisError } from "@/lib/repo/analyze-repo";

export const runtime = "nodejs";
export const maxDuration = 30;

const ZIP_LIMIT = 25 * 1024 * 1024;

export async function POST(request: Request) {
  const declaredLength = Number(request.headers.get("content-length") ?? 0);
  if (declaredLength > ZIP_LIMIT + 512 * 1024) return NextResponse.json({ error: "Request exceeds the 25 MB ZIP limit." }, { status: 413 });
  try {
    const form = await request.formData();
    const githubUrl = form.get("githubUrl");
    if (typeof githubUrl === "string" && githubUrl.trim()) {
      const tools = createF01ToolRegistry();
      const analysis = await tools.execute("analyze_repo", { source: { type: "github", url: githubUrl.trim() } }, { actor: "user" });
      return NextResponse.json({ analysis }, { headers: { "Cache-Control": "no-store" } });
    }
    const upload = form.get("file");
    if (!(upload instanceof File)) return NextResponse.json({ error: "Enter a public GitHub URL or choose a ZIP file." }, { status: 400 });
    if (!upload.name.toLowerCase().endsWith(".zip")) return NextResponse.json({ error: "Upload a .zip archive." }, { status: 400 });
    if (upload.size > ZIP_LIMIT) return NextResponse.json({ error: "ZIP files must be 25 MB or smaller." }, { status: 413 });
    const bytes = new Uint8Array(await upload.arrayBuffer());
    const tools = createF01ToolRegistry({ fetcher: fetch, uploadedZip: { name: upload.name, bytes } });
    const analysis = await tools.execute("analyze_repo", { source: { type: "zip", name: upload.name } }, { actor: "user" });
    return NextResponse.json({ analysis }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    if (error instanceof RepoAnalysisError) return NextResponse.json({ error: error.message }, { status: error.status });
    return NextResponse.json({ error: "Repository analysis failed. Try another public GitHub URL or ZIP archive." }, { status: 500 });
  }
}
