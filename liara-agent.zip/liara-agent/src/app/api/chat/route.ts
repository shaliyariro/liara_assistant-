export const runtime = "nodejs";

export async function POST(request: Request) {
  const { question } = await request.json() as { question?: string };
  if (!question || typeof question !== "string") return Response.json({ error: "A question is required." }, { status: 400 });

  const answer = `root = QuestionCard({ question: ${JSON.stringify(question)}, options: ["هزینه‌ی کمتر", "پایداری بیشتر", "فعلاً فقط آزمایش"], recommendation: "فعلاً فقط آزمایش" })`;
  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      for (const part of answer.match(/.{1,14}/gu) ?? [answer]) {
        controller.enqueue(encoder.encode(part));
        await new Promise((resolve) => setTimeout(resolve, 60));
      }
      controller.close();
    },
  });
  return new Response(stream, { headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-cache" } });
}
