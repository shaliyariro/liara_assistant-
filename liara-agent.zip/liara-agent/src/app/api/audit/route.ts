import { NextResponse } from "next/server";
import { getAuditStore } from "@/lib/audit/sqlite";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json({ entries: getAuditStore().list(100) }, { headers: { "Cache-Control": "no-store" } });
}
