import { NextResponse } from "next/server";
import { z } from "zod";
import { createF01ToolRegistry } from "@/lib/tools/f01-tools";

export const runtime = "nodejs";

const inputSchema = z.object({ service: z.enum(["PostgreSQL", "Redis", "MySQL", "MongoDB"]) }).strict();

export async function POST(request: Request) {
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Expected a JSON body." }, { status: 400 }); }
  const parsed = inputSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Unsupported database service." }, { status: 400 });
  try {
    const registry = createF01ToolRegistry();
    const result = await registry.execute("manual_service_setup", parsed.data, { actor: "user" });
    return NextResponse.json({ ...result as object, manualStep: `Open Liara Console → Databases and check whether ${parsed.data.service} is already connected to this project. If it is, verify its host and app environment. Create a service only when none is connected. This tool did not create or change a service.` }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "Could not prepare manual service guidance." }, { status: 503 });
  }
}
