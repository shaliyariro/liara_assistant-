import { RepoAnalysisFlow } from "@/components/cards/repo-analysis-flow";
import { EnvConsentPanel } from "@/components/cards/env-consent-panel";
import { AuditLog } from "@/components/audit/audit-log";
import { DiagnosisPanel } from "@/components/cards/diagnosis-panel";
import { AssistantPanel } from "@/components/cards/assistant-panel";
import Link from "next/link";

export default function Home() {
  return (
    <main className="mx-auto flex min-h-screen w-full max-w-5xl flex-col gap-8 px-5 py-10 sm:px-8 sm:py-14">
      <header className="space-y-3">
        <p className="text-sm font-semibold text-teal-800">دستیار استقرار لیارا</p>
        <h1 className="text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">اول پروژه را بشناسیم، بعد پلن را انتخاب کنیم</h1>
        <p className="max-w-2xl text-sm leading-7 text-slate-600">فایل‌های پروژه فقط خوانده می‌شوند. مقدارهای .env وارد تحلیل نمی‌شوند و انتخاب پلن هیچ خریدی انجام نمی‌دهد.</p>
        <nav className="flex flex-wrap gap-3 pt-1 text-sm font-semibold"><Link href="/demo" className="min-h-11 rounded-lg border border-slate-300 px-4 py-3 text-slate-800">Demo runbook</Link><Link href="/capabilities" className="min-h-11 rounded-lg border border-slate-300 px-4 py-3 text-slate-800">API capabilities</Link></nav>
      </header>
      <AssistantPanel />
      <RepoAnalysisFlow />
      <DiagnosisPanel />
      <section className="grid gap-6 border-t border-slate-200 pt-8 lg:grid-cols-[.9fr_1.1fr]">
        <EnvConsentPanel />
        <AuditLog />
      </section>
    </main>
  );
}
