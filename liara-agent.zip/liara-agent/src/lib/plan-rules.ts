import type { RepoAnalysis } from "@/lib/repo/analyze-repo";
import type { LiaraPlan, LiaraPlanCatalog } from "@/lib/liara/plan-catalog";
import { z } from "zod";

export type PlanAnswers = { traffic: "trial" | "dozens" | "thousands" | "heavy"; priority: "budget" | "balanced" | "reliability"; database?: "none" | "postgres" | "mysql" | "mongodb"; domain: "existing" | "temporary" };
export type PlanQuestion = { id: keyof PlanAnswers; question: string; options: Array<{ value: string; label: string }>; recommendation: string; recommendationText: string };
export type RecommendedPlanOption = {
  role: "economic" | "recommended" | "safer";
  title: string;
  plan: LiaraPlan;
  services: Array<{ name: string; plan: LiaraPlan }>;
  monthlyToman: number;
  unsuitableWhen: string;
};

export const planAnswersSchema = z.object({
  traffic: z.enum(["trial", "dozens", "thousands", "heavy"]),
  priority: z.enum(["budget", "balanced", "reliability"]),
  database: z.enum(["none", "postgres", "mysql", "mongodb"]).optional(),
  domain: z.enum(["existing", "temporary"]),
}).strict();

export const liaraPlanSchema = z.object({
  id: z.string(), monthlyToman: z.number().nonnegative(), resourceMonthlyToman: z.number().nonnegative().optional(), bundlePlanID: z.string().optional(), bundleMonthlyToman: z.number().nonnegative().optional(), cpuCores: z.number().nonnegative(), memoryGb: z.number().nonnegative(), diskGb: z.number().nonnegative(),
  region: z.string(), supportedEngines: z.array(z.string()),
});
export const planCatalogSchema = z.object({
  projects: z.array(liaraPlanSchema), databases: z.array(liaraPlanSchema), updatedAt: z.string(), source: z.enum(["live", "cache"]), isStale: z.boolean(),
  currentBalance: z.number().nullable(), rechargeUrl: z.string(),
  limitation: z.object({ title: z.string(), detail: z.string(), manualStep: z.string() }).optional(),
});

export const PLAN_RULES = Object.freeze({
  frameworkRankOffset: { "Next.js": 1, Django: 1, FastAPI: 1, Flask: 1, Express: 0, "Node.js": 0, React: 0, Unknown: 0 } as Record<string, number>,
  trafficRank: { trial: 0, dozens: 1, thousands: 2, heavy: 3 } as Record<PlanAnswers["traffic"], number>,
  priorityRankOffset: { budget: -1, balanced: 0, reliability: 1 } as Record<PlanAnswers["priority"], number>,
});

export function buildPlanQuestions(analysis: RepoAnalysis): PlanQuestion[] {
  const questions: PlanQuestion[] = [
    {
      id: "traffic", question: "چه میزان ترافیکی انتظار داری؟",
      options: [{ value: "trial", label: "آزمایشی" }, { value: "dozens", label: "چند ده کاربر" }, { value: "thousands", label: "چند هزار کاربر" }, { value: "heavy", label: "سنگین" }],
      recommendation: "trial", recommendationText: "برای شروع، ترافیک را آزمایشی فرض می‌کنم؛ هر زمان می‌شود پلن را دوباره بررسی کرد.",
    },
    {
      id: "priority", question: "کدام اولویت برایت مهم‌تر است؟",
      options: [{ value: "budget", label: "هزینه‌ی کمتر" }, { value: "balanced", label: "تعادل هزینه و پایداری" }, { value: "reliability", label: "پایداری بیشتر" }],
      recommendation: "balanced", recommendationText: "تعادل را پیشنهاد می‌دهم تا انتخاب فقط بر اساس کمترین قیمت نباشد.",
    },
    {
      id: "domain", question: "دامنه‌ی اختصاصی داری؟",
      options: [{ value: "existing", label: "بله، دامنه دارم" }, { value: "temporary", label: "فعلاً زیردامنه‌ی موقت" }],
      recommendation: "temporary", recommendationText: "برای اولین راه‌اندازی، زیردامنه‌ی موقت کافی است.",
    },
  ];
  if (analysis.databaseAmbiguous) questions.push({
    id: "database", question: "آیا این پروژه به دیتابیس نیاز دارد؟",
    options: [{ value: "none", label: "فعلاً نه" }, { value: "postgres", label: "PostgreSQL" }, { value: "mysql", label: "MySQL" }, { value: "mongodb", label: "MongoDB" }],
    recommendation: "none", recommendationText: "در ریپو کلاینت یا پیکربندی دیتابیس پیدا نشد؛ فعلاً بدون دیتابیس را پیشنهاد می‌دهم.",
  });
  return questions.slice(0, 4);
}

export function recommendPlan(analysis: RepoAnalysis, answers: PlanAnswers, catalog: LiaraPlanCatalog, rules = PLAN_RULES): { options: RecommendedPlanOption[]; reason: string; missingServices: string[] } {
  const allAvailable = catalog.projects.filter((plan) => Number.isFinite(plan.monthlyToman) && plan.monthlyToman >= 0);
  const withSupportedBundle = allAvailable.filter((plan) => Boolean(plan.bundlePlanID));
  const candidates = (withSupportedBundle.length ? withSupportedBundle : allAvailable)
    .sort((a, b) => a.monthlyToman - b.monthlyToman || a.memoryGb - b.memoryGb || a.id.localeCompare(b.id));
  if (candidates.length < 3) return { options: [], reason: "Fewer than three real, available Liara project plans were returned.", missingServices: [] };

  const requestedDatabases = new Set(analysis.databases.map(databaseEngine));
  if (analysis.databaseAmbiguous && answers.database && answers.database !== "none") requestedDatabases.add(answers.database);
  const requestedRedis = analysis.usesRedis || analysis.workers.length > 0;
  const services: RecommendedPlanOption["services"] = [];
  const missingServices: string[] = [];
  for (const engine of requestedDatabases) {
    if (!engine) continue;
    const plan = catalog.databases.find((candidate) => candidate.supportedEngines.includes(engine));
    if (plan) services.push({ name: engine === "postgres" ? "PostgreSQL" : engine === "mysql" ? "MySQL" : "MongoDB", plan });
    else missingServices.push(engine === "postgres" ? "PostgreSQL" : engine);
  }
  if (requestedRedis) {
    const plan = catalog.databases.find((candidate) => candidate.supportedEngines.includes("redis"));
    if (plan) services.push({ name: "Redis", plan });
    else missingServices.push("Redis");
  }

  const trafficRank = rules.trafficRank[answers.traffic];
  const frameworkOffset = rules.frameworkRankOffset[analysis.framework] ?? 0;
  const preferenceOffset = rules.priorityRankOffset[answers.priority];
  const recommendedIndex = clamp(trafficRank + frameworkOffset + preferenceOffset, 1, candidates.length - 2);
  const selected = analysis.staticSite
    ? [candidates[0], candidates[1], candidates[candidates.length - 1]]
    : [candidates[0], candidates[recommendedIndex], candidates[candidates.length - 1]];
  const roles: RecommendedPlanOption["role"][] = analysis.staticSite
    ? ["recommended", "economic", "safer"]
    : ["economic", "recommended", "safer"];
  const titles = roles.map((role) => role === "recommended" ? "⭐ پیشنهاد من" : role === "economic" ? "اقتصادی" : "مطمئن‌تر");
  const unsuitable = ["برای ترافیک زیاد یا بار کاری سنگین مناسب نیست.", "اگر بار واقعی خیلی بیشتر از انتظار شود، بازبینی کن.", "اگر آزمایش کوتاه و کم‌هزینه می‌خواهی، هزینه‌اش ممکن است لازم نباشد."];
  const options = selected.map((plan, index) => ({
    role: roles[index], title: titles[index], plan, services: [...services],
    monthlyToman: plan.monthlyToman + services.reduce((sum, service) => sum + service.plan.monthlyToman, 0),
    unsuitableWhen: unsuitable[index],
  }));
  const dependencyEvidence = [...analysis.databases, ...(analysis.usesRedis ? ["Redis"] : []), ...analysis.workers];
  const resourceEvidence = dependencyEvidence.length
    ? `در ریپو ${dependencyEvidence.join("، ")} شناسایی شد.`
    : `در ریپو ${analysis.framework} شناسایی شد و وابستگی دیتابیس یا Redis پیدا نشد.`;
  const reason = `${resourceEvidence} پلن بر اساس ترافیک و اولویت انتخابی از کاتالوگ واقعی لیارا رتبه‌بندی شد.`.slice(0, 170);
  return { options, reason, missingServices };
}

export function balanceStatusFromLiaraMe(value: unknown): { currentBalance: number | null; rechargeUrl: string; message: string } {
  const user = value && typeof value === "object" && "user" in value ? (value as { user?: Record<string, unknown> }).user : undefined;
  const balance = user && typeof user.balance === "number" && Number.isFinite(user.balance) ? user.balance : null;
  return {
    currentBalance: balance,
    rechargeUrl: "https://console.liara.ir/",
    message: balance === null ? "The Liara plan API does not expose the current account balance. Check it in the Liara console; charging is a user action." : "Balance is shown from the current Liara response. Charging remains a user action.",
  };
}

function databaseEngine(value: string): "postgres" | "mysql" | "mongodb" | undefined {
  if (/postgres/i.test(value)) return "postgres";
  if (/mysql|mariadb/i.test(value)) return "mysql";
  if (/mongo/i.test(value)) return "mongodb";
  return undefined;
}

function clamp(value: number, minimum: number, maximum: number) { return Math.min(Math.max(value, minimum), maximum); }
