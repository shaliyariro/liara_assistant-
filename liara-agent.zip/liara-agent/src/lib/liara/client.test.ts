import { describe, expect, it } from "vitest";
import { LiaraClient } from "./client";
import { LiaraError } from "./errors";

process.env.LIARA_API_TOKEN = "test-token-never-printed";

function clientReturning(status: number, body: string) {
  return new LiaraClient({ logger: () => undefined, fetcher: async () => new Response(body, { status }) });
}

describe("LiaraClient error reasons", () => {
  it("surfaces Liara's machine reason code with a clear message (seen live for G2 plans)", async () => {
    const error = await clientReturning(400, JSON.stringify({ statusCode: 400, error: "Bad Request", message: "g2_plan_unavailable", data: null }))
      .createApp({ name: "demo", planID: "small-g2", bundlePlanID: "basic", platform: "node" }).catch((caught) => caught);
    expect(error).toBeInstanceOf(LiaraError);
    expect(error).toMatchObject({ code: "LIARA_G2_PLAN_UNAVAILABLE", status: 400, retryable: false });
    expect(error.userMessage).toContain("G2");
  });

  it("ignores free-text messages so response content never leaks into the UI", async () => {
    const error = await clientReturning(403, JSON.stringify({ message: "token test-token-never-printed is invalid for user x@y.z" })).listApps().catch((caught) => caught);
    expect(error).toMatchObject({ code: "LIARA_HTTP_403" });
    expect(error.userMessage).not.toContain("test-token");
  });
});

describe("excluded plans", () => {
  it("hides plans the account cannot buy (e.g. *-g2) from every catalog consumer", async () => {
    const { getLiaraPlanCatalog } = await import("./plan-catalog");
    const raw = () => ({ available: true, price: 1, CPU: { amount: 1 }, RAM: { amount: 1 }, volume: 5 });
    const fetchLive = async () => ({ plans: { projects: { "small-g2": raw(), "ir-small": raw(), "medium-g2": raw() } } });
    process.env.LIARA_EXCLUDED_PLANS = "*-g2";
    try {
      const catalog = await getLiaraPlanCatalog({ fetchLive, cachePath: `${process.env.TEMP ?? "/tmp"}/liara-plan-test-${Date.now()}.json` });
      expect(catalog.projects.map((plan) => plan.id)).toEqual(["ir-small"]);
    } finally { delete process.env.LIARA_EXCLUDED_PLANS; }
  });
});
