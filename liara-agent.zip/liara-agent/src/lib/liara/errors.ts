export type LiaraErrorShape = {
  code: string;
  userMessage: string;
  retryable: boolean;
};

export class LiaraError extends Error implements LiaraErrorShape {
  constructor(
    readonly code: string,
    readonly userMessage: string,
    readonly retryable: boolean,
    readonly status?: number,
  ) {
    super(userMessage);
    this.name = "LiaraError";
  }
}

export function sanitizeForLog(text: string, token?: string): string {
  if (!token) return text.replace(/Bearer\s+[^\s"']+/gi, "Bearer [REDACTED]");
  return text.split(token).join("[REDACTED]").replace(/Bearer\s+[^\s"']+/gi, "Bearer [REDACTED]");
}
