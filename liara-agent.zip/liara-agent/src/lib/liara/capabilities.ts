export type ApiCapability = {
  name: string;
  path: string;
  status: "confirmed" | "blocked" | "unverified" | "manual" | "unknown";
  detail: string;
};

export const API_CAPABILITIES: ApiCapability[] = [
  { name: "List apps", path: "GET /v1/projects", status: "confirmed", detail: "Authenticated live request returned HTTP 200." },
  { name: "List plans", path: "GET /v1/me", status: "confirmed", detail: "Authenticated live request returned HTTP 200; F01 uses this response for plan choices." },
  { name: "Create app", path: "POST /v1/projects", status: "blocked", detail: "Live attempt on 2026-10-23 reached Liara: G2 plans returned 400 g2_plan_unavailable and ir-small returned 402 (no account balance). Nothing was created. Errors now surface Liara reason codes." },
  { name: "Upload source", path: "POST /v2/projects/{name}/sources", status: "blocked", detail: "Not attempted because a test app was not created." },
  { name: "Deploy release", path: "POST /v2/projects/{name}/releases", status: "blocked", detail: "Not attempted because a test app was not created." },
  { name: "Set environment", path: "POST /v1/projects/update-envs", status: "blocked", detail: "Not attempted against a real app; local F02 tests use a mocked Liara client." },
  { name: "Read logs", path: "GET /v1/projects/{name}/logs", status: "blocked", detail: "Not attempted because no test app was created." },
  { name: "Read metrics", path: "GET /v1/projects/{name}/metrics/summary", status: "blocked", detail: "Not attempted because no test app was created; granularity is unverified." },
  { name: "Restart app", path: "POST /v1/projects/{name}/actions/restart", status: "blocked", detail: "Not attempted because no test app was created." },
  { name: "Delete app", path: "DELETE /v1/projects/{name}", status: "blocked", detail: "Not attempted; no disposable test app exists." },
  { name: "List DBaaS services", path: "GET /v1/databases", status: "confirmed", detail: "Authenticated read-only request returned HTTP 200 on 2026-10-23 (npm run probe:liara). Creation stays manual." },
  { name: "Create DBaaS service", path: "POST /v1/databases", status: "manual", detail: "Documented but not live-verified. F05 shows manual console instructions and does not create billable services." },
  { name: "Rollback release", path: "Unknown in the checked PaaS API", status: "unknown", detail: "No verified rollback operation is implemented; diagnosis reports this as a limitation." },
  { name: "Account recharge / IrNIC domain registration", path: "No supported Liara API", status: "manual", detail: "The user performs these actions in the provider console / external registrar." },
];

export function capabilityLabel(status: ApiCapability["status"]) {
  return status === "confirmed" ? "✅ Confirmed live" : status === "blocked" ? "⚠️ Not attempted" : status === "unverified" ? "⚠️ Documented, unverified" : status === "unknown" ? "❓ Unknown" : "🧭 Manual";
}
