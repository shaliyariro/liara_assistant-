import "server-only";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { LiaraClient } from "./client";

export type LiaraPlan = {
  id: string;
  monthlyToman: number;
  resourceMonthlyToman?: number;
  bundlePlanID?: string;
  bundleMonthlyToman?: number;
  availableBundles?: Array<{ id: string; monthlyToman: number }>;
  cpuCores: number;
  memoryGb: number;
  diskGb: number;
  region: string;
  supportedEngines: string[];
};
export type LiaraPlanCatalog = {
  projects: LiaraPlan[];
  databases: LiaraPlan[];
  updatedAt: string;
  source: "live" | "cache";
  isStale: boolean;
  currentBalance: number | null;
  rechargeUrl: string;
  limitation?: { title: string; detail: string; manualStep: string };
};

type RawPlan = { available?: boolean; region?: string; price?: number; CPU?: { amount?: number }; RAM?: { amount?: number }; volume?: number; supports?: unknown[] };
type RawBundle = { available?: boolean; displayPrice?: number; price?: number };
type LiaraMe = { plans?: { projects?: Record<string, RawPlan>; databases?: Record<string, RawPlan>; projectBundlePlans?: Record<string, Record<string, RawBundle>>; databaseBundlePlans?: Record<string, Record<string, RawBundle>> }; user?: Record<string, unknown> };

/**
 * Plans the account cannot buy even though /v1/me lists them as available, e.g. G2 plans that
 * return `g2_plan_unavailable` on create. Configure with LIARA_EXCLUDED_PLANS="*-g2,ir-mini" (suffix/prefix `*` wildcards).
 */
export async function getLiaraPlanCatalog(options: Parameters<typeof fetchPlanCatalog>[0] = {}): Promise<LiaraPlanCatalog> {
  const catalog = await fetchPlanCatalog(options);
  const patterns = (process.env.LIARA_EXCLUDED_PLANS ?? "").split(",").map((item) => item.trim()).filter(Boolean);
  if (!patterns.length) return catalog;
  const matches = (id: string, pattern: string) => pattern.startsWith("*") ? id.endsWith(pattern.slice(1)) : pattern.endsWith("*") ? id.startsWith(pattern.slice(0, -1)) : id === pattern;
  const keep = (plan: LiaraPlan) => !patterns.some((pattern) => matches(plan.id, pattern));
  return { ...catalog, projects: catalog.projects.filter(keep), databases: catalog.databases.filter(keep) };
}

async function fetchPlanCatalog(options: {
  fetchLive?: () => Promise<LiaraMe>;
  cachePath?: string;
  now?: () => Date;
} = {}): Promise<LiaraPlanCatalog> {
  const cachePath = resolve(options.cachePath ?? process.env.LIARA_PLAN_CACHE_PATH ?? "data/liara-plans-cache.json");
  const now = options.now ?? (() => new Date());
  try {
    const me = await (options.fetchLive ?? (async () => (await new LiaraClient().listPlans()).data as LiaraMe))();
    const catalog = normalizeLiveCatalog(me, now().toISOString());
    if (catalog.projects.length) {
      await mkdir(dirname(cachePath), { recursive: true });
      await writeFile(cachePath, JSON.stringify({ updatedAt: catalog.updatedAt, projects: catalog.projects, databases: catalog.databases }, null, 2), "utf8");
    }
    return catalog;
  } catch {
    try {
      const cached = JSON.parse(await readFile(cachePath, "utf8")) as Pick<LiaraPlanCatalog, "updatedAt" | "projects" | "databases">;
      if (!cached.projects.length) throw new Error("Empty cached plan list.");
      return {
        ...cached,
        source: "cache",
        isStale: true,
        currentBalance: null,
        rechargeUrl: "https://console.liara.ir/",
        limitation: {
          title: "Could not refresh Liara plans",
          detail: "These real Liara plans are from the last successful catalog fetch and may be outdated.",
          manualStep: "Check the plan and price in the Liara console before choosing.",
        },
      };
    } catch {
      return {
        projects: [], databases: [], updatedAt: "", source: "cache", isStale: true, currentBalance: null, rechargeUrl: "https://console.liara.ir/",
        limitation: {
          title: "Liara plans are unavailable",
          detail: "A live plan request failed and there is no previously cached plan list. The app will not guess plan IDs or prices.",
          manualStep: "Open the Liara console and review the current plans before continuing.",
        },
      };
    }
  }
}

export function normalizeLiveCatalog(me: LiaraMe, updatedAt: string): LiaraPlanCatalog {
  const plans = me.plans;
  return {
    projects: normalizeGroup(plans?.projects, plans?.projectBundlePlans),
    databases: normalizeGroup(plans?.databases, plans?.databaseBundlePlans),
    updatedAt,
    source: "live",
    isStale: false,
    currentBalance: typeof me.user?.balance === "number" && Number.isFinite(me.user.balance) ? me.user.balance : null,
    rechargeUrl: "https://console.liara.ir/",
  };
}

function normalizeGroup(group: Record<string, RawPlan> | undefined, bundleGroups: Record<string, Record<string, RawBundle>> | undefined): LiaraPlan[] {
  if (!group) return [];
  return Object.entries(group).flatMap(([id, raw]) => {
    const cpuCores = raw.CPU?.amount;
    const memoryGb = raw.RAM?.amount;
    const diskGb = raw.volume;
    const hourlyPrice = raw.price;
    if (!raw.available || !Number.isFinite(hourlyPrice) || !Number.isFinite(cpuCores) || !Number.isFinite(memoryGb) || !Number.isFinite(diskGb)) return [];
    const availableBundles = Object.entries(bundleGroups?.[id] ?? {})
      .filter(([, details]) => details.available === true)
      .map(([bundleID, details]) => ({
        id: bundleID,
        monthlyToman: Math.round(Number.isFinite(details.displayPrice) ? details.displayPrice! : (details.price ?? 0) * 720),
      }))
      .sort((left, right) => left.monthlyToman - right.monthlyToman || left.id.localeCompare(right.id));
    const bundle = availableBundles[0];
    const resourceMonthlyToman = Math.round(hourlyPrice! * 720);
    const bundleMonthlyToman = bundle?.monthlyToman ?? 0;
    return [{
      id,
      monthlyToman: resourceMonthlyToman + bundleMonthlyToman,
      resourceMonthlyToman,
      ...(bundle ? { bundlePlanID: bundle.id } : {}),
      bundleMonthlyToman,
      availableBundles,
      cpuCores: cpuCores!,
      memoryGb: memoryGb!,
      diskGb: diskGb!,
      region: raw.region ?? "",
      supportedEngines: (raw.supports ?? []).filter((item): item is string => typeof item === "string").map((item) => item.toLowerCase()),
    }];
  }).sort((left, right) => left.monthlyToman - right.monthlyToman || left.memoryGb - right.memoryGb || left.id.localeCompare(right.id));
}
