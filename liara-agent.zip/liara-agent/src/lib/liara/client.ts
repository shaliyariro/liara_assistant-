import "server-only";
import { LiaraError, sanitizeForLog } from "./errors";

export type LiaraRequestOptions = {
  method?: "GET" | "POST" | "DELETE";
  body?: unknown;
};

export type LiaraResponse<T> = { data: T; status: number; headers: Headers };

export class LiaraClient {
  private readonly baseUrl: string;
  private readonly token: string;

  constructor(options: { baseUrl?: string; fetcher?: typeof fetch; logger?: (line: string) => void } = {}) {
    if (typeof window !== "undefined") throw new Error("LiaraClient is server-only.");
    this.baseUrl = (options.baseUrl ?? process.env.LIARA_API_BASE_URL ?? "https://api.liara.ir").replace(/\/$/, "");
    this.token = process.env.LIARA_API_TOKEN ?? "";
    this.fetcher = options.fetcher ?? fetch;
    this.logger = options.logger ?? ((line) => console.info(line));
    if (!this.token) throw new LiaraError("MISSING_CREDENTIALS", "Liara credentials are not configured on the server.", false);
  }

  private readonly fetcher: typeof fetch;
  private readonly logger: (line: string) => void;

  async request<T>(path: string, options: LiaraRequestOptions = {}): Promise<LiaraResponse<T>> {
    const url = `${this.baseUrl}${path.startsWith("/") ? path : `/${path}`}`;
    let response: Response;
    const headers = new Headers();
    headers.set("Authorization", `Bearer ${this.token}`);
    if (process.env.LIARA_TEAM_ID) headers.set("X-Team-Id", process.env.LIARA_TEAM_ID);
    if (options.body !== undefined && !(options.body instanceof FormData)) headers.set("Content-Type", "application/json");
    try {
      response = await this.fetcher(url, {
        method: options.method ?? "GET",
        headers,
        signal: AbortSignal.timeout(12_000),
        ...(options.body === undefined ? {} : { body: options.body instanceof FormData ? options.body : JSON.stringify(options.body) }),
      });
    } catch {
      this.logger(sanitizeForLog(JSON.stringify({ service: "liara", path, error: "network_error" }), this.token));
      throw new LiaraError("NETWORK_ERROR", "Could not connect to Liara. Check the connection and try again.", true);
    }

    const raw = await response.text();
    this.logger(sanitizeForLog(JSON.stringify({ service: "liara", path, status: response.status }), this.token));
    if (!response.ok) {
      const retryable = response.status === 429 || response.status >= 500;
      const reason = liaraReasonCode(raw) ?? (response.status === 402 ? "payment_required" : undefined);
      throw new LiaraError(
        reason ? `LIARA_${reason.toUpperCase()}` : `LIARA_HTTP_${response.status}`,
        retryable ? "Liara is temporarily unavailable. Try again shortly." : (reason && KNOWN_REASONS[reason]) ?? `Liara rejected this request${reason ? ` (${reason})` : ""}. Check the app settings and permissions.`,
        retryable,
        response.status,
      );
    }

    let data: T;
    try {
      data = (raw ? JSON.parse(raw) : undefined) as T;
    } catch {
      throw new LiaraError("INVALID_RESPONSE", "Liara returned an unreadable response.", false, response.status);
    }
    return { data, status: response.status, headers: response.headers };
  }

  listApps() { return this.request<{ projects: unknown[] }>("/v1/projects"); }
  getAppStatus(name: string) { return this.request<{ project: Record<string, unknown> }>(`/v1/projects/${encodeURIComponent(name)}`); }
  listPlans() { return this.request<{ plans: unknown }>("/v1/me"); }
  createApp(input: { name: string; planID: string; bundlePlanID?: string; platform: string }) {
    return this.request<void>("/v1/projects/", { method: "POST", body: input });
  }
  deleteApp(name: string) { return this.request<void>(`/v1/projects/${encodeURIComponent(name)}`, { method: "DELETE" }); }
  updateEnv(name: string, variables: Array<{ key: string; value: string }>) {
    return this.request<{ message?: string }>("/v1/projects/update-envs", { method: "POST", body: { project: name, variables } });
  }
  getLogs(name: string, since = new Date(Date.now() - 60 * 60 * 1000).toISOString()) {
    const start = Math.floor(new Date(since).getTime() / 1000);
    return this.request<unknown>(`/v2/projects/${encodeURIComponent(name)}/logs?start=${start}&direction=forward&last_lines=true`);
  }
  getMetrics(name: string) { return this.request<unknown>(`/v1/projects/${encodeURIComponent(name)}/metrics/summary`); }
  getReleaseHistory(name: string) {
    return this.request<{ releases?: Array<Record<string, unknown>>; currentRelease?: string; total?: number }>(`/v1/projects/${encodeURIComponent(name)}/releases?page=1&count=20`);
  }
  restartApp(name: string) {
    return this.request<void>(`/v1/projects/${encodeURIComponent(name)}/actions/restart`, { method: "POST" });
  }
  changePlan(name: string, planID: string) {
    return this.request<void>(`/v1/projects/${encodeURIComponent(name)}/resize`, { method: "POST", body: { planID } });
  }
  uploadSource(name: string, file: Blob, filename = "source.tar.gz") {
    const form = new FormData();
    form.set("file", file, filename);
    return this.request<{ sourceID: string }>(`/v2/projects/${encodeURIComponent(name)}/sources`, {
      method: "POST", body: form,
    });
  }
  deployRelease(name: string, input: { sourceID: string; port: number; type: string }) {
    return this.request<{ releaseID: string }>(`/v2/projects/${encodeURIComponent(name)}/releases`, { method: "POST", body: input });
  }
  getRelease(releaseID: string) {
    return this.request<{ release: { state: string; failReason?: string; queue?: number; [key: string]: unknown } }>(`/v1/releases/${encodeURIComponent(releaseID)}`);
  }
  getBuildLogs(releaseID: string, since?: string) {
    const cursor = since ? `?since=${encodeURIComponent(since)}` : "";
    return this.request<{ release: { state: string; failReason?: string }; buildOutput: Array<{ stream: string; line: string; createdAt: string }> }>(`/v2/releases/${encodeURIComponent(releaseID)}/build-logs${cursor}`);
  }
  getDomains(name: string) {
    return this.request<{ domains: Array<{ name: string; certificatesStatus?: string }> }>(`/v1/domains?project=${encodeURIComponent(name)}`);
  }
}

/** Liara error bodies carry a short machine code in `message` (e.g. "g2_plan_unavailable"); only such codes are surfaced. */
function liaraReasonCode(raw: string): string | undefined {
  try {
    const message = (JSON.parse(raw) as { message?: unknown }).message;
    return typeof message === "string" && /^[a-z][a-z0-9_]{2,60}$/u.test(message) ? message : undefined;
  } catch { return undefined; }
}

const KNOWN_REASONS: Record<string, string> = {
  payment_required: "موجودی حساب لیارا کافی نیست. حساب را از console.liara.ir شارژ کنید و دوباره امتحان کنید.",
  g2_plan_unavailable: "این حساب لیارا فعلاً اجازه‌ی ساخت اپ روی پلن‌های G2 را ندارد. یک پلن غیر G2 (مثلاً ir-small) انتخاب کنید یا از پشتیبانی لیارا فعال‌سازی G2 را بخواهید.",
};
