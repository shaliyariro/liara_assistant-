import "server-only";
import * as yauzl from "yauzl";
import { z } from "zod";

const MAX_ZIP_BYTES = 25 * 1024 * 1024;
const MAX_EXPANDED_BYTES = 120 * 1024 * 1024;
const MAX_ENTRIES = 10_000;
const MAX_READ_FILE_BYTES = 1_500_000;

export type RepoSourceFile = { path: string; size: number; text?: string };
export type RepoSource = { files: RepoSourceFile[]; sourceBytes: number; fileCount: number; sourceName: string };

export type RepoAnalysis = {
  sourceName: string;
  language: string[];
  framework: string;
  hasDockerfile: boolean;
  databases: string[];
  usesRedis: boolean;
  workers: string[];
  cron: string[];
  environmentKeys: string[];
  fileCount: number;
  sourceSizeMb: number;
  buildEstimateMb: { min: number; max: number; note: string };
  findings: string[];
  databaseAmbiguous: boolean;
  staticSite: boolean;
};

export const repoAnalysisSchema = z.object({
  sourceName: z.string().max(200), language: z.array(z.string().max(80)).max(12), framework: z.string().max(80), hasDockerfile: z.boolean(),
  databases: z.array(z.string().max(80)).max(8), usesRedis: z.boolean(), workers: z.array(z.string().max(100)).max(12), cron: z.array(z.string().max(100)).max(12),
  environmentKeys: z.array(z.string().max(120)).max(500), fileCount: z.number().int().nonnegative().max(MAX_ENTRIES), sourceSizeMb: z.number().nonnegative(),
  buildEstimateMb: z.object({ min: z.number().nonnegative(), max: z.number().nonnegative(), note: z.string().max(250) }),
  findings: z.array(z.string().max(250)).max(24), databaseAmbiguous: z.boolean(), staticSite: z.boolean(),
}).strict();

export class RepoAnalysisError extends Error {
  constructor(message: string, readonly status = 400) { super(message); this.name = "RepoAnalysisError"; }
}

export async function analyzeZipArchive(bytes: Buffer, sourceName: string): Promise<RepoAnalysis> {
  if (bytes.length === 0 || bytes.length > MAX_ZIP_BYTES) throw new RepoAnalysisError("ZIP files must be between 1 byte and 25 MB.");
  let zip: yauzl.ZipFile;
  try {
    zip = await yauzl.fromBufferPromise(bytes, { lazyEntries: true, autoClose: false, decodeStrings: true, validateEntrySizes: true, strictFileNames: true });
  } catch {
    throw new RepoAnalysisError("The uploaded file is not a valid ZIP archive.");
  }

  const entries: Array<{ path: string; size: number; read: boolean; content?: string }> = [];
  let expandedBytes = 0;
  let entryCount = 0;
  try {
    for await (const entry of zip.eachEntry()) {
      if (++entryCount > MAX_ENTRIES) throw new RepoAnalysisError("The repository contains too many files to analyze safely.");
      const rawPath = entry.fileName.replace(/\\/gu, "/");
      if (rawPath.startsWith("/") || /^[A-Za-z]:/u.test(rawPath) || rawPath.split("/").some((part) => part === "..")) {
        throw new RepoAnalysisError("The ZIP contains an unsafe file path.");
      }
      if (rawPath.endsWith("/")) continue;
      const mode = entry.externalFileAttributes >>> 16;
      if ((mode & 0o170000) === 0o120000) continue;
      expandedBytes += entry.uncompressedSize;
      if (expandedBytes > MAX_EXPANDED_BYTES) throw new RepoAnalysisError("The repository expands beyond the 120 MB analysis limit.");
      const slash = rawPath.indexOf("/");
      const pathWithoutPossibleRoot = slash < 0 ? rawPath : rawPath.slice(slash + 1);
      const shouldRead = (isRelevantTextFile(rawPath) || isRelevantTextFile(pathWithoutPossibleRoot)) && entry.uncompressedSize <= MAX_READ_FILE_BYTES;
      let content: string | undefined;
      if (shouldRead) {
        const stream = await zip.openReadStreamPromise(entry);
        const chunks: Buffer[] = [];
        let received = 0;
        for await (const chunk of stream) {
          const buffer = Buffer.from(chunk);
          received += buffer.length;
          if (received > MAX_READ_FILE_BYTES) throw new RepoAnalysisError("A project manifest exceeded the analysis file-size limit.");
          chunks.push(buffer);
        }
        content = Buffer.concat(chunks).toString("utf8");
      }
      entries.push({ path: rawPath, size: entry.uncompressedSize, read: shouldRead, content });
    }
  } catch (error) {
    zip.close();
    if (error instanceof RepoAnalysisError) throw error;
    throw new RepoAnalysisError("The ZIP could not be read safely.");
  } finally {
    if (zip.isOpen) zip.close();
  }

  const archiveRoot = findCommonArchiveRoot(entries.map(({ path }) => path));
  const files = entries.map(({ path, size, content }) => ({ path: stripArchiveRoot(path, archiveRoot), size, ...(content === undefined ? {} : { text: content }) }));
  const sourceBytes = files.filter(({ path }) => !ignoredPath(path)).reduce((sum, entry) => sum + entry.size, 0);
  return analyzeRepoSource({ files, sourceBytes, fileCount: entries.length, sourceName });
}

export function analyzeRepoSource(source: RepoSource): RepoAnalysis {
  const files = source.files.filter(({ path }) => !ignoredPath(path));
  const paths = new Set(files.map(({ path }) => path.toLowerCase()));
  const manifestText = files.filter(({ path }) => isSignalTextFile(path)).map(({ text }) => text ?? "").join("\n").toLowerCase();
  const rootPackage = files.find(({ path }) => path.toLowerCase() === "package.json")?.text;
  const packageJson = safeJson(rootPackage);
  const deps = { ...(packageJson.dependencies ?? {}), ...(packageJson.devDependencies ?? {}) } as Record<string, unknown>;
  const dependencyNames = Object.keys(deps).map((name) => name.toLowerCase());
  const requirements = files.filter(({ path }) => /(^|\/)(requirements[^/]*\.txt|pyproject\.toml|pipfile)$/iu.test(path)).map(({ text }) => text ?? "").join("\n").toLowerCase();
  const compose = files.filter(({ path }) => /(^|\/)(docker-compose\.ya?ml|compose\.ya?ml)$/iu.test(path)).map(({ text }) => text ?? "").join("\n").toLowerCase();

  const language = new Set<string>();
  if (paths.has("package.json") || files.some(({ path }) => /\.(js|jsx|ts|tsx|mjs|cjs)$/iu.test(path))) language.add("JavaScript/TypeScript");
  if (paths.has("manage.py") || files.some(({ path }) => /\.(py|pyw)$/iu.test(path)) || /(^|\n)django[=<>~!\s]/u.test(requirements)) language.add("Python");
  if (paths.has("go.mod") || files.some(({ path }) => path.endsWith(".go"))) language.add("Go");
  if (files.some(({ path }) => /\.php$/iu.test(path)) || paths.has("composer.json")) language.add("PHP");
  if (paths.has("dockerfile") && language.size === 0) language.add("Docker");

  const framework = detectFramework({ paths, packageJson, dependencyNames, requirements });
  const databases = detectDatabases({ dependencyNames, requirements, manifestText, compose, paths });
  const usesRedis = dependencyNames.some((name) => /^(redis|ioredis|bullmq|@taskforcesh\/bullmq)$/u.test(name))
    || /\b(redis|celery|rq)\b/u.test(requirements)
    || /image:\s*redis\b/u.test(compose);
  const workers = detectWorkers({ dependencyNames, requirements, compose, paths, manifestText });
  const cron = detectCron({ paths, manifestText, compose });
  const environmentKeys = extractExampleEnvNames(files);
  const hasDockerfile = [...paths].some((path) => /(^|\/)dockerfile$/u.test(path));
  const staticSite = files.length > 0
    && files.some(({ path }) => /\.html?$/iu.test(path))
    && files.every(({ path }) => /\.(?:html?|css|svg|png|jpe?g|gif|webp|ico|woff2?)$/iu.test(path));
  const manifestDependencyCount = dependencyNames.length + countPythonDependencies(requirements);
  const sourceSizeMb = roundMb(source.sourceBytes);
  const buildEstimateMb = estimateBuildSize(source.sourceBytes, framework, manifestDependencyCount);
  const findings = buildFindings({ framework, language: [...language], databases, usesRedis, workers, cron, hasDockerfile, environmentKeys, sourceSizeMb });

  return {
    sourceName: source.sourceName,
    language: [...language].sort(),
    framework,
    hasDockerfile,
    databases,
    usesRedis,
    workers,
    cron,
    environmentKeys,
    fileCount: source.fileCount,
    sourceSizeMb,
    buildEstimateMb,
    findings,
    databaseAmbiguous: databases.length === 0,
    staticSite,
  };
}

function detectFramework(input: { paths: Set<string>; packageJson: Record<string, unknown>; dependencyNames: string[]; requirements: string }) {
  if (input.dependencyNames.includes("next")) return "Next.js";
  if (input.paths.has("manage.py") || /(^|\n)django[=<>~!\s]/u.test(input.requirements)) return "Django";
  if (input.dependencyNames.includes("express")) return "Express";
  if (/\bfastapi\b/u.test(input.requirements)) return "FastAPI";
  if (/\bflask\b/u.test(input.requirements)) return "Flask";
  if (input.dependencyNames.includes("react")) return "React";
  if (input.paths.has("package.json")) return "Node.js";
  if (input.paths.has("manage.py") || input.paths.has("requirements.txt") || input.paths.has("pyproject.toml")) return "Python";
  return "Unknown";
}

function detectDatabases(input: { dependencyNames: string[]; requirements: string; manifestText: string; compose: string; paths: Set<string> }) {
  const found = new Set<string>();
  if (/\b(psycopg2?|psycopg2-binary|asyncpg|pg|postgres|postgresql|django-postgres-extra)\b/u.test(`${input.dependencyNames.join(" ")} ${input.requirements} ${input.manifestText} ${input.compose}`)) found.add("PostgreSQL");
  if (/\b(mysql|mysql2|mariadb|pymysql)\b/u.test(`${input.dependencyNames.join(" ")} ${input.requirements} ${input.manifestText} ${input.compose}`)) found.add("MySQL/MariaDB");
  if (/\b(mongodb|mongoose|pymongo)\b/u.test(`${input.dependencyNames.join(" ")} ${input.requirements} ${input.manifestText} ${input.compose}`)) found.add("MongoDB");
  if (input.paths.has("db.sqlite3") || /\bsqlite3?\b/u.test(`${input.dependencyNames.join(" ")} ${input.requirements}`)) found.add("SQLite");
  if (/provider\s*=\s*["']postgresql["']/u.test(input.manifestText)) found.add("PostgreSQL");
  return [...found].sort();
}

function detectWorkers(input: { dependencyNames: string[]; requirements: string; compose: string; paths: Set<string>; manifestText: string }) {
  const found = new Set<string>();
  if (/\bcelery\b/u.test(input.requirements) || /\bcelery\b/u.test(input.compose)) found.add("Celery worker");
  if (input.dependencyNames.includes("bullmq") || input.dependencyNames.includes("@taskforcesh/bullmq")) found.add("BullMQ worker");
  if (input.dependencyNames.includes("agenda")) found.add("Agenda worker");
  if (input.paths.has("procfile") && /\bworker\s*:/u.test(input.manifestText)) found.add("Procfile worker");
  if (/services:\s*[\s\S]{0,1200}\bworker\s*:/u.test(input.compose)) found.add("Docker Compose worker");
  if (input.dependencyNames.includes("redis") || input.dependencyNames.includes("ioredis")) found.add("Queue/worker support");
  return [...found].sort();
}

function detectCron(input: { paths: Set<string>; manifestText: string; compose: string }) {
  const found = new Set<string>();
  if ([...input.paths].some((path) => /(^|\/)(crontab|cron\.yaml|cron\.yml|schedule\.py)$/iu.test(path))) found.add("Cron configuration file");
  if (/(^|\n)\s*schedule\s*:/u.test(input.manifestText)) found.add("GitHub Actions schedule");
  if (/\b(cron|node-cron|crontab)\b/u.test(input.manifestText)) found.add("Cron dependency/configuration");
  if (/\bcron\s*:/u.test(input.compose)) found.add("Docker Compose cron service");
  return [...found].sort();
}

function extractExampleEnvNames(files: RepoSourceFile[]) {
  const example = files.find(({ path }) => path.toLowerCase() === ".env.example");
  if (!example?.text) return [];
  return [...new Set(example.text.split(/\r?\n/u).flatMap((line) => {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) return [];
    const split = trimmed.indexOf("=");
    if (split < 1) return [];
    const key = trimmed.slice(0, split).trim();
    return /^[A-Za-z_][A-Za-z0-9_]*$/u.test(key) ? [key] : [];
  }))].sort();
}

function estimateBuildSize(sourceBytes: number, framework: string, dependencyCount: number) {
  const size = Math.max(sourceBytes / 1024 / 1024, 0.25);
  const factor = framework === "Next.js" ? [1.5, 6] : framework === "Django" || framework === "FastAPI" || framework === "Flask" ? [1.2, 4] : [1.2, 5];
  return {
    min: Math.max(1, Math.ceil(size * factor[0])),
    max: Math.max(2, Math.ceil(size * factor[1] + dependencyCount * 1.5)),
    note: "برآورد بر پایهٔ منبع و manifest است؛ build واقعی اجرا نشده است.",
  };
}

function buildFindings(input: { framework: string; language: string[]; databases: string[]; usesRedis: boolean; workers: string[]; cron: string[]; hasDockerfile: boolean; environmentKeys: string[]; sourceSizeMb: number }) {
  const findings = [`Detected ${input.framework} from checked-in manifest and project files.`];
  if (input.databases.length) findings.push(`Database evidence: ${input.databases.join(", ")}.`);
  if (input.usesRedis) findings.push("Redis dependency or service evidence detected.");
  if (input.workers.length) findings.push(`Worker evidence: ${input.workers.join(", ")}.`);
  if (input.cron.length) findings.push(`Cron evidence: ${input.cron.join(", ")}.`);
  if (input.hasDockerfile) findings.push("A Dockerfile is present.");
  if (input.environmentKeys.length) findings.push(`Found ${input.environmentKeys.length} variable names in .env.example; values were not returned.`);
  findings.push(`Source archive contains about ${input.sourceSizeMb} MB of non-vendored files.`);
  return findings;
}

function isRelevantTextFile(path: string) {
  const lower = path.toLowerCase();
  if (lower === ".env") return false;
  if (ignoredPath(path)) return false;
  return lower === ".env.example" || lower === "package.json" || lower.endsWith("/package.json")
    || lower === "requirements.txt" || /requirements[^/]*\.txt$/u.test(lower) || lower.endsWith("pyproject.toml")
    || lower.endsWith("pipfile") || lower === "dockerfile" || lower.endsWith("/dockerfile")
    || lower.endsWith("docker-compose.yml") || lower.endsWith("docker-compose.yaml") || lower.endsWith("compose.yml") || lower.endsWith("compose.yaml")
    || lower === "procfile" || lower.endsWith("/procfile") || lower.endsWith("schema.prisma")
    || lower.endsWith("/manage.py") || lower.endsWith("/go.mod") || /^\.github\/workflows\/.*\.ya?ml$/u.test(lower)
    || /(^|\/)(crontab|cron\.yaml|cron\.yml|schedule\.py)$/u.test(lower);
}

function isSignalTextFile(path: string) {
  const lower = path.toLowerCase();
  return lower === ".env.example" || /(^|\/)(package\.json|requirements[^/]*\.txt|pyproject\.toml|pipfile|dockerfile|docker-compose\.ya?ml|compose\.ya?ml|procfile|schema\.prisma)$/u.test(lower)
    || /^\.github\/workflows\/.*\.ya?ml$/u.test(lower) || /(^|\/)(crontab|cron\.ya?ml|schedule\.py)$/u.test(lower);
}

export function shouldReadRepoEntry(path: string) {
  return isRelevantTextFile(path);
}

function ignoredPath(path: string) {
  return /(^|\/)(node_modules|vendor|\.git|\.next|dist|build|__pycache__)(\/|$)/iu.test(path) || /(^|\/)\.env$/iu.test(path);
}

function findCommonArchiveRoot(paths: string[]) {
  if (!paths.length || paths.some((path) => !path.includes("/"))) return undefined;
  const root = paths[0].slice(0, paths[0].indexOf("/"));
  return paths.every((path) => path.startsWith(`${root}/`)) ? root : undefined;
}

function stripArchiveRoot(path: string, root?: string) {
  return root ? path.slice(root.length + 1) : path;
}

function safeJson(value: string | undefined): Record<string, unknown> {
  if (!value) return {};
  try { return JSON.parse(value) as Record<string, unknown>; } catch { return {}; }
}

function countPythonDependencies(requirements: string) {
  return requirements.split(/\r?\n/u).filter((line) => /^[a-z0-9_.-]+\s*(?:[<>=!~]|$)/iu.test(line.trim()) && !line.trim().startsWith("#")).length;
}

function roundMb(bytes: number) { return Math.round(bytes / 1024 / 1024 * 10) / 10; }
