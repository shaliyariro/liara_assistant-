import { mkdtemp, readdir, readFile, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { ZipFile } from "yazl";
import { analyzeZipArchive, shouldReadRepoEntry } from "./analyze-repo";
import { getLiaraPlanCatalog, normalizeLiveCatalog } from "@/lib/liara/plan-catalog";
import { balanceStatusFromLiaraMe, buildPlanQuestions, recommendPlan, type PlanAnswers } from "@/lib/plan-rules";

const fixturesRoot = join(process.cwd(), "tests", "fixtures", "repos");

describe("F01 repository analysis and plan selection V1–V8", () => {
  it("V1: detects Django/Postgres, Next.js, and simple Node repositories from ZIPs", async () => {
    const django = await analyzeZipArchive(await zipDirectory(join(fixturesRoot, "django-postgres"), "django-sample"), "django-sample.zip");
    const nextjs = await analyzeZipArchive(await zipDirectory(join(fixturesRoot, "nextjs"), "next-sample"), "next-sample.zip");
    const node = await analyzeZipArchive(await zipDirectory(join(fixturesRoot, "node-simple"), "node-sample"), "node-sample.zip");

    expect(django).toMatchObject({ framework: "Django", databases: ["PostgreSQL"], usesRedis: true, hasDockerfile: true });
    expect(django.workers.join(" ")).toContain("Celery");
    expect(django.environmentKeys).toEqual(["DATABASE_URL", "DJANGO_SECRET_KEY"]);
    expect(nextjs).toMatchObject({ framework: "Next.js", databases: [], usesRedis: false });
    expect(node).toMatchObject({ framework: "Node.js", databases: [], usesRedis: false });
  });

  it("V2: limits questions to four and gives each one a default recommendation", async () => {
    const [django, node] = await Promise.all([
      analyzeZipArchive(await zipDirectory(join(fixturesRoot, "django-postgres"), "django-sample"), "django.zip"),
      analyzeZipArchive(await zipDirectory(join(fixturesRoot, "node-simple"), "node-sample"), "node.zip"),
    ]);
    for (const analysis of [django, node]) {
      const questions = buildPlanQuestions(analysis);
      expect(questions.length).toBeLessThanOrEqual(4);
      expect(questions.length).toBeGreaterThan(0);
      expect(questions.every((question) => question.recommendation && question.recommendationText)).toBe(true);
    }
  });

  it("V3: shows three real catalog plans, API resources, costs, and evidence-based reasoning", async () => {
    const analysis = await analyzeZipArchive(await zipDirectory(join(fixturesRoot, "django-postgres"), "django-sample"), "django.zip");
    const catalog = normalizeLiveCatalog(livePlans(), "2026-10-23T00:00:00.000Z");
    const recommendation = recommendPlan(analysis, { traffic: "dozens", priority: "balanced", domain: "temporary" }, catalog);
    expect(recommendation.options).toHaveLength(3);
    expect(recommendation.options.map(({ plan }) => plan.id)).toEqual(["small-g2", "medium-g2", "pro-g2"]);
    expect(recommendation.options[0]).toMatchObject({ monthlyToman: 1_424_994, plan: { memoryGb: 0.5, cpuCores: 0.5, diskGb: 5 } });
    expect(recommendation.options[1].services.map((service) => service.name)).toEqual(["PostgreSQL", "Redis"]);
    expect(recommendation.reason).toContain("PostgreSQL");
    expect(recommendation.reason.length).toBeLessThanOrEqual(260);
  });

  it("V4: ignores .env while reading only environment variable names from .env.example", async () => {
    expect(shouldReadRepoEntry(".env")).toBe(false);
    expect(shouldReadRepoEntry(".env.example")).toBe(true);
    const analysis = await analyzeZipArchive(await makeZip("fixture", {
      ".env": "DATABASE_URL=do-not-read-this-secret-value",
      ".env.example": "DATABASE_URL=\nSECRET_KEY=placeholder-only\n# COMMENTED_OUT=x\n",
      "package.json": "{\"name\":\"node\",\"dependencies\":{}}",
      "server.js": "console.log('safe')",
    }), "env-test.zip");
    expect(analysis.environmentKeys).toEqual(["DATABASE_URL", "SECRET_KEY"]);
    expect(JSON.stringify(analysis)).not.toContain("do-not-read-this-secret-value");
    expect(JSON.stringify(analysis)).not.toContain("placeholder-only");
  });

  it("V5: shows real cached plans as stale when the live plan API is unavailable", async () => {
    const directory = await mkdtemp(join(tmpdir(), "liara-plans-test-"));
    const cachePath = join(directory, "plans.json");
    const fresh = normalizeLiveCatalog(livePlans(), "2026-10-22T10:00:00.000Z");
    await import("node:fs/promises").then(({ writeFile }) => writeFile(cachePath, JSON.stringify({ updatedAt: fresh.updatedAt, projects: fresh.projects, databases: fresh.databases }), "utf8"));
    try {
      const result = await getLiaraPlanCatalog({ fetchLive: async () => { throw new Error("API offline"); }, cachePath });
      expect(result).toMatchObject({ source: "cache", isStale: true });
      expect(result.projects[0]?.id).toBe("small-g2");
      expect(result.limitation?.detail).toContain("may be outdated");
    } finally { await rm(directory, { recursive: true, force: true }); }
  });

  it("V6: never claims a current balance and provides the Liara console for user-side recharge", () => {
    const status = balanceStatusFromLiaraMe({ user: { minCreditAmount: 20_000 } });
    expect(status.currentBalance).toBeNull();
    expect(status.rechargeUrl).toBe("https://console.liara.ir/");
    expect(status.message).toContain("charging is a user action");
  });

  it("V7: returns the first project analysis from a sample ZIP in under 30 seconds", async () => {
    const started = performance.now();
    const result = await analyzeZipArchive(await zipDirectory(join(fixturesRoot, "django-postgres"), "django-sample"), "django.zip");
    expect(performance.now() - started).toBeLessThan(30_000);
    expect(result.framework).toBe("Django");
  });

  it("V8: a new user can continue with the recommended answers and reach a three-card plan comparison", async () => {
    const analysis = await analyzeZipArchive(await zipDirectory(join(fixturesRoot, "node-simple"), "node-sample"), "node.zip");
    const questions = buildPlanQuestions(analysis);
    const values = Object.fromEntries(questions.map(({ id, recommendation }) => [id, recommendation]));
    const answers = values as PlanAnswers;
    const result = recommendPlan(analysis, answers, normalizeLiveCatalog(livePlans(), "2026-10-23T00:00:00.000Z"));
    expect(questions.length).toBeLessThanOrEqual(4);
    expect(result.options.map((option) => option.role)).toEqual(["economic", "recommended", "safer"]);
    expect(result.options.every((option) => option.monthlyToman > 0 && option.plan.cpuCores > 0 && option.plan.memoryGb > 0)).toBe(true);
  });
});

async function zipDirectory(directory: string, root: string) {
  const zip = new ZipFile();
  for (const path of await walk(directory)) {
    const fullPath = join(directory, path);
    const info = await stat(fullPath);
    if (!info.isFile()) continue;
    zip.addBuffer(await readFile(fullPath), `${root}/${path.replace(/\\/gu, "/")}`, { compress: true });
  }
  zip.end();
  const chunks: Buffer[] = [];
  for await (const chunk of zip.outputStream) chunks.push(Buffer.from(chunk));
  return Buffer.concat(chunks);
}

async function walk(directory: string, prefix = ""): Promise<string[]> {
  const entries = await readdir(directory, { withFileTypes: true });
  const paths = await Promise.all(entries.map(async (entry) => {
    const path = prefix ? join(prefix, entry.name) : entry.name;
    return entry.isDirectory() ? walk(join(directory, entry.name), path) : [path];
  }));
  return paths.flat();
}

async function makeZip(root: string, files: Record<string, string>) {
  const zip = new ZipFile();
  for (const [path, contents] of Object.entries(files)) zip.addBuffer(Buffer.from(contents), `${root}/${path}`, { compress: true });
  zip.end();
  const chunks: Buffer[] = [];
  for await (const chunk of zip.outputStream) chunks.push(Buffer.from(chunk));
  return Buffer.concat(chunks);
}

function livePlans() {
  const projectPlan = (available: boolean, ram: number, cpu: number, disk: number, price: number) => ({ available, region: "iran", RAM: { amount: ram }, CPU: { amount: cpu }, volume: disk, price });
  const servicePlan = (id: string, available: boolean, ram: number, price: number) => ({
    available, region: "iran", RAM: { amount: ram }, CPU: { amount: 0.5 }, volume: 5, price,
    supports: [id],
  });
  return {
    plans: {
      projects: {
        "small-g2": projectPlan(true, 0.5, 0.5, 5, 659.72),
        "medium-g2": projectPlan(true, 1, 1, 10, 1145.83),
        "pro-g2": projectPlan(true, 8, 4, 80, 6388.88),
        "unavailable-g2": projectPlan(false, 2, 1, 20, 1),
      },
      databases: {
        "pg-g2": servicePlan("postgres", true, 0.5, 659.72),
        "redis-g2": servicePlan("redis", true, 0.5, 659.72),
      },
    },
    user: { minCreditAmount: 20_000 },
  };
}
