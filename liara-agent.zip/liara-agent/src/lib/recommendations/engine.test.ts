import { describe, expect, it } from "vitest";
import { buildApprovalCard } from "@/lib/approval/cards";
import { analyzeEvidence } from "@/lib/diagnosis/analyze";
import { normalizeLiveCatalog } from "@/lib/liara/plan-catalog";
import { analyzeRepoSource } from "@/lib/repo/analyze-repo";
import { createLiaraToolRegistry } from "@/lib/tools/liara-tools";
import { ToolRegistry } from "@/lib/tools/registry";
import { createManualServiceSetupTool } from "@/lib/tools/analysis-planning";
import { recommendForDiagnosis, recommendForProject } from "./engine";

describe("F05 recommendation engine V1–V5", () => {
  it("V1: recommends a Python plan, PostgreSQL, and Redis from Django dependencies", () => {
    const recommendations = recommendForProject(djangoRepo(), catalog());
    expect(recommendations.map(({ id }) => id)).toEqual(["project-plan", "postgres-service", "redis-service"]);
    expect(recommendations[0].evidence).toContain("Django");
    expect(recommendations[1].evidence).toContain("PostgreSQL");
    expect(recommendations[2].evidence).toContain("Celery");
    for (const recommendation of recommendations) {
      expect(recommendation.reason).toContain(recommendation.evidence);
      expect(recommendation.reason).toContain(recommendation.rule);
      expect(recommendation.reason).toContain(recommendation.proposal);
      expect(recommendation.reason).not.toMatch(/for better performance|برای عملکرد بهتر/iu);
    }
  });

  it("V2: a refused database connection suggests a database check and never a plan upgrade", () => {
    const diagnosis = analyzeEvidence(evidence(["psycopg2.OperationalError: connection refused"]));
    const recommendations = recommendForDiagnosis(diagnosis);
    expect(diagnosis.finding.causes[0]?.id).toBe("database_connection");
    expect(recommendations).toHaveLength(1);
    expect(recommendations[0]).toMatchObject({ toolName: "get_app_status", riskLevel: "green" });
    expect(recommendations.some(({ toolName }) => toolName === "change_plan")).toBe(false);
    expect(recommendations[0].rule).toContain("connection refusal");
  });

  it("V3: a static HTML/CSS project selects the lowest real plan and names its light contents", () => {
    const analysis = analyzeRepoSource({ sourceName: "static", sourceBytes: 250, fileCount: 3, files: [
      { path: "index.html", size: 100, text: "<h1>Hello</h1>" },
      { path: "site.css", size: 100, text: "body { margin: 0 }" },
      { path: "logo.svg", size: 50, text: "<svg/>" },
    ] });
    const recommendations = recommendForProject(analysis, catalog());
    const plan = recommendations.find(({ id }) => id === "project-plan");
    expect(analysis.staticSite).toBe(true);
    expect(plan?.action).toContain("small");
    expect(plan?.reason).toContain("static HTML/CSS/assets");
    expect(plan?.financialEffect).toContain(new Intl.NumberFormat("en-US").format(catalog().projects[0].monthlyToman));
  });

  it("V4: strong OOM evidence yields a red plan recommendation backed by F04 ApprovalCard metadata", () => {
    const diagnosis = analyzeEvidence(evidence(["Fatal error: out of memory; heap out of memory"]));
    const recommendation = recommendForDiagnosis(diagnosis)[0];
    expect(recommendation).toMatchObject({ toolName: "change_plan", riskLevel: "red", execution: "approval" });
    const registry = createLiaraToolRegistry({} as never);
    const tool = registry.get("change_plan");
    const card = buildApprovalCard(tool, { projectId: "demo", planID: "small-g2", monthlyCost: 1000 }, { rationale: recommendation.reason });
    expect(card).toMatchObject({ toolName: "change_plan", riskLevel: "red", monthlyCost: 1000 });
    expect(card?.consequence).toContain("هزینه");
  });

  it("V5: never repeats database creation guidance for services already connected", () => {
    const recommendations = recommendForProject(djangoRepo(), catalog(), { existingServices: ["postgres", "redis"] });
    expect(recommendations.map(({ id }) => id)).toEqual(["project-plan"]);
    const registry = new ToolRegistry();
    registry.register(createManualServiceSetupTool());
    expect(registry.list()).toContainEqual({ name: "manual_service_setup", riskLevel: "green" });
  });
});

function djangoRepo() {
  return analyzeRepoSource({ sourceName: "django-example", sourceBytes: 170, fileCount: 3, files: [
    { path: "manage.py", size: 20, text: "" },
    { path: "requirements.txt", size: 100, text: "Django==5.0\npsycopg2-binary==2.9\ncelery==5.3\nredis==5.0" },
    { path: ".env.example", size: 50, text: "DATABASE_URL=\nREDIS_URL=" },
  ] });
}

function evidence(logs: string[]) {
  return { appName: "demo-app", status: null, logs, metrics: null, releases: null, probe: null, limitations: [], observedAt: "2026-10-23T00:00:00.000Z" };
}

function catalog() {
  return normalizeLiveCatalog({ plans: {
    projects: {
      small: { available: true, region: "iran", RAM: { amount: 0.5 }, CPU: { amount: 0.5 }, volume: 5, price: 659.72 },
      medium: { available: true, region: "iran", RAM: { amount: 1 }, CPU: { amount: 1 }, volume: 10, price: 1145.83 },
      large: { available: true, region: "iran", RAM: { amount: 2 }, CPU: { amount: 2 }, volume: 20, price: 2200 },
    },
    databases: {
      pg: { available: true, region: "iran", RAM: { amount: 0.5 }, CPU: { amount: 0.5 }, volume: 5, price: 659.72, supports: ["postgres"] },
      redis: { available: true, region: "iran", RAM: { amount: 0.5 }, CPU: { amount: 0.5 }, volume: 5, price: 500, supports: ["redis"] },
    },
  } }, "2026-10-23T00:00:00.000Z");
}
