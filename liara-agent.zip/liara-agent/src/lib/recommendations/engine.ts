import type { DiagnosisResult } from "@/lib/diagnosis/types";
import type { LiaraPlanCatalog } from "@/lib/liara/plan-catalog";
import type { RepoAnalysis } from "@/lib/repo/analyze-repo";
import { recommendPlan, type PlanAnswers } from "@/lib/plan-rules";

export type Recommendation = {
  id: string;
  action: string;
  toolName: string;
  riskLevel: "green" | "red";
  execution: "tool" | "approval" | "manual";
  evidence: string;
  rule: string;
  proposal: string;
  reason: string;
  financialEffect: string;
  stabilityEffect: string;
  downtimeEffect: string;
  alternative: string;
  manualStep?: string;
};

const GENERIC_REASONS = /\b(?:for|to) better performance\b|\bimprove performance\b|برای عملکرد بهتر/iu;
const SERVICE_MANUAL = "Liara database and Redis create operations are documented but were not live-verified in phase 0; confirm existing services in the console before creating one.";

export function recommendForProject(
  analysis: RepoAnalysis,
  catalog: LiaraPlanCatalog,
  options: { answers?: PlanAnswers; existingServices?: string[] } = {},
): Recommendation[] {
  const answers: PlanAnswers = options.answers ?? { traffic: "trial", priority: "balanced", domain: "temporary" };
  const result = recommendPlan(analysis, answers, catalog);
  const recommendations: Recommendation[] = [];
  const preferred = result.options.find((option) => option.role === "recommended") ?? result.options[0];
  const catalogLabel = catalog.isStale ? "Liara's cached catalog (may be outdated)" : "the current Liara API catalog";

  if (preferred) {
    const resourceEvidence = analysis.staticSite
      ? `The repository contains ${analysis.fileCount} files classified as static HTML/CSS/assets (${analysis.sourceSizeMb} MB source).`
      : `${analysis.framework} was detected; estimated build size is ${analysis.buildEstimateMb.min}–${analysis.buildEstimateMb.max} MB.`;
    const proposal = analysis.staticSite
      ? `Choose the lowest available project plan, ${preferred.plan.id}, at ${formatMoney(preferred.plan.monthlyToman)} Toman/month.`
      : `Start the ${analysis.language.includes("Python") ? "Python" : analysis.framework} project on the real ${preferred.plan.id} plan (${preferred.plan.cpuCores} CPU, ${preferred.plan.memoryGb} GB RAM) at ${formatMoney(preferred.plan.monthlyToman)} Toman/month.`;
    recommendations.push(make({
      id: "project-plan", action: proposal, toolName: "recommend_plan", riskLevel: "green", execution: "tool",
      evidence: resourceEvidence,
      rule: analysis.staticSite
        ? "When only static site assets are present, select the lowest-priced available project plan; no application runtime was detected."
        : `Use the live Liara project-plan catalog and the configured ${answers.traffic} traffic / ${answers.priority} priority rules; do not invent resource sizes or prices.`,
      proposal,
      financialEffect: `Quoted from ${catalogLabel}: ${formatMoney(preferred.plan.monthlyToman)} Toman/month for the app plan; service charges are separate.`,
      stabilityEffect: `${preferred.plan.cpuCores} CPU and ${preferred.plan.memoryGb} GB RAM are the catalog resources; this is a starting choice, not a capacity guarantee.`,
      downtimeEffect: "No change is applied by this recommendation; deploy/resize requires its existing approval flow.",
      alternative: result.options.find((option) => option.role === "economic")?.plan.id === preferred.plan.id
        ? "Compare the safer plan in the plan card before deployment."
        : `Choose the ${result.options.find((option) => option.role === "economic")?.plan.id ?? "lower-priced"} option to reduce monthly cost.`,
    }));
  }

  const existing = new Set((options.existingServices ?? []).map(normalizeEngine));
  const needsPostgres = analysis.databases.some((database) => /postgres/i.test(database));
  const needsRedis = analysis.usesRedis || analysis.workers.some((worker) => /celery|bullmq|queue/i.test(worker));
  if (needsPostgres && !existing.has("postgres")) {
    const servicePlan = catalog.databases.find((plan) => plan.supportedEngines.some((engine) => /postgres/i.test(engine)));
    recommendations.push(serviceRecommendation({
      id: "postgres-service", name: "PostgreSQL", engine: "postgres", evidence: `Repository dependency detection found ${analysis.databases.filter((item) => /postgres/i.test(item)).join(", ")}.`,
      rule: "A PostgreSQL client requires a reachable PostgreSQL endpoint and valid connection settings; Liara publishes matching database plans in the live catalog.",
      planCost: servicePlan?.monthlyToman,
      priceSource: catalogLabel,
    }));
  }
  if (needsRedis && !existing.has("redis")) {
    const servicePlan = catalog.databases.find((plan) => plan.supportedEngines.some((engine) => /redis/i.test(engine)));
    const evidence = analysis.workers.length
      ? `Repository dependency detection found ${analysis.workers.join(", ")}.`
      : "Repository dependency detection found a Redis client.";
    recommendations.push(serviceRecommendation({
      id: "redis-service", name: "Redis", engine: "redis", evidence,
      rule: "Celery, BullMQ, and Redis queue clients use Redis as a broker or queue store; a reachable endpoint and matching environment value are required.",
      planCost: servicePlan?.monthlyToman,
      priceSource: catalogLabel,
    }));
  }
  return recommendations;
}

export function recommendForDiagnosis(result: DiagnosisResult): Recommendation[] {
  const { finding, evidence } = result;
  const primaryCause = finding.causes[0];
  if (!primaryCause) return [];
  const matchingEvidence = finding.evidence.slice(0, 3).join(" ") || primaryCause.explanation;
  if (primaryCause.id === "database_connection" || primaryCause.id === "incomplete_env") {
    return [make({
      id: "database-connection-check", action: "Collect a fresh app status and database connection check", toolName: "get_app_status", riskLevel: "green", execution: "tool",
      evidence: `${primaryCause.title}: ${matchingEvidence}`,
      rule: "A refused or timed-out database connection points to endpoint, network, credentials, or service availability; app RAM/CPU changes do not repair a connection refusal.",
      proposal: "Verify the configured database endpoint and service health before changing the app plan.",
      financialEffect: "No plan or database purchase is proposed from this evidence.",
      stabilityEffect: "Correcting the endpoint or restoring the database can resolve connection failures; the available evidence does not prove which one failed.",
      downtimeEffect: "Checking is read-only; changing an environment value may restart the app.",
      alternative: "Inspect redacted connection errors and Liara database status manually.",
    })];
  }
  if (primaryCause.id === "oom" || primaryCause.id === "cpu_pressure" || primaryCause.id === "slow_response") {
    const explicitOom = evidence.logs.some((line) => /out of memory|heap out of memory|killed process/iu.test(line));
    const strongCpu = Object.entries(evidence.metrics ?? {}).some(([name, value]) => /cpu/i.test(name) && value >= 90);
    const strongResourceEvidence = explicitOom || strongCpu;
    const toolName = strongResourceEvidence ? "change_plan" : "restart";
    const riskLevel = strongResourceEvidence ? "red" : "green";
    const execution = strongResourceEvidence ? "approval" : "tool";
    const proposal = strongResourceEvidence
      ? "Compare the live Liara plan catalog; consider a larger plan only after confirming the process is not stuck and the resource signal is current."
      : "Try the no-cost restart and inspect a fresh health probe before considering a plan change.";
    return [make({
      id: "resource-pressure", action: proposal, toolName, riskLevel, execution,
      evidence: `${primaryCause.title}: ${matchingEvidence}`,
      rule: strongResourceEvidence
        ? "An explicit OOM log or measured CPU at/above 90% is strong resource evidence; any paid resize remains red and must use F04 approval."
        : "Latency or a heuristic memory signal alone is insufficient for a paid upgrade; try reversible software actions first.",
      proposal,
      financialEffect: strongResourceEvidence ? "A plan change can increase recurring monthly charges; show the live quote in ApprovalCard." : "Restart has no plan-price increase; no upgrade is proposed yet.",
      stabilityEffect: strongResourceEvidence ? "More allocated resources may reduce confirmed resource exhaustion; it will not fix application defects." : "Restart may clear a transient stuck process; it does not establish the root cause.",
      downtimeEffect: strongResourceEvidence ? "Resizing may restart the app; confirm the expected interruption in ApprovalCard." : "Restart can briefly interrupt requests.",
      alternative: strongResourceEvidence ? "Restart, inspect the latest logs, and verify whether the resource signal repeats." : "Inspect logs and metrics again; investigate the application code if the symptom returns.",
    })];
  }
  return [];
}

export function recommendForLocalDemo(result: DiagnosisResult): Recommendation[] {
  const cause = result.finding.causes[0];
  const latency = result.evidence.probe?.durationMs;
  if (cause?.id !== "slow_response" || latency === undefined || latency === null) return [];
  return [make({
    id: "demo-slow-fix", action: `Disable the injected slow response measured at ${latency} ms`, toolName: "disable_demo_failure", riskLevel: "green", execution: "tool",
    evidence: `The local demo's /slow probe returned HTTP ${result.evidence.probe?.status ?? "unknown"} in ${latency} ms.`,
    rule: "The demo's reversible slow failure is controlled by its local failure toggle; disabling that toggle removes the injected delay without changing Liara resources.",
    proposal: "Turn off only the injected slow failure, then repeat the HTTP probe and compare the measured slowResponseMs metric.",
    financialEffect: "No Liara plan or paid service changes.",
    stabilityEffect: "Removes the deliberate demo delay; it does not claim to repair unrelated production bottlenecks.",
    downtimeEffect: "No process restart; the next /slow request should return immediately.",
    alternative: "Leave the failure active and inspect the demo logs and measured response time.",
  })];
}

function serviceRecommendation(input: { id: string; name: string; engine: string; evidence: string; rule: string; planCost?: number; priceSource: string }): Recommendation {
  const quote = input.planCost === undefined ? "No matching available plan was returned; confirm the Liara console catalog." : `${formatMoney(input.planCost)} Toman/month from ${input.priceSource}`;
  return make({
    id: input.id, action: `Check for an existing ${input.name} service, then create or connect it manually`, toolName: "manual_service_setup", riskLevel: "green", execution: "manual",
    evidence: input.evidence,
    rule: input.rule,
    proposal: `Check whether ${input.name} is already connected; if not, select an available Liara ${input.name} plan (${quote}).`,
    financialEffect: quote === "No matching available plan was returned; confirm the Liara console catalog." ? quote : `Potential recurring service charge: ${quote}; creation is not automated because the DBaaS write API is not phase-0 live-verified.`,
    stabilityEffect: `A reachable ${input.name} endpoint is required by the detected project dependency.`,
    downtimeEffect: "Manual service creation/connection can change availability; confirm the app configuration before switching endpoints.",
    alternative: `If an existing ${input.name} is already connected, keep it and verify its host and credentials instead.`,
    manualStep: `${SERVICE_MANUAL} In Liara Console, open Databases, inspect existing ${input.name} services, and create one only if none is connected. Then add its connection setting in the deployment environment; do not paste secret values into this app's chat.`,
  });
}

function make(value: Omit<Recommendation, "reason">): Recommendation {
  const reason = `${value.evidence} ${value.rule} ${value.proposal}`;
  if (GENERIC_REASONS.test(reason)) throw new Error(`Generic recommendation reason is forbidden: ${value.id}`);
  return { ...value, reason };
}

function normalizeEngine(value: string) {
  if (/postgres|postgresql/iu.test(value)) return "postgres";
  if (/redis/iu.test(value)) return "redis";
  if (/mysql/iu.test(value)) return "mysql";
  if (/mongo/iu.test(value)) return "mongodb";
  return value.toLowerCase();
}

function formatMoney(value: number) {
  return new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(value);
}
