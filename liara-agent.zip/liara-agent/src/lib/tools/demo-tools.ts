import "server-only";
import { z } from "zod";
import { ToolRegistry } from "./registry";
import { defineTool } from "./types";

export function createDemoToolRegistry(fetcher: typeof fetch = fetch) {
  const registry = new ToolRegistry();
  registry.register(createFailureToggleTool("activate_demo_failure", true, fetcher));
  registry.register(createFailureToggleTool("disable_demo_failure", false, fetcher));
  registry.register(defineTool({
    name: "reset_demo_state", riskLevel: "green", requiresEnvelope: false,
    inputSchema: z.object({}).strict(),
    describe: () => ({ action: "Reset local demo failures and measurements", consequence: "Only local loopback demo state is cleared; no Liara resource is touched.", recommendation: "Reset before recording the next demo run.", alternatives: ["Leave the current local state as it is"], reversible: true }),
    withinEnvelope: () => true,
    run: async () => sendControl(fetcher, { reset: true }),
  }));
  return registry;
}

function createFailureToggleTool(name: "activate_demo_failure" | "disable_demo_failure", enabled: boolean, fetcher: typeof fetch) {
  return defineTool({
    name, riskLevel: "green", requiresEnvelope: false,
    inputSchema: z.object({ failure: z.enum(["slow"]) }).strict(),
    describe: () => ({ action: `${enabled ? "Enable" : "Disable"} the local demo's injected slow response`, consequence: "Only the loopback demo service failure toggle is changed; no Liara resource is touched.", recommendation: "Measure the HTTP response before and after the local fix.", alternatives: ["Review local demo logs and metrics"], reversible: true }),
    withinEnvelope: () => true,
    run: async ({ failure }) => sendControl(fetcher, { failure, enabled }),
  });
}

async function sendControl(fetcher: typeof fetch, body: unknown) {
  const response = await fetcher(`${demoBaseUrl()}/controls`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), signal: AbortSignal.timeout(5_000) });
  if (!response.ok) throw new Error(`Local demo control returned HTTP ${response.status}.`);
  return response.json() as Promise<Record<string, unknown>>;
}

export function demoBaseUrl() {
  const configured = process.env.DEMO_BROKEN_APP_URL ?? "http://127.0.0.1:3001";
  let url: URL;
  try { url = new URL(configured); } catch { throw new Error("DEMO_BROKEN_APP_URL is invalid."); }
  if (url.protocol !== "http:" || !["127.0.0.1", "localhost", "[::1]"].includes(url.hostname) || url.username || url.password || url.pathname !== "/") {
    throw new Error("The demo service must use a plain HTTP loopback URL without a path or credentials.");
  }
  return url.origin;
}
