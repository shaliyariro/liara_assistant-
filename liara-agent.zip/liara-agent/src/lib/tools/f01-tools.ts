import "server-only";
import { ToolRegistry } from "./registry";
import { createAnalyzeRepoTool } from "./analyze-repo";
import { createListPlansTool, createManualServiceSetupTool, createRecommendPlanTool } from "./analysis-planning";

export function createF01ToolRegistry(options: {
  fetcher?: typeof fetch;
  uploadedZip?: { name: string; bytes: Uint8Array };
  fetchPlans?: Parameters<typeof createListPlansTool>[0];
} = {}) {
  const registry = new ToolRegistry();
  registry.register(createAnalyzeRepoTool(options.fetcher, options.uploadedZip));
  registry.register(createListPlansTool(options.fetchPlans));
  registry.register(createRecommendPlanTool());
  registry.register(createManualServiceSetupTool());
  return registry;
}
