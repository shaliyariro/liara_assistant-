import "server-only";
import { z } from "zod";
import { analyzeZipArchive, RepoAnalysisError, type RepoAnalysis } from "@/lib/repo/analyze-repo";
import { defineTool } from "./types";

const githubSource = z.object({ type: z.literal("github"), url: z.string().url() }).strict();
const zipSource = z.object({ type: z.literal("zip"), name: z.string().min(1).max(150) }).strict();

export const analyzeRepoInputSchema = z.object({ source: z.discriminatedUnion("type", [githubSource, zipSource]) }).strict();

export function createAnalyzeRepoTool(fetcher: typeof fetch = fetch, uploadedZip?: { name: string; bytes: Uint8Array }) {
  return defineTool({
    name: "analyze_repo",
    riskLevel: "green",
    requiresEnvelope: false,
    inputSchema: analyzeRepoInputSchema,
    describe: () => ({ action: "Analyze a repository manifest and project structure", consequence: "Read-only analysis; .env values are never read or returned.", recommendation: "Review the detected project facts before choosing a plan.", alternatives: ["Cancel analysis"], reversible: false }),
    withinEnvelope: () => true,
    run: async ({ source }): Promise<RepoAnalysis> => {
      if (source.type === "zip") {
        if (!uploadedZip || uploadedZip.name !== source.name) throw new RepoAnalysisError("The selected ZIP was not available to the analyzer.");
        return analyzeZipArchive(Buffer.from(uploadedZip.bytes), source.name);
      }
      const { owner, repository } = parsePublicGithubUrl(source.url);
      const headers = new Headers({ Accept: "application/vnd.github+json", "User-Agent": "liara-project-analyzer" });
      if (process.env.GITHUB_TOKEN) headers.set("Authorization", `Bearer ${process.env.GITHUB_TOKEN}`);
      let response: Response;
      try {
        response = await fetcher(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repository)}/zipball`, {
          headers, signal: AbortSignal.timeout(20_000),
        });
      } catch {
        throw new RepoAnalysisError("GitHub could not be reached within 20 seconds. Try uploading a ZIP.", 504);
      }
      if (!response.ok) {
        if (response.status === 404 && !process.env.GITHUB_TOKEN) throw new RepoAnalysisError("This repository is private or unavailable. Configure GITHUB_TOKEN on the server or upload a ZIP.", 403);
        throw new RepoAnalysisError(response.status === 404 ? "GitHub repository was not found or access was denied." : `GitHub returned HTTP ${response.status}.`, response.status === 404 ? 404 : 502);
      }
      const declaredLength = Number(response.headers.get("content-length") ?? 0);
      if (declaredLength > 25 * 1024 * 1024) throw new RepoAnalysisError("The GitHub archive exceeds the 25 MB limit.", 413);
      const bytes = await readLimitedResponse(response, 25 * 1024 * 1024);
      if (bytes.length > 25 * 1024 * 1024) throw new RepoAnalysisError("The GitHub archive exceeds the 25 MB limit.", 413);
      return analyzeZipArchive(bytes, `${owner}/${repository}`);
    },
  });
}

async function readLimitedResponse(response: Response, limit: number) {
  if (!response.body) return Buffer.alloc(0);
  const reader = response.body.getReader();
  const chunks: Buffer[] = [];
  let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > limit) {
        await reader.cancel();
        throw new RepoAnalysisError("The GitHub archive exceeds the 25 MB limit.", 413);
      }
      chunks.push(Buffer.from(value));
    }
  } finally { reader.releaseLock(); }
  return Buffer.concat(chunks);
}

function parsePublicGithubUrl(value: string) {
  const url = new URL(value);
  if (url.protocol !== "https:" || url.hostname.toLowerCase() !== "github.com" || url.username || url.password || url.search || url.hash) {
    throw new RepoAnalysisError("Use an https://github.com/owner/repository URL.");
  }
  const parts = url.pathname.split("/").filter(Boolean);
  if (parts.length !== 2) throw new RepoAnalysisError("Use the repository root URL, without a branch or file path.");
  const repository = parts[1].replace(/\.git$/iu, "");
  if (!/^[A-Za-z0-9_.-]+$/u.test(parts[0]) || !/^[A-Za-z0-9_.-]+$/u.test(repository)) throw new RepoAnalysisError("GitHub owner or repository name is invalid.");
  return { owner: parts[0], repository };
}
