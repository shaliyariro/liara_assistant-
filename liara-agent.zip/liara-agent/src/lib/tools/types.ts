import { z } from "zod";
import { ApprovalRequiredError, EnvelopeRequiredError, consumeApproval, effectiveRiskLevel, isValidApproval } from "@/lib/approval/gate";
import type { ApprovedEnvelope, ValidApproval } from "@/lib/approval/gate";
import { recordToolOutcome } from "@/lib/audit/record";
import { LiaraError } from "@/lib/liara/errors";

export type RiskLevel = "green" | "red";

export type ToolDescription = {
  action: string;
  consequence: string;
  recommendation: string;
  alternatives: string[];
  reversible: boolean;
  undoAction?: string;
  monthlyCost?: number;
};

export type ToolExecutionContext = { approval?: ValidApproval; envelope?: ApprovedEnvelope; actor?: string };

export type Tool<I extends z.ZodType, O> = {
  name: string;
  riskLevel: RiskLevel;
  /** Read-only discovery tools can run before a project envelope exists. */
  requiresEnvelope?: boolean;
  inputSchema: I;
  describe(input: z.infer<I>): ToolDescription;
  withinEnvelope(input: z.infer<I>, envelope: ApprovedEnvelope): boolean;
  execute(input: unknown, context?: ToolExecutionContext): Promise<O>;
};

export type ToolDefinition<I extends z.ZodType, O> = Omit<Tool<I, O>, "execute"> & { run(input: z.infer<I>): Promise<O> };

export function defineTool<I extends z.ZodType, O>(definition: ToolDefinition<I, O>): Tool<I, O> {
  const { run, ...metadata } = definition;
  const tool: Tool<I, O> = {
    ...metadata,
    async execute(input: unknown, context: ToolExecutionContext = {}) {
      let parsed: z.infer<I> | undefined;
      let riskLevel: RiskLevel = tool.riskLevel;
      let description: ToolDescription | undefined;
      try {
        parsed = definition.inputSchema.parse(input);
        const risk = effectiveRiskLevel(tool, parsed, context.envelope);
        riskLevel = risk.riskLevel;
        description = tool.describe(parsed);
        if (risk.riskLevel === "red") {
          if (!isValidApproval(context.approval, tool.name, parsed)) {
            if (tool.riskLevel === "green") throw new EnvelopeRequiredError();
            throw new ApprovalRequiredError();
          }
          if (!consumeApproval(context.approval!)) throw new ApprovalRequiredError("This approval has already been used.");
        }
        const result = await run(parsed);
        recordToolOutcome({ actor: context.actor ?? "user", toolName: tool.name, riskLevel, parameters: parsed, outcome: "success", userMessage: `Completed: ${description.action}`, reversible: description.reversible, undoAction: description.undoAction });
        return result;
      } catch (error) {
        const liaraError = error instanceof LiaraError ? error : undefined;
        recordToolOutcome({
          actor: context.actor ?? "user", toolName: tool.name, riskLevel, parameters: parsed ?? input, outcome: "failure",
          code: liaraError?.code ?? (error instanceof ApprovalRequiredError ? error.code : "TOOL_FAILED"),
          userMessage: liaraError?.userMessage ?? (error instanceof ApprovalRequiredError ? error.message : "Action failed; sensitive details were omitted."),
          reversible: description?.reversible,
        });
        if (error instanceof z.ZodError) throw new ToolInputError();
        throw error;
      }
    },
  };
  return Object.freeze(tool);
}

export class ToolInputError extends Error {
  readonly code = "INVALID_TOOL_INPUT";
  constructor() { super("Tool input did not match its server-defined schema."); this.name = "ToolInputError"; }
}
