import type { RiskLevel } from "./types";

export const TOOL_RISK_POLICY = Object.freeze({
  analyze_repo: "green",
  list_apps: "green",
  read_status: "green",
  get_app_status: "green",
  get_logs: "green",
  get_metrics: "green",
  get_release_history: "green",
  http_probe: "green",
  read_logs: "green",
  read_metrics: "green",
  create_app: "green",
  set_env: "green",
  upload_source: "green",
  deploy_release: "green",
  redeploy: "green",
  restart_app: "green",
  read_env: "red",
  select_plan: "red",
  change_plan: "red",
  create_database: "red",
  create_redis: "red",
  delete_app: "red",
  delete_database: "red",
  rollback_release: "red",
  add_domain: "red",
  change_domain: "red",
  delete_domain: "red",
  charge_account: "red",
} satisfies Record<string, RiskLevel>);

export function isRiskLevel(value: unknown): value is RiskLevel {
  return value === "green" || value === "red";
}
