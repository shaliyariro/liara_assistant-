import "server-only";
import { getLiaraPlanCatalog } from "@/lib/liara/plan-catalog";
import { planAnswersSchema, planCatalogSchema, recommendPlan } from "@/lib/plan-rules";
import { repoAnalysisSchema } from "@/lib/repo/analyze-repo";
import { z } from "zod";
import { defineTool } from "./types";

type PlanCatalogFetch = NonNullable<Parameters<typeof getLiaraPlanCatalog>[0]>["fetchLive"];

export function createListPlansTool(fetchLive?: PlanCatalogFetch) {
  return defineTool({
    name: "list_plans",
    riskLevel: "green",
    requiresEnvelope: false,
    inputSchema: z.object({}).strict(),
    describe: () => ({ action: "Read currently available Liara plan details", consequence: "Read-only catalog request; no plan is purchased or changed.", recommendation: "Compare only the plans and prices returned by Liara.", alternatives: ["Open the Liara console"], reversible: false }),
    withinEnvelope: () => true,
    run: async () => getLiaraPlanCatalog({ fetchLive }),
  });
}

export function createRecommendPlanTool() {
  return defineTool({
    name: "recommend_plan",
    riskLevel: "green",
    requiresEnvelope: false,
    inputSchema: z.object({ analysis: repoAnalysisSchema, answers: planAnswersSchema, catalog: planCatalogSchema }).strict(),
    describe: () => ({ action: "Compare three available Liara plans against detected project needs", consequence: "Planning only; no account or billing changes are made.", recommendation: "Choose among live plans and verify stale prices before purchase.", alternatives: ["Review all plans in the Liara console"], reversible: false }),
    withinEnvelope: () => true,
    run: async ({ analysis, answers, catalog }) => recommendPlan(analysis, answers, catalog),
  });
}

export function createManualServiceSetupTool() {
  return defineTool({
    name: "manual_service_setup",
    riskLevel: "green",
    requiresEnvelope: false,
    inputSchema: z.object({ service: z.enum(["PostgreSQL", "Redis", "MySQL", "MongoDB"]) }).strict(),
    describe: ({ service }) => ({ action: `Show manual ${service} setup instructions in the Liara console`, consequence: "This tool only provides guidance; it does not create, change, or bill for a service.", recommendation: "Check for an existing connected service before creating one.", alternatives: ["Keep the existing service and verify its connection", "Continue without this dependency if the project does not need it"], reversible: true }),
    withinEnvelope: () => true,
    run: async ({ service }) => ({ service, action: "manual-guidance-only", automatedWriteAvailable: false }),
  });
}
