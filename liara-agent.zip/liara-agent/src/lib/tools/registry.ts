import type { Tool } from "./types";
import type { z } from "zod";
import type { ToolExecutionContext } from "./types";

export class ToolRegistry {
  private readonly tools = new Map<string, Tool<z.ZodType, unknown>>();

  register<I extends z.ZodType, O>(tool: Tool<I, O>): void {
    if (this.tools.has(tool.name)) throw new Error(`Tool already registered: ${tool.name}`);
    this.tools.set(tool.name, tool as Tool<z.ZodType, unknown>);
  }

  get(name: string): Tool<z.ZodType, unknown> {
    const tool = this.tools.get(name);
    if (!tool) throw new Error(`Unknown tool: ${name}`);
    return tool;
  }

  list(): ReadonlyArray<Pick<Tool<z.ZodType, unknown>, "name" | "riskLevel">> {
    return [...this.tools.values()].map(({ name, riskLevel }) => ({ name, riskLevel }));
  }

  execute(name: string, input: unknown, context: ToolExecutionContext = {}): Promise<unknown> {
    return this.get(name).execute(input, context);
  }
}
