import "server-only";
import { getAuditStore } from "@/lib/audit/sqlite";
import { isValidEnvelope, type ApprovedEnvelope } from "@/lib/approval/gate";
import type { ToolExecutionContext } from "./types";

export function resolveToolExecutionContext(input: unknown, actor = "agent"): ToolExecutionContext {
  if (!input || typeof input !== "object" || !("projectId" in input) || typeof input.projectId !== "string") return { actor };
  const envelope = getAuditStore().getApprovedEnvelope<ApprovedEnvelope>(input.projectId);
  return { actor, envelope: isValidEnvelope(envelope) ? envelope : undefined };
}
