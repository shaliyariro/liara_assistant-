export type Limitation = { title: string; detail: string; manualStep: string };

const LIMITATIONS: Readonly<Record<string, Limitation>> = Object.freeze({
  charge_account: {
    title: "شارژ حساب از API در دسترس نیست",
    detail: "Liara برای شارژ حساب مسیر API قابل استفاده‌ای در این اتصال ارائه نمی‌کند.",
    manualStep: "موجودی را از پنل Liara افزایش بده؛ سپس عملیات را دوباره اجرا کن.",
  },
  rollback_release: {
    title: "Rollback خودکار هنوز در API تأیید نشده است",
    detail: "مسیر برگشت release در API قابل اتکای این پروژه ثبت نشده است.",
    manualStep: "از پنل Liara نسخه‌ی قبلی را فعال کن و پس از بررسی، وضعیت اپ را دوباره بخوان.",
  },
});

export function getLimitation(toolName: string): Limitation | undefined { return LIMITATIONS[toolName]; }
