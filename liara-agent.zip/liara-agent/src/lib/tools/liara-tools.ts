import "server-only";
import { readFile } from "node:fs/promises";
import { resolve, sep } from "node:path";
import { z } from "zod";
import { LiaraClient } from "@/lib/liara/client";
import { LiaraError } from "@/lib/liara/errors";
import { isValidEnvelope } from "@/lib/approval/gate";
import type { ApprovedEnvelope } from "@/lib/approval/gate";
import { consumeEnvReadConsent } from "@/lib/approval/env-consent";
import { ToolRegistry } from "./registry";
import { defineTool } from "./types";

const appInput = z.object({ projectId: z.string().min(1).max(120) }).strict();
const appNameInput = z.object({ projectId: z.string().min(1).max(120), appName: z.string().min(1).max(63) }).strict();

export function createReadEnvTool() {
  return defineTool({
    name: "read_env",
    riskLevel: "red",
    inputSchema: z.object({ projectId: z.string().min(1).max(120), workspacePath: z.string().min(1), keys: z.array(z.string().min(1)).min(1) }).strict(),
    describe: ({ projectId, keys }) => ({ action: `مقدارهای ${keys.length} کلید env پروژه‌ی ${projectId} را با ماسک می‌خوانم`, consequence: "اطلاعات محرمانه خوانده می‌شود؛ مقدار خام در خروجی ابزار یا دفترچه ثبت نمی‌شود.", recommendation: "برای این عملیات یک‌بار اجازه بده.", alternatives: ["مقدارها را دستی و ماسک‌شده وارد کن"], reversible: false }),
    withinEnvelope: () => false,
    run: async ({ projectId, workspacePath, keys }) => {
      if (!consumeEnvReadConsent(projectId)) throw new LiaraError("ENV_READ_NOT_ALLOWED", "Environment file access has not been approved for this project.", false);
      const root = resolve(process.env.WORKSPACE_ROOT || process.cwd());
      const directory = resolve(root, workspacePath);
      if (directory !== root && !directory.startsWith(`${root}${sep}`)) throw new LiaraError("INVALID_WORKSPACE_PATH", "The selected workspace is outside the allowed project root.", false);
      const contents = await readFile(resolve(directory, ".env"), "utf8");
      const values = new Map(contents.split(/\r?\n/u).filter((line) => line && !line.trimStart().startsWith("#")).map((line) => {
        const split = line.indexOf("=");
        return split < 1 ? ["", ""] : [line.slice(0, split).trim(), line.slice(split + 1).trim().replace(/^['"]|['"]$/gu, "")];
      }));
      return Object.fromEntries(keys.map((key) => [key, maskEnvValue(values.get(key) ?? "")]));
    },
  });
}

export function createReadEnvArchiveTool(readValues: (keys: string[]) => Promise<Record<string, string>>) {
  return defineTool({
    name: "read_env",
    riskLevel: "red",
    inputSchema: z.object({ projectId: z.string().min(1).max(120), keys: z.array(z.string().min(1).max(120)).min(1).max(100) }).strict(),
    describe: ({ projectId, keys }) => ({ action: `مقدارهای ${keys.length} کلید env پروژه‌ی ${projectId} را در سرور می‌خوانم`, consequence: "دسترسی صریح به داده‌ی محرمانه؛ مقدار خام در UI، audit یا LLM قرار نمی‌گیرد.", recommendation: "برای این عملیات یک‌بار اجازه بده.", alternatives: ["مقدارها را دستی و ماسک‌شده وارد کن"], reversible: false }),
    withinEnvelope: () => false,
    run: async ({ projectId, keys }) => {
      if (!consumeEnvReadConsent(projectId)) throw new LiaraError("ENV_READ_NOT_ALLOWED", "Environment file access has not been approved for this project.", false);
      return readValues(keys);
    },
  });
}

function projectInsideEnvelope(projectId: string, envelope: ApprovedEnvelope) {
  return isValidEnvelope(envelope) && envelope.projectIds.includes(projectId);
}

function resourceInsideEnvelope(envelope: ApprovedEnvelope, kind: "app" | "database" | "redis", id: string, planID: string, monthlyCost: number, bundlePlanID?: string) {
  if (!isValidEnvelope(envelope)) return false;
  const resource = envelope.resources.find((item) => item.id === id && item.kind === kind);
  return Boolean(resource && resource.planID === planID && resource.bundlePlanID === bundlePlanID && resource.monthlyCost === monthlyCost && monthlyCost <= envelope.maxMonthlyCost);
}

export function createLiaraToolRegistry(client = new LiaraClient(), sourceArchive?: Blob) {
  const registry = new ToolRegistry();

  for (const definition of [
    {
      name: "get_app_status",
      label: "وضعیت اپ",
      run: async (appName: string) => (await client.getAppStatus(appName)).data,
    },
    {
      name: "get_logs",
      label: "لاگ‌های اپ",
      run: async (appName: string) => (await client.getLogs(appName)).data,
    },
    {
      name: "get_metrics",
      label: "متریک‌های اپ",
      run: async (appName: string) => (await client.getMetrics(appName)).data,
    },
    {
      name: "get_release_history",
      label: "تاریخچه‌ی release",
      run: async (appName: string) => {
        const history = (await client.getReleaseHistory(appName)).data;
        const releases = history.releases ?? [];
        const detailed = await Promise.all(releases.slice(0, 20).map(async (release) => {
          const releaseID = String(release._id ?? release.id ?? "");
          if (!releaseID) return release;
          try {
            const detail = await client.getRelease(releaseID);
            return { ...release, ...(detail.data.release as Record<string, unknown>) };
          } catch { return release; }
        }));
        return { ...history, releases: detailed };
      },
    },
  ] as const) {
    registry.register(defineTool({
      name: definition.name,
      riskLevel: "green",
      requiresEnvelope: false,
      inputSchema: appNameInput,
      describe: ({ appName }) => ({ action: `${definition.label} ${appName} را می‌خوانم`, consequence: "فقط‌خواندنی؛ تغییری در اپ نمی‌دهد.", recommendation: "شواهد را برای عیب‌یابی مقایسه کن.", alternatives: ["تحلیل را لغو کن"], reversible: false }),
      withinEnvelope: () => true,
      run: async ({ appName }) => definition.run(appName),
    }));
  }

  registry.register(defineTool({
    name: "http_probe",
    riskLevel: "green",
    requiresEnvelope: false,
    inputSchema: appNameInput,
    describe: ({ appName }) => ({ action: `وضعیت HTTP اپ ${appName} را بررسی می‌کنم`, consequence: "یک درخواست GET به دامنه‌ی اپ فرستاده می‌شود.", recommendation: "برای سنجش پاسخ واقعی ادامه بده.", alternatives: ["فقط API را بررسی کن"], reversible: false }),
    withinEnvelope: () => true,
    run: async ({ appName }) => {
      let url = `https://${appName}.iran.liara.run`;
      try {
        const domains = await client.getDomains(appName);
        const candidate = domains.data.domains?.find((domain) => typeof domain.name === "string" && domain.name.includes("."))?.name;
        if (candidate) url = `https://${candidate}`;
      } catch { /* The documented Liara subdomain remains the probe target. */ }
      const parsed = new URL(url);
      if (parsed.protocol !== "https:" || !parsed.hostname.includes(".") || parsed.hostname === "localhost") throw new LiaraError("INVALID_PROBE_TARGET", "The app probe target was not a public HTTPS hostname.", false);
      const startedAt = performance.now();
      try {
        const response = await fetch(url, { redirect: "manual", signal: AbortSignal.timeout(8_000) });
        return { url, status: response.status, durationMs: Math.round(performance.now() - startedAt) };
      } catch {
        return { url, status: null, durationMs: Math.round(performance.now() - startedAt), error: "The app did not return an HTTP response." };
      }
    },
  }));

  registry.register(defineTool({
    name: "list_apps",
    riskLevel: "green",
    inputSchema: z.object({}).strict(),
    describe: () => ({ action: "فهرست اپ‌ها را می‌خوانم", consequence: "فقط اطلاعات پروژه‌های حساب خوانده می‌شود.", recommendation: "برای ادامه، اپ موردنظر را انتخاب کن.", alternatives: ["فقط توضیح بده"], reversible: false }),
    withinEnvelope: () => true,
    run: async () => (await client.listApps()).data,
  }));

  registry.register(defineTool({
    name: "read_logs",
    riskLevel: "green",
    inputSchema: appInput,
    describe: ({ projectId }) => ({ action: `لاگ‌های ${projectId} را می‌خوانم`, consequence: "فقط‌خواندنی؛ تغییری در اپ نمی‌دهد.", recommendation: "برای بررسی خطاها ادامه بده.", alternatives: ["وضعیت اپ را بخوان"], reversible: false }),
    withinEnvelope: ({ projectId }, envelope) => projectInsideEnvelope(projectId, envelope),
    run: async ({ projectId }) => (await client.getLogs(projectId)).data,
  }));

  registry.register(defineTool({
    name: "read_metrics",
    riskLevel: "green",
    inputSchema: appInput,
    describe: ({ projectId }) => ({ action: `متریک‌های ${projectId} را می‌خوانم`, consequence: "فقط‌خواندنی؛ تغییری در اپ نمی‌دهد.", recommendation: "برای دیدن مصرف منابع ادامه بده.", alternatives: ["لاگ‌ها را بخوان"], reversible: false }),
    withinEnvelope: ({ projectId }, envelope) => projectInsideEnvelope(projectId, envelope),
    run: async ({ projectId }) => (await client.getMetrics(projectId)).data,
  }));

  registry.register(defineTool({
    name: "restart_app",
    riskLevel: "green",
    inputSchema: appNameInput,
    describe: ({ appName }) => ({ action: `اپ ${appName} را restart می‌کنم`, consequence: "ممکن است چند ثانیه اختلال ایجاد شود؛ عملیات قابل تکرار است.", recommendation: "اگر اپ پاسخ نمی‌دهد، یک بار restart کن.", alternatives: ["اول لاگ‌ها را بررسی کن"], reversible: false }),
    withinEnvelope: ({ projectId, appName }, envelope) => projectInsideEnvelope(projectId, envelope) && envelope.appNames.includes(appName),
    run: async ({ appName }) => (await client.restartApp(appName)).status,
  }));

  registry.register(defineTool({
    name: "create_app",
    riskLevel: "green",
    inputSchema: z.object({ projectId: z.string().min(1).max(120), appName: z.string().min(1).max(63), planID: z.string().min(1), bundlePlanID: z.string().min(1), platform: z.enum(["node", "next", "django", "flask", "python", "docker", "static", "react", "go", "php", "laravel", "dotnet", "vue", "angular"]), monthlyCost: z.number().nonnegative() }).strict(),
    describe: ({ appName, monthlyCost }) => ({ action: `اپ ${appName} را می‌سازم`, consequence: "اپ طبق پلن تأییدشده ساخته می‌شود و ممکن است هزینه‌ی ماهانه داشته باشد.", recommendation: "ساخت را در چارچوب هزینه‌ی تأییدشده ادامه بده.", alternatives: ["ساخت را لغو کن"], reversible: false, monthlyCost }),
    withinEnvelope: (input, envelope) => projectInsideEnvelope(input.projectId, envelope) && resourceInsideEnvelope(envelope, "app", input.appName, input.planID, input.monthlyCost, input.bundlePlanID),
    run: async ({ appName, planID, bundlePlanID, platform }) => {
      const existing = await client.listApps();
      const projects = Array.isArray(existing.data?.projects) ? existing.data.projects as Array<Record<string, unknown>> : [];
      const alreadyExists = projects.some((project) => [project.project_id, project.projectId, project.name].some((id) => typeof id === "string" && id.toLowerCase() === appName.toLowerCase()));
      if (alreadyExists) return { appName, created: false, reused: true };
      await client.createApp({ name: appName, planID, bundlePlanID, platform });
      return { appName, created: true, reused: false };
    },
  }));

  registry.register(defineTool({
    name: "upload_source",
    riskLevel: "green",
    inputSchema: z.object({ projectId: z.string().min(1).max(120), appName: z.string().min(1).max(63), sourceDigest: z.string().regex(/^[a-f0-9]{64}$/u), sourceBytes: z.number().int().positive().max(256 * 1024 * 1024) }).strict(),
    describe: ({ appName }) => ({ action: `سورس پروژه را برای ${appName} بارگذاری می‌کنم`, consequence: "فایل‌های پروژه برای ساخت release به Liara فرستاده می‌شوند؛ فایل .env از بسته حذف شده است.", recommendation: "سورس بررسی‌شده را بارگذاری کن.", alternatives: ["بارگذاری را لغو کن"], reversible: false }),
    withinEnvelope: ({ projectId, appName }, envelope) => projectInsideEnvelope(projectId, envelope) && envelope.appNames.includes(appName),
    run: async ({ appName }) => {
      if (!sourceArchive) throw new LiaraError("SOURCE_UNAVAILABLE", "The prepared project archive is unavailable. Upload the source again.", false);
      const result = await client.uploadSource(appName, sourceArchive, "source.tar.gz");
      if (!result.data?.sourceID) throw new LiaraError("SOURCE_ID_MISSING", "Liara accepted the source but did not return a source ID.", false, result.status);
      return { sourceID: result.data.sourceID };
    },
  }));

  registry.register(defineTool({
    name: "deploy_release",
    riskLevel: "green",
    inputSchema: z.object({ projectId: z.string().min(1).max(120), appName: z.string().min(1).max(63), sourceID: z.string().min(1), platform: z.enum(["node", "next", "django", "flask", "python", "docker", "static", "react", "go", "php", "laravel", "dotnet", "vue", "angular"]), port: z.number().int().min(1).max(65535) }).strict(),
    describe: ({ appName }) => ({ action: `release جدید ${appName} را اجرا می‌کنم`, consequence: "سورس build و اجرا می‌شود؛ آنلاین‌شدن فقط بعد از health check واقعی اعلام خواهد شد.", recommendation: "release را اجرا و سلامت HTTP را بررسی کن.", alternatives: ["release را لغو کن"], reversible: false }),
    withinEnvelope: ({ projectId, appName }, envelope) => projectInsideEnvelope(projectId, envelope) && envelope.appNames.includes(appName),
    run: async ({ appName, sourceID, platform, port }) => {
      const result = await client.deployRelease(appName, { sourceID, port, type: platform });
      if (!result.data?.releaseID) throw new LiaraError("RELEASE_ID_MISSING", "Liara did not return a release ID.", false, result.status);
      return { releaseID: result.data.releaseID };
    },
  }));

  registry.register(defineTool({
    name: "redeploy",
    riskLevel: "green",
    inputSchema: z.object({ projectId: z.string().min(1).max(120), appName: z.string().min(1).max(63), sourceID: z.string().min(1), platform: z.enum(["node", "next", "django", "flask", "python", "docker", "static", "react", "go", "php", "laravel", "dotnet", "vue", "angular"]), port: z.number().int().min(1).max(65535) }).strict(),
    describe: ({ appName }) => ({ action: `سورس release تأییدشده‌ی ${appName} را redeploy می‌کنم`, consequence: "از همان سورس یک release تازه ساخته می‌شود؛ فقط پس از بررسی وضعیت و health check موفق گزارش می‌شود.", recommendation: "بعد از اصلاح env یا کد، release را اجرا و نتیجه را verify کن.", alternatives: ["فقط اپ را restart کن"], reversible: true }),
    withinEnvelope: ({ projectId, appName }, envelope) => projectInsideEnvelope(projectId, envelope) && envelope.appNames.includes(appName),
    run: async ({ appName, sourceID, platform, port }) => client.deployRelease(appName, { sourceID, type: platform, port }),
  }));

  registry.register(defineTool({
    name: "set_env",
    riskLevel: "green",
    inputSchema: z.object({ projectId: z.string().min(1), appName: z.string().min(1).max(63), variables: z.array(z.object({ key: z.string().min(1), value: z.string() }).strict()).min(1) }).strict(),
    describe: ({ appName, variables }) => ({ action: `${variables.length} متغیر env را برای ${appName} ست می‌کنم`, consequence: "مقدارها مستقیم به Liara فرستاده می‌شوند؛ ممکن است اپ restart شود.", recommendation: "فقط کلیدهای لازم را ست کن.", alternatives: ["لغو و ورود دستی"], reversible: false }),
    withinEnvelope: ({ projectId, appName, variables }, envelope) => projectInsideEnvelope(projectId, envelope) && envelope.appNames.includes(appName) && variables.every(({ key }) => envelope.approvedEnvKeys.includes(key)),
    run: async ({ projectId, appName, variables }) => {
      await client.updateEnv(appName, variables);
      return { projectId, appName, updatedKeys: variables.map(({ key }) => key), count: variables.length };
    },
  }));

  registry.register(defineTool({
    name: "delete_app",
    riskLevel: "red",
    inputSchema: z.object({ appName: z.string().min(1).max(63) }).strict(),
    describe: ({ appName }) => ({ action: `اپ ${appName} را حذف می‌کنم`, consequence: "سرویس و داده‌های وابسته ممکن است از دست بروند و بازگردانی تضمین‌شده نیست.", recommendation: "قبل از حذف از داده‌ها نسخه‌ی پشتیبان بگیر.", alternatives: ["اپ را متوقف کن"], reversible: false }),
    withinEnvelope: () => false,
    run: async ({ appName }) => (await client.deleteApp(appName)).status,
  }));

  registry.register(defineTool({
    name: "change_plan",
    riskLevel: "red",
    inputSchema: z.object({ projectId: z.string().min(1).max(120), planID: z.string().min(1), monthlyCost: z.number().nonnegative() }).strict(),
    describe: ({ projectId, planID, monthlyCost }) => ({ action: `پلن ${projectId} را به ${planID} تغییر می‌دهم`, consequence: "ممکن است منابع و هزینه‌ی جاری تغییر کند؛ Liara قیمت فعلی را برای این پلن گزارش کرده است.", recommendation: "قبل از اجرا، پلن و هزینه‌ی ماهانه‌ی API را بررسی کن.", alternatives: ["پلن فعلی را نگه دار"], reversible: false, monthlyCost }),
    withinEnvelope: () => false,
    run: async ({ projectId, planID }) => (await client.changePlan(projectId, planID)).status,
  }));

  registry.register(defineTool({
    name: "rollback_release",
    riskLevel: "red",
    inputSchema: z.object({ projectId: z.string().min(1).max(120), appName: z.string().min(1).max(63), releaseID: z.string().min(1).max(120), sourceID: z.string().min(1).max(200), platform: z.enum(["node", "next", "django", "flask", "python", "docker", "static", "react", "go", "php", "laravel", "dotnet", "vue", "angular"]), port: z.number().int().min(1).max(65535) }).strict(),
    describe: ({ appName, releaseID }) => ({ action: `سورس release ${releaseID} را دوباره روی ${appName} اجرا می‌کنم`, consequence: "این کار release تازه‌ای از سورس قدیمی می‌سازد؛ داده‌های پایگاه‌داده به عقب برنمی‌گردند و ممکن است اختلال ایجاد شود.", recommendation: "فقط اگر release قبلی در تاریخچه موجود و سورسش قابل استفاده است اجرا کن.", alternatives: ["نسخه‌ی فعلی را نگه دار و عیب‌یابی را ادامه بده"], reversible: false }),
    withinEnvelope: () => false,
    run: async ({ appName, sourceID, platform, port }) => client.deployRelease(appName, { sourceID, type: platform, port }),
  }));

  registry.register(createReadEnvTool());

  return registry;
}

function maskEnvValue(value: string) {
  if (!value) return "";
  return value.length <= 4 ? "••••" : `••••••${value.slice(-4)}`;
}
