import { afterAll, beforeAll, describe, expect, it } from "vitest";
import Database from "better-sqlite3";
import { z } from "zod";
import { analyzeEvidence, verifyFix } from "./analyze";
import { collectDiagnosis } from "./collect";
import type { DiagnosisEvidence } from "./types";
import { createAuditStore, installAuditStoreForTests } from "../audit/sqlite";
import { ToolRegistry } from "../tools/registry";
import { defineTool } from "../tools/types";

process.env.APPROVAL_SIGNING_SECRET = "phase-three-test-key-0123456789abcdef0123456789abcdef";

const db = new Database(":memory:");
beforeAll(() => installAuditStoreForTests(createAuditStore(db)));
afterAll(() => { installAuditStoreForTests(undefined); db.close(); });

const FAKE_TOKEN = "lra_live_FAKE0123456789abcdefSECRET";

function evidence(overrides: Partial<DiagnosisEvidence> = {}): DiagnosisEvidence {
  return { appName: "test-app", status: { status: "running", currentRelease: "rel-2" }, logs: [], metrics: null, releases: [], probe: { status: 200, durationMs: 40 }, limitations: [], observedAt: new Date().toISOString(), ...overrides };
}

/** Read-only evidence tools backed by fixed responses, mirroring the Liara tool names used by collectDiagnosis. */
function evidenceRegistry(responses: Record<string, unknown>) {
  const registry = new ToolRegistry();
  for (const name of ["get_app_status", "get_logs", "get_metrics", "get_release_history", "http_probe"]) {
    registry.register(defineTool({
      name, riskLevel: "green", requiresEnvelope: false,
      inputSchema: z.object({ projectId: z.string(), appName: z.string() }).strict(),
      describe: () => ({ action: `Read ${name}`, consequence: "Read-only.", recommendation: "Proceed.", alternatives: [], reversible: true }),
      withinEnvelope: () => true,
      run: async () => {
        const value = responses[name];
        if (value instanceof Error) throw value;
        return value;
      },
    }));
  }
  return registry;
}

describe("F03 Validation V4–V6", () => {
  it("V4: an ineffective fix fails verification and the finding offers a rollback to a READY release", () => {
    const releases = [
      { _id: "rel-2", tag: "v2", state: "READY", sourceAvailable: true, sourceID: "src-2" },
      { _id: "rel-1", tag: "v1", state: "READY", sourceAvailable: true, sourceID: "src-1" },
    ];
    const before = evidence({ probe: { status: 500, durationMs: 30 }, metrics: { errorCount: 12 }, releases, logs: ["TypeError: Cannot read properties of undefined\n    at handler (/app/server.js:42:7)"] });
    const after = evidence({ probe: { status: 500, durationMs: 32 }, metrics: { errorCount: 14 }, releases });

    const verification = verifyFix(before, after);
    expect(verification).toMatchObject({ verified: false, rollbackSuggested: true, http: { before: 500, after: 500 } });

    const rollback = analyzeEvidence(after).finding.actions.find((action) => action.id === "rollback");
    expect(rollback).toMatchObject({ riskLevel: "red", releaseID: "rel-1" });
  });

  it("V5: with metrics switched off the evidence says so and contains no invented CPU/RAM values", async () => {
    const registry = evidenceRegistry({
      get_app_status: { project: { status: "running", type: "node", port: 3000 } },
      get_logs: { data: [] },
      get_metrics: new Error("Metrics API disabled in this mock."),
      get_release_history: { releases: [] },
      http_probe: { status: 200, durationMs: 50 },
    });
    const collected = await collectDiagnosis("test-app", registry);
    expect(collected.metrics).toBeNull();
    expect(collected.limitations.map((item) => item.title)).toContain("Get metrics unavailable");
    expect(collected.limitations.map((item) => item.title)).toContain("Resource metrics unavailable");

    const result = analyzeEvidence(collected);
    expect(result.finding.evidence.join(" ")).not.toMatch(/cpu|memory|ram|rss/iu);
    expect(result.finding.causes.map((cause) => cause.id)).not.toContain("cpu_pressure");
  });

  it("V6: a fake token in Liara logs never reaches the model-bound evidence or finding", async () => {
    const registry = evidenceRegistry({
      get_app_status: { project: { status: "running", type: "node", port: 3000 } },
      get_logs: { data: [{ values: [
        ["1", `Authorization: Bearer ${FAKE_TOKEN}`],
        ["2", `Error: upstream rejected token=${FAKE_TOKEN}`],
        ["3", `connecting with api_key: ${FAKE_TOKEN} failed`],
      ] }] },
      get_metrics: { memory: { rssBytes: 1024 } },
      get_release_history: { releases: [{ _id: "rel-1", state: "FAILED", failReason: `token=${FAKE_TOKEN}` }] },
      http_probe: { status: 500, durationMs: 20 },
    });
    const collected = await collectDiagnosis("test-app", registry);
    const result = analyzeEvidence(collected);
    const modelPayload = JSON.stringify({ evidence: result.evidence, finding: result.finding });
    expect(collected.logs.length).toBe(3);
    expect(modelPayload).not.toContain(FAKE_TOKEN);
    expect(JSON.stringify(collected)).not.toContain(FAKE_TOKEN);
    expect(JSON.stringify(db.prepare("SELECT * FROM audit_entries").all())).not.toContain(FAKE_TOKEN);
  });
});
