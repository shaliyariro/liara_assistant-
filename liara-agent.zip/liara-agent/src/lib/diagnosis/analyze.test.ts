import { describe, expect, it } from "vitest";
import { analyzeEvidence, redactDiagnosticLog, verifyFix } from "./analyze";
import type { DiagnosisEvidence } from "./types";

function evidence(overrides: Partial<DiagnosisEvidence> = {}): DiagnosisEvidence {
  return { appName: "test-app", status: { status: "running" }, logs: [], metrics: null, releases: [], probe: { status: 200, durationMs: 40 }, limitations: [], observedAt: new Date().toISOString(), ...overrides };
}

describe("F03 evidence diagnosis", () => {
  it("redacts credentials before evidence can be sent to a model", () => {
    const line = "Authorization: Bearer abc123 password=hunter2 DATABASE_URL=postgres://user:pw@db/app token=xyz";
    const safe = redactDiagnosticLog(line);
    expect(safe).not.toContain("abc123");
    expect(safe).not.toContain("hunter2");
    expect(safe).not.toContain("user:pw");
    expect(safe).not.toContain("xyz");
  });

  it("detects missing DATABASE_URL with only the observed key and recommends set_env", () => {
    const result = analyzeEvidence(evidence({ logs: ["Startup failed: DATABASE_URL is required. Set it or use demo mode."] }));
    expect(result.finding.causes[0]).toMatchObject({ id: "incomplete_env", confidence: 98 });
    expect(result.finding.actions[0]).toMatchObject({ id: "set_env", envKey: "DATABASE_URL", riskLevel: "green" });
  });

  it("does not create CPU or memory values when the API supplies no metrics", () => {
    const result = analyzeEvidence(evidence({ probe: { status: 500, durationMs: 40 } }));
    expect(result.evidence.metrics).toBeNull();
    expect(result.finding.evidence.join(" ")).not.toMatch(/CPU\s*[:=]|RAM\s*[:=]|rssBytes\s*[:=]/iu);
  });

  it("verifies a fix only when HTTP and a same-named measured metric are both comparable", () => {
    expect(verifyFix(evidence({ probe: { status: 503, durationMs: 20 }, metrics: { errorCount: 3 } }), evidence({ probe: { status: 200, durationMs: 15 }, metrics: { errorCount: 0 } }))).toMatchObject({ verified: true, http: { before: 503, after: 200 }, metric: { name: "errorCount", before: 3, after: 0 } });
    expect(verifyFix(evidence({ probe: { status: 503, durationMs: 20 }, metrics: null }), evidence({ probe: { status: 200, durationMs: 15 }, metrics: null }))).toMatchObject({ verified: false, rollbackSuggested: true });
  });

  it("selects an improved comparable metric when another resource counter increases", () => {
    const result = verifyFix(
      evidence({ probe: { status: 200, durationMs: 2_500 }, metrics: { rssBytes: 100, slowResponseMs: 2_500 } }),
      evidence({ probe: { status: 200, durationMs: 5 }, metrics: { rssBytes: 110, slowResponseMs: 0 } }),
    );
    expect(result).toMatchObject({ verified: true, metric: { name: "slowResponseMs", before: 2_500, after: 0 } });
  });
});
