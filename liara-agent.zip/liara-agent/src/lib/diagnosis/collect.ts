import type { ToolRegistry } from "@/lib/tools/registry";
import type { ToolExecutionContext } from "@/lib/tools/types";
import { redactDiagnosticLog } from "./analyze";
import type { DiagnosisEvidence, DiagnosisMetrics } from "./types";

const limitation = (title: string, detail: string, manualStep: string) => ({ title, detail, manualStep });

export async function collectDiagnosis(appName: string, registry: ToolRegistry): Promise<DiagnosisEvidence> {
  const input = { projectId: appName, appName };
  const context: ToolExecutionContext = { actor: "agent" };
  const names = ["get_app_status", "get_logs", "get_metrics", "get_release_history", "http_probe"] as const;
  const settled = await Promise.allSettled(names.map((name) => registry.execute(name, input, context)));
  const values = new Map<string, unknown>();
  const limitations: DiagnosisEvidence["limitations"] = [];
  for (let index = 0; index < settled.length; index++) {
    const result = settled[index];
    const name = names[index];
    if (result.status === "fulfilled") values.set(name, result.value);
    else limitations.push(limitation(
      `${label(name)} unavailable`,
      errorMessage(result.reason),
      `Check the Liara app name and permissions, then retry ${name.replaceAll("_", " ")}.`,
    ));
  }

  const rawStatus = unwrap(values.get("get_app_status"));
  const status = pickStringFields(rawStatus, ["status", "type", "port", "planID", "bundlePlanID", "scale", "currentRelease", "updatedAt"]);
  const logs = extractLogs(values.get("get_logs")).map(redactDiagnosticLog);
  const metrics = extractMetrics(values.get("get_metrics"));
  const releases = extractReleases(values.get("get_release_history"));
  const probeData = unwrap(values.get("http_probe"));
  const probe = probeData && typeof probeData === "object" ? {
    status: typeof (probeData as Record<string, unknown>).status === "number" ? (probeData as Record<string, number>).status : null,
    durationMs: typeof (probeData as Record<string, unknown>).durationMs === "number" ? (probeData as Record<string, number>).durationMs : null,
    ...(typeof (probeData as Record<string, unknown>).url === "string" ? { url: String((probeData as Record<string, unknown>).url) } : {}),
  } : null;

  if (!metrics) limitations.push(limitation("Resource metrics unavailable", "Liara did not return a usable CPU, memory, or error metric for this app. The diagnosis will not estimate or invent one.", "Check resource charts in the Liara panel and retry when metrics are available."));
  if (!status) limitations.push(limitation("App status unavailable", "The project details API returned no status fields that could be safely displayed.", "Check the app name and current status in the Liara Console."));
  if (!logs.length) limitations.push(limitation("App logs unavailable", "No log lines were returned by the app log API for the current window.", "Open the Liara logs panel or widen the log time range."));
  if (!releases) limitations.push(limitation("Release history unavailable", "Liara did not return release history for this app.", "Check the Releases panel in Liara."));
  if (probe?.status === null || !probe) limitations.push(limitation("HTTP probe unavailable", "The app did not return an HTTP response that could be measured.", "Check the app's public domain and try the probe again."));

  return { appName, status, logs, metrics, releases, probe, limitations, observedAt: new Date().toISOString() };
}

function label(name: string) { return name.replaceAll("_", " ").replace(/^./u, (letter) => letter.toUpperCase()); }
function errorMessage(error: unknown) { return error instanceof Error ? error.message.slice(0, 250) : "The evidence API request failed."; }
function unwrap(value: unknown): unknown {
  if (!value || typeof value !== "object" || Array.isArray(value)) return value;
  const record = value as Record<string, unknown>;
  if ("project" in record && record.project && typeof record.project === "object") return record.project;
  return value;
}

function pickStringFields(value: unknown, allowed: string[]) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const input = value as Record<string, unknown>;
  const output: Record<string, unknown> = {};
  for (const key of allowed) {
    const item = input[key];
    if (typeof item === "string" || typeof item === "number" || typeof item === "boolean") output[key] = item;
  }
  return Object.keys(output).length ? output : null;
}

function extractLogs(value: unknown): string[] {
  const data = unwrap(value);
  if (typeof data === "string") return data.split(/\r?\n/u).filter(Boolean).slice(-100);
  if (!data || typeof data !== "object") return [];
  const root = data as Record<string, unknown>;
  const groups = Array.isArray(root.data) ? root.data : Array.isArray(root.logs) ? root.logs : [];
  const lines: string[] = [];
  for (const group of groups) {
    if (Array.isArray(group)) { lines.push(...group.map(String)); continue; }
    if (!group || typeof group !== "object") continue;
    const record = group as Record<string, unknown>;
    if (Array.isArray(record.values)) {
      for (const pair of record.values) {
        if (Array.isArray(pair) && typeof pair[1] === "string") {
          let message = pair[1];
          try { const parsed = JSON.parse(message) as Record<string, unknown>; message = String(parsed._entry ?? parsed.message ?? message); } catch { /* Liara may return plain text. */ }
          lines.push(message);
        } else if (typeof pair === "string") lines.push(pair);
      }
    } else if (typeof record.line === "string") lines.push(record.line);
  }
  return lines.slice(-100);
}

function extractMetrics(value: unknown): DiagnosisMetrics | null {
  const data = unwrap(value);
  if (!data || typeof data !== "object" || Array.isArray(data)) return null;
  const result: DiagnosisMetrics = {};
  const visit = (current: unknown, prefix: string, depth: number) => {
    if (!current || typeof current !== "object" || Array.isArray(current) || depth > 4) return;
    for (const [key, child] of Object.entries(current as Record<string, unknown>)) {
      const name = prefix ? `${prefix}.${key}` : key;
      if (typeof child === "number" && Number.isFinite(child) && /cpu|memory|mem|ram|rss|error|restart|latency|duration|response|leak/iu.test(name)) result[name] = child;
      else visit(child, name, depth + 1);
    }
  };
  visit(data, "", 0);
  return Object.keys(result).length ? result : null;
}

function extractReleases(value: unknown): Array<Record<string, unknown>> | null {
  const data = unwrap(value);
  if (!data || typeof data !== "object") return null;
  const record = data as Record<string, unknown>;
  const releases = Array.isArray(record.releases) ? record.releases : Array.isArray(record.data) ? record.data : null;
  if (!releases) return null;
  return releases.slice(0, 20).flatMap((release) => {
    if (!release || typeof release !== "object") return [];
    const item = release as Record<string, unknown>;
    const safe: Record<string, unknown> = {};
    for (const key of ["_id", "id", "tag", "state", "createdAt", "finishedAt", "sourceAvailable", "sourceID", "port", "type", "failReason"]) {
      const value = item[key];
      if (["string", "number", "boolean"].includes(typeof value)) safe[key] = typeof value === "string" ? redactDiagnosticLog(value) : value;
    }
    return [safe];
  });
}

export function formatDiagnosisLimitation(name: string, detail: string) {
  return limitation(`${label(name)} unavailable`, detail, "Use the corresponding Liara Console page and retry the diagnosis.");
}
