import type { DiagnosisEvidence, DiagnosisResult, Finding, DiagnosisAction } from "./types";

const patterns = {
  oom: /(?:\boom\b|out of memory|heap out of memory|heap space|memoryerror|killed process)/iu,
  crash: /(?:crash(?:ed)? loop|restart(?:ed|ing)? (?:too often|repeatedly)|exit code\s*[1-9]|exited with code\s*[1-9])/iu,
  env: /(?:DATABASE_URL.{0,80}(?:required|missing|undefined)|(?:missing|required) (?:environment )?variable|KeyError:\s*['"][A-Z0-9_]+|process\.env\.[A-Z0-9_]+.{0,40}undefined)/iu,
  database: /(?:ECONNREFUSED|ETIMEDOUT|too many connections|database.{0,40}(?:timeout|refused|unavailable)|connection.{0,30}refused|connection pool)/iu,
  build: /(?:npm ERR!|npm error|pip install.{0,50}error|build failed|failed to build|docker build failed|ModuleNotFoundError|Cannot find module)/iu,
  stack: /(?:\bat\s+\S+\s*\([^)]*:\d+:\d+\)|\b(?:TypeError|ReferenceError|SyntaxError|UnhandledPromiseRejection)\b)/u,
};

export function redactDiagnosticLog(value: string): string {
  return value
    .replace(/\b(Bearer\s+)[A-Za-z0-9._~+/=-]+/giu, "$1[REDACTED]")
    .replace(/((?:password|passwd|secret|token|api[-_]?key|private[-_]?key|database[-_]?url|connection[-_]?string)\s*[=:]\s*)(?:"[^"]*"|'[^']*'|[^\s,;]+)/giu, "$1[REDACTED]")
    .replace(/([?&](?:token|api_key|password|secret)=)[^&\s]+/giu, "$1[REDACTED]")
    .replace(/(-----BEGIN [A-Z ]*PRIVATE KEY-----)[\s\S]*?(-----END [A-Z ]*PRIVATE KEY-----)/gu, "$1[REDACTED]$2")
    .slice(0, 2_000);
}

function metric(metrics: DiagnosisEvidence["metrics"], names: string[]) {
  if (!metrics) return undefined;
  const entry = Object.entries(metrics).find(([name, value]) => names.some((candidate) => name.toLowerCase().includes(candidate)) && Number.isFinite(value));
  return entry ? { key: entry[0], value: entry[1] } : undefined;
}

function actions(...items: DiagnosisAction[]): DiagnosisAction[] { return items; }

const restartAction: DiagnosisAction = { id: "restart", title: "Restart the app", riskLevel: "green", rationale: "Recheck service health after a transient crash or stuck process.", cost: "No plan change; check Liara billing for usage charges.", downtime: "May briefly interrupt requests.", reversible: true };
const upgradeAction: DiagnosisAction = { id: "change_plan", title: "Increase the app plan", riskLevel: "red", rationale: "More memory or CPU may reduce resource pressure.", cost: "Monthly price must be quoted from Liara before approval.", downtime: "May restart the app during resize.", reversible: true };
const rollbackAction: DiagnosisAction = { id: "rollback", title: "Roll back to a previous release", riskLevel: "red", rationale: "A previous release may restore service if the current release caused the failure.", cost: "No plan-price change; data compatibility must be checked.", downtime: "May interrupt requests.", reversible: false };
const envAction: DiagnosisAction = { id: "set_env", title: "Set the missing environment value", riskLevel: "green", rationale: "Supply the named key from a trusted source, then restart or redeploy.", cost: "No plan change.", downtime: "The app may restart after the environment is updated.", reversible: true };
const redeployAction: DiagnosisAction = { id: "redeploy", title: "Redeploy the corrected source", riskLevel: "green", rationale: "Build and start a corrected release after the source or environment is fixed.", cost: "No plan change; build usage may be billed separately.", downtime: "Depends on the platform's release strategy.", reversible: true };
const issueAction: DiagnosisAction = { id: "issue", title: "Prepare a coding-agent issue", riskLevel: "green", rationale: "The evidence points to an application-code or build problem.", cost: "No infrastructure change.", downtime: "None.", reversible: true };

export function analyzeEvidence(evidence: DiagnosisEvidence, startedAt = Date.now()): DiagnosisResult {
  const logs = evidence.logs.map(redactDiagnosticLog);
  const allLogs = logs.join("\n");
  const rss = metric(evidence.metrics, ["rssbytes", "residentmemorybytes", "memoryrssbytes", "memoryrss"]);
  const leaked = metric(evidence.metrics, ["leakedmegabytes", "leakedchunks"]);
  const restarts = metric(evidence.metrics, ["restartcount", "restarts"]);
  const cpu = metric(evidence.metrics, ["cpupercent", "cpu_pct", "cpuusagepercent"]);
  const latency = evidence.probe?.durationMs;
  const causes = new Map<string, { title: string; score: number; explanation: string }>();
  const add = (id: string, title: string, score: number, explanation: string) => causes.set(id, { title, score, explanation });

  if (patterns.oom.test(allLogs)) add("oom", "Memory pressure / OOM", 0.98, "Logs contain an explicit out-of-memory or process-killed signal.");
  else if (leaked && leaked.value > 0) add("oom", "Memory growth; possible OOM", 0.91, `The reported ${leaked.key} value is ${leaked.value}; the demo or runtime reports retained memory.`);
  else if (rss && evidence.metrics && evidence.metrics[rss.key] > 0 && /memory/i.test(rss.key)) add("oom", "Elevated memory use", 0.62, `Liara reported ${rss.key}=${rss.value}. No memory limit was available to calculate headroom.`);

  if (patterns.crash.test(allLogs) || (restarts && restarts.value >= 3)) add("crash_loop", "Repeated process crashes", restarts ? 0.88 : 0.90, restarts ? `The runtime reported ${restarts.value} restarts.` : "Logs contain a repeated-crash or non-zero-exit signal.");
  const envMatch = allLogs.match(/(?:DATABASE_URL|[A-Z][A-Z0-9_]{2,})\s*(?:is\s+)?(?:required|missing|undefined)|missing (?:environment )?variable\s+([A-Z][A-Z0-9_]+)/iu);
  const missingEnvKey = envMatch?.[1] ?? envMatch?.[0]?.match(/[A-Z][A-Z0-9_]{2,}/u)?.[0];
  if (patterns.env.test(allLogs)) add("incomplete_env", "Required environment value is missing", 0.98, `Startup evidence names ${missingEnvKey ?? "a required variable"}.`);
  if (patterns.database.test(allLogs)) add("database_connection", "Database connection failed", 0.94, "Logs contain a database timeout, refusal, or connection-pool error.");
  if (evidence.probe?.status !== null && evidence.probe?.status !== undefined && evidence.probe.status >= 500 || patterns.stack.test(allLogs)) add("application_500", "Application returned an error", evidence.probe?.status && evidence.probe.status >= 500 ? 0.98 : 0.87, evidence.probe?.status && evidence.probe.status >= 500 ? `The HTTP probe returned ${evidence.probe.status}.` : "Logs include an application stack trace.");
  const failedRelease = evidence.releases?.find((release) => String(release.state ?? "").toUpperCase() === "FAILED" || String(release.state ?? "").toUpperCase() === "UNHEALTHY");
  const currentReleaseID = String(evidence.status?.currentRelease ?? "");
  const priorReadyRelease = evidence.releases?.find((release) => {
    const releaseID = String(release._id ?? release.id ?? "");
    return releaseID && releaseID !== currentReleaseID && String(release.state ?? "").toUpperCase() === "READY" && release.sourceAvailable === true && typeof release.sourceID === "string";
  });
  const proposedRollback = priorReadyRelease ? { ...rollbackAction, releaseID: String(priorReadyRelease._id ?? priorReadyRelease.id) } : rollbackAction;
  if (failedRelease || patterns.build.test(allLogs)) add("build_failure", "The latest build failed", failedRelease ? 0.96 : 0.90, failedRelease ? `Release ${String(failedRelease.tag ?? failedRelease._id ?? "(id unavailable)")} reported ${String(failedRelease.state)}.` : "Build logs contain a dependency or build error.");
  if (cpu && cpu.value >= 80) add("cpu_pressure", "High CPU use", 0.82, `Liara reported ${cpu.key}=${cpu.value}.`);
  if (latency !== null && latency !== undefined && latency >= 2_000) add("slow_response", "Slow HTTP response", Math.min(0.95, 0.65 + latency / 20_000), `The HTTP probe took ${latency} ms.`);

  const ranked = [...causes.entries()].map(([id, cause]) => ({ id, title: cause.title, confidence: Math.round(cause.score * 100), explanation: cause.explanation })).sort((a, b) => b.confidence - a.confidence);
  const top = ranked[0];
  const severity: Finding["severity"] = top?.id === "oom" || top?.id === "crash_loop" ? "critical" : top ? "important" : "warning";
  let summary = top ? summaryFor(top.id, top.title) : "Available evidence does not identify a specific failure. Collect application logs and a fresh health probe.";
  let suggested = actions(issueAction);
  if (top?.id === "oom") {
    const explicitOom = patterns.oom.test(allLogs);
    suggested = explicitOom ? actions(upgradeAction, restartAction, issueAction) : actions(restartAction, issueAction);
    summary = "Memory use is growing or the process reported an out-of-memory failure.";
  }
  else if (top?.id === "crash_loop") { suggested = actions(restartAction, proposedRollback, issueAction); summary = "The app is restarting repeatedly and may not stay available."; }
  else if (top?.id === "incomplete_env") { suggested = actions({ ...envAction, ...(missingEnvKey ? { envKey: missingEnvKey } : {}) }, redeployAction); summary = "The app cannot start because a required environment value is missing."; }
  else if (top?.id === "database_connection") { suggested = actions(envAction, restartAction, issueAction); summary = "The app cannot establish a database connection."; }
  else if (top?.id === "application_500") { suggested = actions(issueAction, proposedRollback, restartAction); summary = "The app returned an HTTP error; the logs include the likely code path."; }
  else if (top?.id === "build_failure") { suggested = actions(issueAction, proposedRollback); summary = "The latest release failed during build or startup."; }
  else if (top?.id === "cpu_pressure" || top?.id === "slow_response") { suggested = actions(restartAction, issueAction); summary = "The app is responding slowly or the available CPU evidence is high."; }

  const evidenceLines = [
    ...(evidence.probe?.status !== null && evidence.probe?.status !== undefined ? [`HTTP ${evidence.probe.status}${latency !== null && latency !== undefined ? ` in ${latency} ms` : ""}${evidence.probe.url ? ` · ${evidence.probe.url}` : ""}`] : []),
    ...(evidence.metrics ? Object.entries(evidence.metrics).map(([key, value]) => `${key}: ${value}`) : []),
    ...logs.filter((line) => /error|exception|failed|killed|oom|timeout|refused|missing|required|traceback/iu.test(line)).slice(-4),
    ...(evidence.status ? [`App status: ${JSON.stringify(evidence.status).slice(0, 300)}`] : []),
  ].slice(0, 10);
  const finding: Finding = {
    id: `${evidence.appName}:${top?.id ?? "insufficient-evidence"}`,
    severity,
    summary,
    causes: ranked.slice(0, 5),
    evidence: evidenceLines,
    actions: suggested,
    ...(top && ["application_500", "build_failure"].includes(top.id) ? { issuePrompt: makeIssuePrompt(evidence.appName, top.title, top.explanation, logs) } : {}),
  };
  const safeEvidence = { ...evidence, logs };
  return { appName: evidence.appName, finding, evidence: safeEvidence, elapsedMs: Math.max(0, Date.now() - startedAt), confidenceMethod: "evidence-rule heuristic" };
}

function summaryFor(_id: string, title: string) { return `${title}: evidence is incomplete; use the expandable details to review the observed signals.`; }

function makeIssuePrompt(appName: string, cause: string, explanation: string, logs: string[]) {
  const relevant = logs.filter((line) => patterns.stack.test(line) || /error|exception|traceback|failed/iu.test(line)).slice(-5);
  return {
    title: `[${appName}] Investigate ${cause}`,
    body: [
      `## Observed evidence\n${relevant.length ? relevant.map((line) => `- ${line}`).join("\n") : "- No stack trace was available from the current evidence."}`,
      `## Hypothesis\n${explanation}`,
      "## Reproduction\n1. Open the affected endpoint or reproduce the failed release.\n2. Compare the response with the timestamped evidence above.",
      "## Request\nIdentify the responsible file and line, add a regression test, and propose a minimal fix. Do not include secrets in the patch.",
    ].join("\n\n"),
  };
}

export function verifyFix(before: DiagnosisEvidence, after: DiagnosisEvidence) {
  const metricKeys = Object.keys(before.metrics ?? {}).filter((key) => typeof after.metrics?.[key] === "number");
  const improvedMetricKey = metricKeys.find((key) => isLowerBetterMetric(key) && before.metrics && after.metrics && after.metrics[key] < before.metrics[key]);
  const metricKey = improvedMetricKey ?? metricKeys[0];
  const httpCompared = before.probe?.status !== null && before.probe?.status !== undefined && after.probe?.status !== null && after.probe?.status !== undefined;
  const metricCompared = metricKey !== undefined;
  const improved = Boolean(httpCompared && after.probe!.status === 200 && before.probe!.status !== 200) || Boolean(improvedMetricKey);
  return {
    verified: Boolean(httpCompared && metricCompared && improved),
    http: httpCompared ? { before: before.probe!.status, after: after.probe!.status } : undefined,
    metric: metricKey && before.metrics && after.metrics ? { name: metricKey, before: before.metrics[metricKey], after: after.metrics[metricKey] } : undefined,
    rollbackSuggested: !(httpCompared && metricCompared && improved),
  };
}

function isLowerBetterMetric(name: string) { return /cpu|memory|mem|ram|rss|error|restart|latency|duration|response|leak/iu.test(name); }
