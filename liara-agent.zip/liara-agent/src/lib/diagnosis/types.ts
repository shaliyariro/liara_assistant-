export type DiagnosisMetrics = Record<string, number>;

export type DiagnosisEvidence = {
  appName: string;
  status: Record<string, unknown> | null;
  logs: string[];
  metrics: DiagnosisMetrics | null;
  releases: Array<Record<string, unknown>> | null;
  probe: { status: number | null; durationMs: number | null; url?: string } | null;
  limitations: Array<{ title: string; detail: string; manualStep: string }>;
  observedAt: string;
};

export type DiagnosisAction = {
  id: string;
  title: string;
  riskLevel: "green" | "red";
  rationale: string;
  cost: string;
  downtime: string;
  reversible: boolean;
  envKey?: string;
  releaseID?: string;
};

export type DiagnosisCause = { id: string; title: string; confidence: number; explanation: string };

export type Finding = {
  id: string;
  severity: "critical" | "important" | "warning";
  summary: string;
  causes: DiagnosisCause[];
  evidence: string[];
  actions: DiagnosisAction[];
  issuePrompt?: { title: string; body: string };
};

export type DiagnosisResult = {
  appName: string;
  finding: Finding;
  evidence: DiagnosisEvidence;
  elapsedMs: number;
  confidenceMethod: "evidence-rule heuristic";
};
