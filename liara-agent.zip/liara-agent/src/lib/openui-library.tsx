import { useState } from "react";
import { createLibrary, defineComponent } from "@openuidev/react-lang";
import { z } from "zod/v4";

const ProjectCardComponent = defineComponent({
  name: "ProjectCard",
  description: "A factual Persian right-to-left summary of checked repository contents.",
  props: z.object({
    sourceName: z.string(), language: z.array(z.string()), framework: z.string(), hasDockerfile: z.boolean(), databases: z.array(z.string()),
    usesRedis: z.boolean(), workers: z.array(z.string()), cron: z.array(z.string()), environmentKeys: z.array(z.string()), fileCount: z.number(),
    sourceSizeMb: z.number(), buildEstimateMb: z.object({ min: z.number(), max: z.number(), note: z.string() }), findings: z.array(z.string()),
  }),
  component: ({ props }) => (
    <article dir="rtl" className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <header className="border-b border-slate-100 bg-slate-50 px-5 py-4 sm:px-6">
        <p className="text-xs font-semibold text-teal-800">شناخت پروژه · {props.sourceName}</p>
        <h2 className="mt-1 text-xl font-bold text-slate-950">{props.framework}</h2>
        <p className="mt-1 text-sm text-slate-600">{props.language.join("، ") || "زبان از فایل‌های موجود مشخص نشد"} · {props.fileCount} فایل بررسی شد</p>
      </header>
      <div className="grid gap-4 p-5 sm:grid-cols-2 sm:p-6">
        <Fact label="پایگاه‌داده" value={props.databases.join("، ") || "موردی شناسایی نشد"} />
        <Fact label="Redis و پردازش پس‌زمینه" value={[props.usesRedis ? "Redis" : "بدون Redis شناسایی‌شده", ...props.workers].join(" · ")} />
        <Fact label="زمان‌بندی" value={props.cron.join("، ") || "cron شناسایی نشد"} />
        <Fact label="Dockerfile" value={props.hasDockerfile ? "پیدا شد" : "پیدا نشد"} />
        <Fact label="متغیرهای نمونه" value={props.environmentKeys.length ? props.environmentKeys.join("، ") : "در .env.example کلیدی پیدا نشد"} />
        <Fact label="اندازه‌ی build" value={`${props.buildEstimateMb.min}–${props.buildEstimateMb.max} MB · تخمینی`} />
      </div>
      <p className="border-t border-slate-100 px-5 py-3 text-xs leading-6 text-slate-500 sm:px-6">اندازه‌ی ورودی بررسی‌شده: {props.sourceSizeMb} MB. {props.buildEstimateMb.note}</p>
    </article>
  ),
});

const QuestionCardComponent = defineComponent({
  name: "QuestionCard",
  description: "A Persian right-to-left choice card with a visible recommended answer.",
  props: z.object({ question: z.string(), id: z.string(), options: z.array(z.object({ value: z.string(), label: z.string() })), recommendation: z.string(), recommendationText: z.string() }),
  component: ({ props }) => (
    <fieldset dir="rtl" className="min-w-0 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6">
      <legend className="px-1 text-base font-bold text-slate-950">{props.question}</legend>
      <p className="mt-1 text-sm leading-6 text-teal-900"><span className="font-bold">پیشنهاد من:</span> {props.recommendationText}</p>
      <div className="mt-4 grid gap-2 sm:grid-cols-2">
        {props.options.map((option) => (
          <label key={option.value} className="flex min-h-11 cursor-pointer items-center gap-3 rounded-xl border border-slate-200 px-3 py-2.5 text-sm text-slate-800 transition hover:border-teal-500 has-[:checked]:border-teal-700 has-[:checked]:bg-teal-50">
            <input type="radio" name={props.id} value={option.value} defaultChecked={option.value === props.recommendation} required className="accent-teal-700" />
            <span>{option.label}</span>
          </label>
        ))}
      </div>
    </fieldset>
  ),
});

const planSchema = z.object({
  role: z.enum(["economic", "recommended", "safer"]), title: z.string(), plan: z.object({ id: z.string(), monthlyToman: z.number(), resourceMonthlyToman: z.number().optional(), bundlePlanID: z.string().optional(), bundleMonthlyToman: z.number().optional(), cpuCores: z.number(), memoryGb: z.number(), diskGb: z.number() }),
  services: z.array(z.object({ name: z.string(), plan: z.object({ id: z.string(), monthlyToman: z.number(), cpuCores: z.number(), memoryGb: z.number(), diskGb: z.number() }) })),
  monthlyToman: z.number(), unsuitableWhen: z.string(),
});

const planPropsSchema = z.object({ options: z.array(planSchema), reason: z.string(), isStale: z.boolean(), updatedAt: z.string() });

const PlanCardComponent = defineComponent({
  name: "PlanCard",
  description: "A comparison of three available Liara plans using current API prices and resources.",
  props: planPropsSchema,
  component: ({ props }) => <PlanCardView {...props} />,
});

function PlanCardView({ options, reason, isStale, updatedAt }: z.infer<typeof planPropsSchema>) {
  const [selected, setSelected] = useState<string | null>(null);
  return (
    <section id="liara-plan-card" dir="rtl" className="space-y-4" aria-label="مقایسه‌ی پلن‌های واقعی لیارا">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div><p className="text-xs font-semibold text-teal-800">انتخاب پلن</p><h2 className="mt-1 text-xl font-bold text-slate-950">سه گزینه از کاتالوگ لیارا</h2></div>
        <span className={`rounded-full px-3 py-1 text-xs font-medium ${isStale ? "bg-amber-100 text-amber-950" : "bg-teal-50 text-teal-900"}`}>
          {isStale ? "کش‌شده · ممکن است قدیمی باشد" : "دریافت‌شده از API لیارا"}
        </span>
      </header>
      <p className="rounded-xl border border-teal-100 bg-teal-50/70 px-4 py-3 text-sm leading-6 text-teal-950">{reason}</p>
      {updatedAt && <p className="text-xs text-slate-500">آخرین دریافت کاتالوگ: {new Date(updatedAt).toLocaleString("fa-IR")}</p>}
      <div className="grid gap-3 lg:grid-cols-3">
        {options.map((option) => {
          const active = selected === option.plan.id;
          return (
            <article key={`${option.role}-${option.plan.id}`} className={`flex flex-col rounded-2xl border bg-white p-5 transition ${option.role === "recommended" ? "border-teal-700 shadow-[0_12px_30px_-24px_rgba(15,118,110,.7)]" : "border-slate-200"}`}>
              <p className={`text-xs font-bold ${option.role === "recommended" ? "text-teal-800" : "text-slate-500"}`}>{option.title}</p>
              <h3 className="mt-2 text-lg font-bold text-slate-950" dir="ltr">{option.plan.id}</h3>
              <p className="mt-3 text-xl font-bold tabular-nums text-slate-950">{money(option.monthlyToman)} <span className="text-xs font-medium text-slate-500">تومان / ماه</span></p>
              <p className="mt-3 text-sm text-slate-700">{option.plan.cpuCores} CPU · {option.plan.memoryGb} GB RAM · {option.plan.diskGb} GB SSD</p>
              {option.plan.resourceMonthlyToman !== undefined && <p className="mt-2 text-xs text-slate-600">منابع پلن · {money(option.plan.resourceMonthlyToman)} تومان/ماه</p>}
              {option.plan.bundlePlanID && <p className="mt-1 text-xs text-slate-600">بسته‌ی {option.plan.bundlePlanID} · {money(option.plan.bundleMonthlyToman ?? 0)} تومان/ماه</p>}
              {option.services.map((service) => <p key={service.name} className="mt-2 text-xs leading-5 text-slate-600">{service.name} · {service.plan.id} · {money(service.plan.monthlyToman)} تومان / ماه</p>)}
              <p className="mt-4 flex-1 border-t border-slate-100 pt-3 text-xs leading-5 text-slate-500">مناسب نیست اگر {option.unsuitableWhen.replace(/^برای\s/u, "")}</p>
              <button type="button" aria-pressed={active} onClick={() => setSelected(option.plan.id)} className={`mt-4 min-h-11 rounded-xl px-4 py-2 text-sm font-semibold transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700 ${active ? "bg-teal-800 text-white" : "border border-slate-300 text-slate-800 hover:bg-slate-50"}`}>
                {active ? "انتخاب شد" : "انتخاب این گزینه"}
              </button>
            </article>
          );
        })}
      </div>
      {selected && <p role="status" className="text-sm text-teal-900">این گزینه فقط برای مقایسه انتخاب شد؛ هیچ پلن یا سرویس خریداری نشده است.</p>}
    </section>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return <div className="min-w-0"><p className="text-xs font-semibold text-slate-500">{label}</p><p className="mt-1 break-words text-sm leading-6 text-slate-900">{value}</p></div>;
}

function money(value: number) { return new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0 }).format(value); }

export const projectLibrary = createLibrary({ root: "ProjectCard", components: [ProjectCardComponent] });
export const questionLibrary = createLibrary({ root: "QuestionCard", components: [QuestionCardComponent] });
export const planLibrary = createLibrary({ root: "PlanCard", components: [PlanCardComponent] });

const recommendationSchema = z.object({
  id: z.string(), action: z.string(), toolName: z.string(), riskLevel: z.enum(["green", "red"]), execution: z.enum(["tool", "approval", "manual"]),
  evidence: z.string(), rule: z.string(), proposal: z.string(), reason: z.string(), financialEffect: z.string(), stabilityEffect: z.string(), downtimeEffect: z.string(), alternative: z.string(), manualStep: z.string().optional(),
});
const RecommendationCardComponent = defineComponent({
  name: "RecommendationCard",
  description: "A compact, evidence-traceable recommendation with explicit cost, stability, downtime, and action path.",
  props: recommendationSchema,
  component: ({ props }) => <RecommendationCardView {...props} />,
});
function RecommendationCardView(props: z.infer<typeof recommendationSchema>) {
  const [expanded, setExpanded] = useState(false);
  const [guide, setGuide] = useState(props.manualStep ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function showManualGuide() {
    if (expanded) { setExpanded(false); return; }
    const service = props.id === "postgres-service" ? "PostgreSQL" : props.id === "redis-service" ? "Redis" : props.id === "mysql-service" ? "MySQL" : "MongoDB";
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/recommendations/manual-service", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ service }) });
      const payload = await response.json() as { manualStep?: string; error?: string };
      if (!response.ok) throw new Error(payload.error ?? "Manual guidance is unavailable.");
      setGuide(payload.manualStep ?? props.manualStep ?? ""); setExpanded(true);
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Manual guidance is unavailable."); }
    finally { setBusy(false); }
  }
  return <article dir="rtl" className={`overflow-hidden rounded-2xl border bg-white shadow-sm ${props.riskLevel === "red" ? "border-rose-200" : "border-teal-200"}`} aria-label="RecommendationCard">
    <header className={`border-b px-5 py-4 ${props.riskLevel === "red" ? "border-rose-100 bg-rose-50" : "border-teal-100 bg-teal-50"}`}>
      <p className="text-xs font-bold text-teal-900">⭐ پیشنهاد من · {props.riskLevel === "red" ? "نیازمند ApprovalCard" : "اقدام کم‌ریسک"}</p>
      <h3 className="mt-1 text-base font-bold leading-7 text-slate-950">{props.action}</h3>
      <p className="mt-2 line-clamp-2 text-sm leading-6 text-slate-700" title={props.reason}>[{props.evidence}] + [{props.rule}] = [{props.proposal}]</p>
    </header>
    <div className="grid gap-3 p-5 text-sm sm:grid-cols-3">
      <RecommendationEffect label="اثر مالی" text={props.financialEffect} />
      <RecommendationEffect label="اثر پایداری" text={props.stabilityEffect} />
      <RecommendationEffect label="زمان قطعی" text={props.downtimeEffect} />
    </div>
    <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 px-5 py-3">
      <p className="text-xs leading-5 text-slate-600">جایگزین: {props.alternative}</p>
      <button type="button" disabled={busy} onClick={() => {
        if (props.execution === "manual") { void showManualGuide(); return; }
        if (props.toolName === "recommend_plan") { document.getElementById("liara-plan-card")?.scrollIntoView({ behavior: "smooth", block: "start" }); return; }
        window.dispatchEvent(new CustomEvent("liara-recommendation-action", { detail: { recommendation: props } }));
      }} className={`min-h-11 rounded-xl px-4 py-2 text-sm font-semibold focus-visible:outline-2 focus-visible:outline-offset-2 ${props.riskLevel === "red" ? "bg-rose-700 text-white focus-visible:outline-rose-700" : "bg-teal-800 text-white focus-visible:outline-teal-700"}`}>
        {props.execution === "manual" ? busy ? "در حال آماده‌سازی…" : expanded ? "بستن راهنمای دستی" : "اجرای ابزار راهنمای دستی" : props.riskLevel === "red" ? "بررسی هزینه و ApprovalCard" : "اجرای ابزار مرتبط"}
      </button>
    </footer>
    {error && <p className="border-t border-rose-200 bg-rose-50 px-5 py-3 text-sm text-rose-900" role="alert">{error}</p>}
    {expanded && guide && <p className="border-t border-amber-200 bg-amber-50 px-5 py-4 text-sm leading-7 text-amber-950" role="note">{guide}</p>}
  </article>;
}
function RecommendationEffect({ label, text }: { label: string; text: string }) { return <div className="min-w-0"><p className="text-xs font-bold text-slate-500">{label}</p><p className="mt-1 break-words leading-6 text-slate-800">{text}</p></div>; }
export const recommendationLibrary = createLibrary({ root: "RecommendationCard", components: [RecommendationCardComponent] });

const findingPropsSchema = z.object({
  appName: z.string(),
  severity: z.enum(["critical", "important", "warning"]),
  summary: z.string(),
  causes: z.array(z.object({ id: z.string(), title: z.string(), confidence: z.number().min(0).max(100), explanation: z.string() })),
  evidence: z.array(z.string()),
  actions: z.array(z.object({ id: z.string(), title: z.string(), riskLevel: z.enum(["green", "red"]), rationale: z.string(), cost: z.string(), downtime: z.string(), reversible: z.boolean(), envKey: z.string().optional(), releaseID: z.string().optional() })),
  issuePrompt: z.object({ title: z.string(), body: z.string() }).optional(),
  elapsedMs: z.number().nonnegative(),
});

const FindingCardComponent = defineComponent({
  name: "FindingCard",
  description: "Evidence-based Persian SRE finding with confidence-ranked causes and safe action choices.",
  props: findingPropsSchema,
  component: ({ props }) => <article dir="rtl" className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm" aria-label={`یافته‌ی عیب‌یابی ${props.appName}`}>
    <header className={`border-b px-5 py-4 sm:px-6 ${props.severity === "critical" ? "border-rose-200 bg-rose-50" : props.severity === "important" ? "border-amber-200 bg-amber-50" : "border-slate-200 bg-slate-50"}`}>
      <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-xs font-semibold text-slate-600">یافته‌ی سلامت · <bdi dir="ltr">{props.appName}</bdi></p><h2 className="mt-1 text-lg font-bold text-slate-950">{severityLabel(props.severity)}</h2></div><span className="rounded-full border border-white/80 bg-white/80 px-3 py-1 text-xs text-slate-700">{props.elapsedMs} ms تا یافته</span></div>
      <p className="mt-3 text-sm leading-7 text-slate-800">{props.summary}</p>
    </header>
    <div className="space-y-5 p-5 sm:p-6">
      <section aria-label="علت‌های رتبه‌بندی‌شده"><h3 className="text-sm font-bold text-slate-900">علت‌های محتمل</h3>{props.causes.length ? <ol className="mt-2 space-y-2">{props.causes.map((cause) => <li key={cause.id} className="rounded-xl border border-slate-100 bg-slate-50 p-3"><div className="flex items-center justify-between gap-3"><strong className="text-sm text-slate-900">{cause.title}</strong><span className="shrink-0 text-sm font-bold tabular-nums text-teal-800">{cause.confidence}%</span></div><p className="mt-1 text-xs leading-5 text-slate-600">{cause.explanation}</p></li>)}</ol> : <p className="mt-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-950">شواهد فعلی برای رتبه‌بندی یک علت مشخص کافی نیست.</p>}<p className="mt-2 text-xs text-slate-500">درصدها امتیاز ابتکاری قواعد مبتنی بر شواهدند؛ احتمال آماری تضمین‌شده نیستند.</p></section>
      <details className="rounded-xl border border-slate-200"><summary className="min-h-11 cursor-pointer px-4 py-3 text-sm font-semibold text-slate-800">نمایش شواهد خامِ پاک‌سازی‌شده ({props.evidence.length})</summary><ul className="space-y-2 border-t border-slate-100 px-4 py-3">{props.evidence.map((line, index) => <li key={`${index}-${line}`} className="break-all font-mono text-xs leading-5 text-slate-700" dir="auto">{line}</li>)}</ul></details>
      <section aria-label="راه‌حل‌ها"><h3 className="text-sm font-bold text-slate-900">راه‌حل‌ها</h3><div className="mt-2 grid gap-2 sm:grid-cols-2">{props.actions.map((action, index) => <div key={action.id} className={`rounded-xl border p-3 ${action.riskLevel === "red" ? "border-rose-200 bg-rose-50/50" : "border-teal-100 bg-teal-50/50"}`}><p className="text-sm font-bold text-slate-900">{index === 0 ? "⭐ پیشنهاد من · " : "جایگزین · "}{action.title}</p><p className="mt-1 text-xs leading-5 text-slate-700">{action.rationale}</p><p className="mt-2 text-xs text-slate-600">{action.cost} · اختلال: {action.downtime} · {action.reversible ? "قابل بازگشت" : "بازگشت تضمین‌شده نیست"}</p><span className={`mt-2 inline-block rounded-full px-2 py-1 text-[11px] ${action.riskLevel === "red" ? "bg-rose-100 text-rose-900" : "bg-teal-100 text-teal-900"}`}>{action.riskLevel === "red" ? "نیازمند ApprovalCard" : "اقدام green"}</span>{action.id !== "issue" && <button type="button" onClick={() => window.dispatchEvent(new CustomEvent("liara-finding-action", { detail: { action } }))} className="mt-3 min-h-11 rounded-lg border border-slate-300 bg-white px-3 text-xs font-semibold text-slate-800">بررسی و اجرا</button>}</div>)}</div></section>
      {props.issuePrompt && <details className="rounded-xl border border-sky-200 bg-sky-50/50"><summary className="min-h-11 cursor-pointer px-4 py-3 text-sm font-semibold text-sky-950">Issue برای عامل کدنویس</summary><div className="border-t border-sky-100 p-4"><h3 className="text-sm font-bold">{props.issuePrompt.title}</h3><pre className="mt-3 whitespace-pre-wrap break-words text-xs leading-5 text-slate-700">{props.issuePrompt.body}</pre><button type="button" onClick={() => void navigator.clipboard.writeText(props.issuePrompt!.body)} className="mt-3 min-h-11 rounded-lg border border-sky-300 bg-white px-4 py-2 text-sm font-semibold text-sky-950">کپی Issue</button></div></details>}
    </div>
  </article>,
});

function severityLabel(severity: "critical" | "important" | "warning") { return severity === "critical" ? "بحرانی" : severity === "important" ? "مهم" : "هشدار"; }
export const findingLibrary = createLibrary({ root: "FindingCard", components: [FindingCardComponent] });
