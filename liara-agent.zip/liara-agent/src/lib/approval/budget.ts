import type { ApprovalCardModel } from "./cards";

export function enforceApprovalCardBudget(cards: ApprovalCardModel[], limit = 3): ApprovalCardModel[] {
  if (!Number.isInteger(limit) || limit < 0) throw new Error("Approval card limit must be a non-negative integer.");
  if (cards.length > limit) throw new Error(`Approval flow has ${cards.length} cards; the limit is ${limit}.`);
  return cards;
}
