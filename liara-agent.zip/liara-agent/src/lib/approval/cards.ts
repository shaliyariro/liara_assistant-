import type { Tool, ToolDescription } from "@/lib/tools/types";
import type { z } from "zod";
import type { ApprovedEnvelope } from "./gate";
import { effectiveRiskLevel } from "./gate";

export type CostLine = { kind: "plan" | "database" | "redis"; name: string; resourceId: string; planID: string; bundlePlanID?: string; monthlyCost: number };
export type ApprovalCardModel = {
  toolName: string;
  riskLevel: "red";
  action: string;
  rationale?: string;
  consequence: string;
  recommendation: string;
  alternatives: string[];
  reversible: boolean;
  monthlyCost?: number;
  costLines?: CostLine[];
};

export function buildApprovalCard<I extends z.ZodType, O>(
  tool: Tool<I, O>, input: z.infer<I>, options: { rationale?: string; envelope?: ApprovedEnvelope } = {},
): ApprovalCardModel | undefined {
  const parsed = tool.inputSchema.parse(input);
  if (effectiveRiskLevel(tool, parsed, options.envelope).riskLevel !== "red") return undefined;
  const description: ToolDescription = tool.describe(parsed);
  return {
    toolName: tool.name,
    riskLevel: "red",
    action: description.action,
    rationale: options.rationale?.slice(0, 400),
    consequence: description.consequence,
    recommendation: description.recommendation,
    alternatives: description.alternatives,
    reversible: description.reversible,
    monthlyCost: description.monthlyCost,
  };
}

export function buildAggregateCostCard(input: {
  toolName: string;
  action: string;
  rationale?: string;
  items: CostLine[];
  recommendation: string;
  alternatives: string[];
}): ApprovalCardModel {
  if (!input.items.length) throw new Error("At least one priced item is required.");
  for (const item of input.items) {
    if (!Number.isFinite(item.monthlyCost) || item.monthlyCost < 0 || !item.resourceId || !item.planID) throw new Error("Every cost line needs a resource, plan, and non-negative server-calculated monthly cost.");
  }
  const allowedKinds = new Set<CostLine["kind"]>(["plan", "database", "redis"]);
  if (input.items.some((item) => !allowedKinds.has(item.kind))) throw new Error("Unsupported cost item.");
  return {
    toolName: input.toolName,
    riskLevel: "red",
    action: input.action,
    rationale: input.rationale?.slice(0, 400),
    consequence: "These services will be provisioned and billed together; the total is the monthly estimate before usage-based extras.",
    recommendation: input.recommendation,
    alternatives: input.alternatives,
    reversible: false,
    monthlyCost: input.items.reduce((sum, item) => sum + item.monthlyCost, 0),
    costLines: input.items.map((item) => ({ ...item })),
  };
}
