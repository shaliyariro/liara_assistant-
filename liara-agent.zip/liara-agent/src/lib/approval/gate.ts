import "server-only";
import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import type { Tool, ToolExecutionContext } from "@/lib/tools/types";
import { getAuditStore } from "@/lib/audit/sqlite";
import { recordToolOutcome } from "@/lib/audit/record";
import type { CostLine } from "./cards";

export type ValidApproval = {
  toolName: string;
  inputDigest: string;
  approvedAt: number;
  expiresAt: number;
  nonce: string;
  signature: string;
};

export type ApprovedEnvelopeClaims = {
  projectIds: string[];
  appNames: string[];
  planIDs: string[];
  servicePlanIDs: string[];
  approvedEnvKeys: string[];
  resources: Array<{ id: string; kind: "app" | "database" | "redis"; planID: string; bundlePlanID?: string; monthlyCost: number }>;
  maxMonthlyCost: number;
  approvedAt: number;
  expiresAt: number;
  nonce: string;
};

export type ApprovedEnvelope = ApprovedEnvelopeClaims & { signature: string };

export class ApprovalRequiredError extends Error {
  readonly code: string = "APPROVAL_REQUIRED";
  constructor(readonly reason = "A valid approval is required before running this sensitive action.") {
    super(reason);
    this.name = "ApprovalRequiredError";
  }
}

export class EnvelopeRequiredError extends ApprovalRequiredError {
  readonly code = "OUTSIDE_APPROVED_ENVELOPE";
  constructor() { super("This action is outside the approved project, service, or cost envelope."); }
}

function signingSecret(): string {
  const secret = process.env.APPROVAL_SIGNING_SECRET;
  if (!secret || secret.length < 32) throw new Error("APPROVAL_SIGNING_SECRET must contain at least 32 characters.");
  return secret;
}

function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => `${JSON.stringify(key)}:${canonical(item)}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

function digest(value: unknown): string {
  return createHmac("sha256", signingSecret()).update(canonical(value)).digest("hex");
}

function safeEqual(left: string, right: string): boolean {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}

function signApprovalPayload(payload: Omit<ValidApproval, "signature">): string { return digest(payload); }

export function issueApproval(toolName: string, input: unknown, now = Date.now(), ttlMs = 60_000): ValidApproval {
  const payload = { toolName, inputDigest: digest(input), approvedAt: now, expiresAt: now + ttlMs, nonce: randomUUID() };
  return { ...payload, signature: signApprovalPayload(payload) };
}

export function createApprovedEnvelope(claims: Omit<ApprovedEnvelopeClaims, "approvedAt" | "expiresAt" | "nonce">, now = Date.now(), ttlMs = 30 * 24 * 60 * 60 * 1000): ApprovedEnvelope {
  const total = claims.resources.reduce((sum, resource) => sum + resource.monthlyCost, 0);
  if (!Number.isFinite(claims.maxMonthlyCost) || total > claims.maxMonthlyCost) throw new Error("Approved resource cost exceeds the monthly limit.");
  if (claims.resources.some((resource) => !Number.isFinite(resource.monthlyCost) || resource.monthlyCost < 0 || !resource.id || !resource.planID || (resource.bundlePlanID !== undefined && !resource.bundlePlanID))) throw new Error("Approved resource details are invalid.");
  const payload: ApprovedEnvelopeClaims = { ...claims, approvedAt: now, expiresAt: now + ttlMs, nonce: randomUUID() };
  return { ...payload, signature: digest(payload) };
}

export function approveCostBundle(input: {
  projectIds: string[];
  appNames: string[];
  planIDs: string[];
  servicePlanIDs: string[];
  approvedEnvKeys: string[];
  items: CostLine[];
  approvedMonthlyLimit: number;
}): ApprovedEnvelope {
  if (!input.projectIds.length) throw new Error("The approved envelope must include at least one project.");
  const resources = input.items.map((item) => ({ id: item.resourceId, kind: item.kind === "plan" ? "app" as const : item.kind, planID: item.planID, ...(item.bundlePlanID ? { bundlePlanID: item.bundlePlanID } : {}), monthlyCost: item.monthlyCost }));
  if (new Set(resources.map(({ id }) => id)).size !== resources.length) throw new Error("Each approved resource must have a unique ID.");
  if (resources.some(({ kind, planID }) => kind === "app" ? !input.planIDs.includes(planID) : !input.servicePlanIDs.includes(planID))) {
    throw new Error("Each resource must use a plan ID included in the approved plan lists.");
  }
  const sum = input.items.reduce((total, item) => total + item.monthlyCost, 0);
  if (sum > input.approvedMonthlyLimit) throw new Error("The aggregate cost exceeds the approved amount.");
  const envelope = createApprovedEnvelope({
    projectIds: input.projectIds,
    appNames: input.appNames,
    planIDs: input.planIDs,
    servicePlanIDs: input.servicePlanIDs,
    approvedEnvKeys: input.approvedEnvKeys,
    resources,
    maxMonthlyCost: input.approvedMonthlyLimit,
  });
  const store = getAuditStore();
  for (const projectId of input.projectIds) store.saveApprovedEnvelope(projectId, envelope);
  recordToolOutcome({ actor: "user", toolName: "approve_cost_bundle", riskLevel: "red", parameters: { projectIds: input.projectIds, resources, monthlyLimit: input.approvedMonthlyLimit }, outcome: "success", userMessage: "The approved resource and monthly cost envelope was saved." });
  return envelope;
}

export function recordApprovalRejection(input: { toolName: string; parameters: unknown; alternatives: string[]; actor?: string }) {
  recordToolOutcome({
    actor: input.actor ?? "user", toolName: input.toolName, riskLevel: "red", parameters: input.parameters, outcome: "failure",
    code: "USER_REJECTED", userMessage: input.alternatives[0] ? `Not run. Alternative: ${input.alternatives[0]}` : "Not run. You can ask for an explanation instead.",
  });
}

export function isValidEnvelope(envelope: ApprovedEnvelope | undefined, now = Date.now()): envelope is ApprovedEnvelope {
  if (!envelope || envelope.expiresAt <= now || envelope.approvedAt > now || !Number.isFinite(envelope.maxMonthlyCost) || envelope.maxMonthlyCost < 0) return false;
  const { signature, ...payload } = envelope;
  try { return safeEqual(signature, digest(payload)); } catch { return false; }
}

export function isValidApproval(approval: ValidApproval | undefined, toolName: string, input: unknown, now = Date.now()): approval is ValidApproval {
  if (!approval || approval.toolName !== toolName || approval.expiresAt <= now || approval.approvedAt > now || approval.expiresAt <= approval.approvedAt) return false;
  const { signature, ...payload } = approval;
  try { return safeEqual(approval.inputDigest, digest(input)) && safeEqual(signature, signApprovalPayload(payload)); } catch { return false; }
}

export function consumeApproval(approval: ValidApproval): boolean {
  return getAuditStore().consumeApprovalNonce(`approval:${approval.nonce}`);
}

export function effectiveRiskLevel<I>(tool: { riskLevel: "green" | "red"; requiresEnvelope?: boolean; withinEnvelope(input: I, envelope: ApprovedEnvelope): boolean }, input: I, envelope?: ApprovedEnvelope): { riskLevel: "green" | "red"; reason?: string } {
  if (tool.riskLevel === "red") return { riskLevel: "red", reason: "This action reads secrets, can incur costs, or can cause destructive changes." };
  if (tool.requiresEnvelope === false) return { riskLevel: "green" };
  if (!isValidEnvelope(envelope) || !tool.withinEnvelope(input, envelope)) {
    return { riskLevel: "red", reason: "This action is outside the approved project, service, or cost envelope." };
  }
  return { riskLevel: "green" };
}

export async function executeWithApproval<I extends import("zod").ZodType, O>(tool: Tool<I, O>, input: unknown, context: ToolExecutionContext = {}): Promise<O> {
  return tool.execute(input, context);
}
