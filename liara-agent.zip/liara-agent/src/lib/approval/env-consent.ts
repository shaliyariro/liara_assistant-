import "server-only";
import { getAuditStore } from "@/lib/audit/sqlite";
import { recordToolOutcome } from "@/lib/audit/record";

export type EnvConsentChoice = "once" | "project" | "deny";
const oneTimeGrants = new Set<string>();

export function setEnvConsent(projectId: string, choice: EnvConsentChoice) {
  if (!projectId.trim()) throw new Error("A project ID is required.");
  if (projectId.length > 120) throw new Error("Project ID is too long.");
  if (choice === "once") {
    oneTimeGrants.add(projectId);
  } else {
    oneTimeGrants.delete(projectId);
    const store = getAuditStore();
    if (choice === "project") store.setEnvConsent(projectId, true);
    else store.revokeEnvConsent(projectId);
  }
  recordToolOutcome({ actor: "user", toolName: "set_env_read_consent", riskLevel: "red", parameters: { projectId, choice }, outcome: choice === "deny" ? "failure" : "success", code: choice === "deny" ? "USER_DENIED" : undefined, userMessage: choice === "deny" ? "Environment read was declined." : "Environment read permission was updated." });
}

export function consumeEnvReadConsent(projectId: string): boolean {
  if (oneTimeGrants.delete(projectId)) return true;
  return getAuditStore().getEnvConsent(projectId)?.allowForProject === true;
}

export function getEnvConsentSettings(projectId: string) {
  return { projectId, allowForProject: getAuditStore().getEnvConsent(projectId)?.allowForProject === true };
}

export function revokeProjectEnvConsent(projectId: string) {
  oneTimeGrants.delete(projectId);
  getAuditStore().revokeEnvConsent(projectId);
}
