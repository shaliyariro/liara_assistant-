import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import Database from "better-sqlite3";
import { z } from "zod";
import { ApprovalRequiredError, EnvelopeRequiredError, approveCostBundle, createApprovedEnvelope, effectiveRiskLevel, issueApproval, recordApprovalRejection } from "./gate";
import { buildAggregateCostCard, buildApprovalCard, type ApprovalCardModel } from "./cards";
import { enforceApprovalCardBudget } from "./budget";
import { consumeEnvReadConsent, getEnvConsentSettings, revokeProjectEnvConsent, setEnvConsent } from "./env-consent";
import { getAuditStore, createAuditStore, installAuditStoreForTests } from "../audit/sqlite";
import { defineTool, ToolInputError } from "../tools/types";
import { TOOL_RISK_POLICY } from "../tools/risk-policy";
import { getLimitation } from "../tools/limitations";

process.env.APPROVAL_SIGNING_SECRET = "phase-four-test-key-0123456789abcdef0123456789abcdef";

const db = new Database(":memory:");
const store = createAuditStore(db);

function clearDatabase() {
  db.exec("DELETE FROM audit_entries; DELETE FROM env_consents; DELETE FROM used_approval_nonces; DELETE FROM approved_envelopes;");
}

const redHandler = vi.fn(async ({ appName }: { appName: string }) => `deleted:${appName}`);
const redTool = defineTool({
  name: "delete_app",
  riskLevel: "red",
  inputSchema: z.object({ appName: z.string() }).strict(),
  describe: ({ appName }) => ({ action: `Delete ${appName}`, consequence: "The service may be permanently removed.", recommendation: "Export data first.", alternatives: ["Stop the app"], reversible: false }),
  withinEnvelope: () => false,
  run: redHandler,
});

function makeEnvelope(overrides: Partial<Parameters<typeof createApprovedEnvelope>[0]> = {}) {
  return createApprovedEnvelope({
    projectIds: ["demo"], appNames: ["demo-app"], planIDs: ["small-g2"], servicePlanIDs: ["basic"], approvedEnvKeys: ["DATABASE_URL"],
    resources: [], maxMonthlyCost: 1000, ...overrides,
  });
}

function makeCard(action: string): ApprovalCardModel {
  return { toolName: "delete_app", riskLevel: "red", action, rationale: "Evidence suggests a broken service.", consequence: "May remove data.", recommendation: "Back up first.", alternatives: ["Stop the service"], reversible: false };
}

beforeAll(() => installAuditStoreForTests(store));
beforeEach(() => { clearDatabase(); redHandler.mockClear(); });
afterAll(() => { installAuditStoreForTests(undefined); db.close(); });

describe("F04 Validation V1–V10", () => {
  it("V1: blocks direct red-tool calls and ignores caller attempts to lower risk", async () => {
    await expect(redTool.execute({ appName: "demo-app" })).rejects.toBeInstanceOf(ApprovalRequiredError);
    await expect(redTool.execute({ appName: "demo-app", riskLevel: "green" })).rejects.toBeInstanceOf(ToolInputError);
    expect(redTool.riskLevel).toBe("red");
    expect(Object.isFrozen(redTool)).toBe(true);
    expect(redHandler).not.toHaveBeenCalled();
  });

  it("V2: keeps deploy-path tools green inside their envelope and red categories fixed", () => {
    const envelope = makeEnvelope();
    const projectTool = defineTool({
      name: "restart_app", riskLevel: "green", inputSchema: z.object({ projectId: z.string() }).strict(),
      describe: () => ({ action: "Restart", consequence: "Brief interruption possible.", recommendation: "Restart once.", alternatives: ["Read logs"], reversible: false }),
      withinEnvelope: ({ projectId }, approved) => approved.projectIds.includes(projectId), run: async () => "ok",
    });
    expect(buildApprovalCard(projectTool, { projectId: "demo" }, { envelope })).toBeUndefined();
    expect(effectiveRiskLevel(projectTool, { projectId: "demo" }, envelope).riskLevel).toBe("green");
    for (const name of ["create_app", "set_env", "upload_source", "deploy_release", "redeploy", "restart_app"] as const) expect(TOOL_RISK_POLICY[name]).toBe("green");
    for (const name of ["read_env", "select_plan", "change_plan", "create_database", "create_redis", "delete_app", "delete_database", "rollback_release", "change_domain"] as const) expect(TOOL_RISK_POLICY[name]).toBe("red");
  });

  it("V3: escalates green actions that leave the approved envelope", async () => {
    const tool = defineTool({
      name: "restart_app", riskLevel: "green", inputSchema: z.object({ projectId: z.string() }).strict(),
      describe: () => ({ action: "Restart", consequence: "Brief interruption possible.", recommendation: "Restart once.", alternatives: ["Read logs"], reversible: false }),
      withinEnvelope: ({ projectId }, envelope) => envelope.projectIds.includes(projectId), run: vi.fn(async () => "ok"),
    });
    const envelope = makeEnvelope();
    expect(effectiveRiskLevel(tool, { projectId: "another-project" }, envelope)).toMatchObject({ riskLevel: "red" });
    await expect(tool.execute({ projectId: "another-project" }, { envelope })).rejects.toBeInstanceOf(EnvelopeRequiredError);
  });

  it("V4: groups plan, database and Redis into one cost card and one approval", async () => {
    const lines = [
      { kind: "plan" as const, name: "Node app", resourceId: "demo-app", planID: "small-g2", monthlyCost: 475_000 },
      { kind: "database" as const, name: "Postgres", resourceId: "db-main", planID: "small-g2", monthlyCost: 475_000 },
      { kind: "redis" as const, name: "Redis", resourceId: "cache-main", planID: "small-g2", monthlyCost: 475_000 },
    ];
    const card = buildAggregateCostCard({ toolName: "provision_bundle", action: "Provision the app and its data services", items: lines, recommendation: "Use the approved bundle.", alternatives: ["Use only the app"] });
    expect(card.monthlyCost).toBe(1_425_000);
    expect(card.costLines).toHaveLength(3);
    const monthlyLimit = card.monthlyCost ?? 0;
    const envelope = approveCostBundle({
      projectIds: ["demo"], appNames: ["demo-app"], planIDs: ["small-g2"], servicePlanIDs: ["small-g2"],
      approvedEnvKeys: [], items: lines, approvedMonthlyLimit: monthlyLimit,
    });
    expect(getAuditStore().getApprovedEnvelope("demo")).toMatchObject({ maxMonthlyCost: 1_425_000, resources: [{ id: "demo-app" }, { id: "db-main" }, { id: "cache-main" }] });
    expect(envelope.resources).toHaveLength(3);
    expect(() => approveCostBundle({
      projectIds: ["demo"], appNames: ["demo-app"], planIDs: ["small-g2"], servicePlanIDs: ["basic"],
      approvedEnvKeys: [], items: lines, approvedMonthlyLimit: monthlyLimit,
    })).toThrow(/plan ID included/u);
  });

  it("V5: three concurrent local approval clicks complete below five seconds", async () => {
    const starts: number[] = [];
    const tool = defineTool({
      name: "test_sensitive_action", riskLevel: "red", inputSchema: z.object({ user: z.string() }).strict(),
      describe: () => ({ action: "Run a protected action", consequence: "Test action only.", recommendation: "Proceed.", alternatives: ["Cancel"], reversible: false }),
      withinEnvelope: () => false, run: async ({ user }) => { starts.push(Date.now()); return user; },
    });
    const begin = performance.now();
    const results = await Promise.all(["user-1", "user-2", "user-3"].map((user) => tool.execute({ user }, { approval: issueApproval("test_sensitive_action", { user }) })));
    const elapsed = performance.now() - begin;
    expect(results).toHaveLength(3);
    expect(starts).toHaveLength(3);
    expect(elapsed).toBeLessThan(5_000);
  });

  it("V6: supports one-use and project env consent and revocation", () => {
    setEnvConsent("demo", "once");
    expect(consumeEnvReadConsent("demo")).toBe(true);
    expect(consumeEnvReadConsent("demo")).toBe(false);
    setEnvConsent("demo", "project");
    expect(getEnvConsentSettings("demo").allowForProject).toBe(true);
    expect(consumeEnvReadConsent("demo")).toBe(true);
    expect(consumeEnvReadConsent("demo")).toBe(true);
    revokeProjectEnvConsent("demo");
    expect(getEnvConsentSettings("demo").allowForProject).toBe(false);
    expect(consumeEnvReadConsent("demo")).toBe(false);
  });

  it("V7: writes success and failure to SQLite while masking env values", async () => {
    const envTool = defineTool({
      name: "set_env", riskLevel: "green", inputSchema: z.object({ projectId: z.string(), variables: z.array(z.object({ key: z.string(), value: z.string() })) }).strict(),
      describe: () => ({ action: "Set env", consequence: "Updates app settings.", recommendation: "Set approved values.", alternatives: ["Cancel"], reversible: false }),
      withinEnvelope: ({ projectId }, envelope) => envelope.projectIds.includes(projectId), run: async () => "done",
    });
    const input = { projectId: "demo", variables: [{ key: "DATABASE_URL", value: "postgres://secret-value" }] };
    await envTool.execute(input, { envelope: makeEnvelope({ approvedEnvKeys: ["DATABASE_URL"] }) });
    const rows = getAuditStore().list();
    const serialized = JSON.stringify(rows);
    expect(serialized).not.toContain("postgres://secret-value");
    expect(serialized).toContain("[REDACTED]");
    expect(rows[0].outcome).toBe("success");
  });

  it("V8: rejection records the alternative and never invokes the tool", () => {
    recordApprovalRejection({ toolName: "delete_app", parameters: { appName: "demo" }, alternatives: ["Stop the app"] });
    expect(redHandler).not.toHaveBeenCalled();
    expect(getAuditStore().list()[0]).toMatchObject({ code: "USER_REJECTED", userMessage: "Not run. Alternative: Stop the app" });
  });

  it("V9: caps the demo flow at three approval cards", () => {
    const flow = enforceApprovalCardBudget([makeCard("Plan"), makeCard("Env read"), makeCard("Delete")], 3);
    expect(flow).toHaveLength(3);
    expect(() => enforceApprovalCardBudget([...flow, makeCard("Extra")], 3)).toThrow(/limit is 3/u);
  });

  it("V10: exposes an API limitation and manual path before attempting billing", () => {
    expect(getLimitation("charge_account")).toMatchObject({ title: expect.stringContaining("API"), manualStep: expect.stringContaining("پنل Liara") });
  });
});
