import "server-only";
import { randomUUID } from "node:crypto";
import { analyzeEvidence, verifyFix } from "@/lib/diagnosis/analyze";
import { recommendForLocalDemo } from "@/lib/recommendations/engine";
import type { DiagnosisEvidence } from "@/lib/diagnosis/types";
import { demoBaseUrl, createDemoToolRegistry } from "@/lib/tools/demo-tools";

const sessions = new Map<string, { before: DiagnosisEvidence; recommendationId: string; createdAt: number }>();
const DEMO_SLOW_RECOMMENDATION = "demo-slow-fix";

export async function activateDemoSlowFailure() {
  const registry = createDemoToolRegistry();
  await registry.execute("activate_demo_failure", { failure: "slow" }, { actor: "user" });
  const health = await requestJson<{ status: string; failures: string[] }>("/health");
  return { active: health.failures.includes("slow"), failures: health.failures };
}

export async function diagnoseDemoSlowFailure() {
  const startedAt = Date.now();
  const evidence = await collectDemoEvidence();
  const result = analyzeEvidence(evidence, startedAt);
  result.finding.actions = [];
  const recommendations = recommendForLocalDemo(result);
  if (!recommendations.length) throw new Error("The local probe did not observe the injected slow response. Activate the slow failure and retry.");
  const sessionId = randomUUID();
  expireSessions();
  sessions.set(sessionId, { before: evidence, recommendationId: DEMO_SLOW_RECOMMENDATION, createdAt: Date.now() });
  return { result, recommendations, sessionId };
}

export async function executeDemoRecommendation(sessionId: string, recommendationId: string) {
  expireSessions();
  const session = sessions.get(sessionId);
  if (!session || session.recommendationId !== recommendationId || recommendationId !== DEMO_SLOW_RECOMMENDATION) throw new Error("The demo recommendation expired. Activate the failure and diagnose again.");
  const registry = createDemoToolRegistry();
  const toolResult = await registry.execute("disable_demo_failure", { failure: "slow" }, { actor: "user" });
  const after = await collectDemoEvidence();
  const verification = verifyFix(session.before, after);
  sessions.delete(sessionId);
  return { toolResult, before: publicEvidence(session.before), after: publicEvidence(after), verification };
}

export async function resetDemoService() {
  const registry = createDemoToolRegistry();
  const response = await registry.execute("reset_demo_state", {}, { actor: "user" }) as { failures?: string[]; leakedChunks?: number; slowResponseMs?: number };
  sessions.clear();
  return response;
}

async function collectDemoEvidence(): Promise<DiagnosisEvidence> {
  const [health, logData] = await Promise.all([
    requestJson<Record<string, unknown>>("/health"), requestJson<{ logs?: unknown[] }>("/demo-logs"),
  ]);
  const probe = await timedProbe();
  const metrics = await requestJson<Record<string, unknown>>("/metrics");
  const numericMetrics = Object.fromEntries(Object.entries(metrics).filter((entry): entry is [string, number] => typeof entry[1] === "number" && Number.isFinite(entry[1])));
  return {
    appName: "demo-broken-app",
    status: health,
    logs: (logData.logs ?? []).map((line) => typeof line === "string" ? line : JSON.stringify(line)),
    metrics: numericMetrics,
    releases: null,
    probe,
    limitations: [{ title: "Liara release history unavailable for local demo", detail: "This scenario runs a local Node demo service and does not request Liara release data.", manualStep: "Use the Liara diagnosis flow for a real Liara app." }],
    observedAt: new Date().toISOString(),
  };
}

async function timedProbe() {
  const started = performance.now();
  const response = await fetch(`${demoBaseUrl()}/slow`, { signal: AbortSignal.timeout(8_000) });
  await response.arrayBuffer();
  return { status: response.status, durationMs: Math.round(performance.now() - started), url: `${demoBaseUrl()}/slow` };
}

async function requestJson<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try { response = await fetch(`${demoBaseUrl()}${path}`, { ...init, signal: AbortSignal.timeout(8_000) }); }
  catch { throw new Error("The local demo service is not reachable. Start it with npm run demo:broken."); }
  if (!response.ok) throw new Error(`The local demo service returned HTTP ${response.status}.`);
  try { return await response.json() as T; } catch { throw new Error("The local demo service returned invalid JSON."); }
}

function publicEvidence(evidence: DiagnosisEvidence) {
  return { probe: evidence.probe, metrics: evidence.metrics, status: evidence.status, observedAt: evidence.observedAt };
}

function expireSessions() {
  const cutoff = Date.now() - 10 * 60_000;
  for (const [id, session] of sessions) if (session.createdAt < cutoff) sessions.delete(id);
}
