export type AuditEntry = {
  id?: string;
  timestamp: string;
  actor: string;
  toolName: string;
  riskLevel: "green" | "red";
  maskedInput: unknown;
  outcome: "success" | "failure";
  code?: string;
  userMessage?: string;
  reversible?: boolean;
  undoAction?: string;
};

export interface AuditSink {
  write(entry: AuditEntry): Promise<void>;
}
