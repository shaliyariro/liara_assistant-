const SECRET_KEY = /(password|passwd|secret|token|authorization|api[-_]?key|database[-_]?url|connection[-_]?string|private[-_]?key)/i;
const ENV_CONTAINER = /^(variables|envs|environment|environmentvariables)$/i;

export function maskAuditValue(value: unknown, parentKey = ""): unknown {
  if (ENV_CONTAINER.test(parentKey) && Array.isArray(value)) {
    return value.map((item) => {
      if (!item || typeof item !== "object") return "[REDACTED]";
      return Object.fromEntries(Object.entries(item).map(([key, child]) => [
        key,
        key === "value" ? "[REDACTED]" : maskAuditValue(child, key),
      ]));
    });
  }
  if (SECRET_KEY.test(parentKey)) return "[REDACTED]";
  if (Array.isArray(value)) return value.map((item) => maskAuditValue(item));
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([key, child]) => [key, maskAuditValue(child, key)]));
  }
  if (typeof value === "string") {
    return value.replace(/(Bearer\s+)[^\s"']+/gi, "$1[REDACTED]");
  }
  return value;
}
