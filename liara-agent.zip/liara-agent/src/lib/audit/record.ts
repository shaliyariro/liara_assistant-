import "server-only";
import { randomUUID } from "node:crypto";
import { getAuditStore } from "./sqlite";
import { maskAuditValue } from "./mask";
import type { AuditEntry } from "./index";

export function recordToolOutcome(input: {
  actor: string;
  toolName: string;
  riskLevel: "green" | "red";
  parameters: unknown;
  outcome: "success" | "failure";
  code?: string;
  userMessage: string;
  reversible?: boolean;
  undoAction?: string;
}) {
  const entry: AuditEntry = {
    id: randomUUID(),
    timestamp: new Date().toISOString(),
    actor: input.actor,
    toolName: input.toolName,
    riskLevel: input.riskLevel,
    maskedInput: maskAuditValue(input.parameters),
    outcome: input.outcome,
    code: input.code,
    userMessage: input.userMessage,
    reversible: input.reversible === true,
    undoAction: input.undoAction,
  };
  getAuditStore().write(entry);
}
