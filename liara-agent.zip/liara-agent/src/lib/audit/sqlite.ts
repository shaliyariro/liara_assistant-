import "server-only";
import Database from "better-sqlite3";
import { mkdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { randomUUID } from "node:crypto";
import type { AuditEntry, AuditSink } from "./index";

export type EnvConsent = { projectId: string; allowForProject: boolean; updatedAt: string };

export function createAuditStore(db: Database.Database) {
  db.pragma("journal_mode = WAL");
  db.exec(`
    CREATE TABLE IF NOT EXISTS audit_entries (
      id TEXT PRIMARY KEY,
      timestamp TEXT NOT NULL,
      actor TEXT NOT NULL,
      tool_name TEXT NOT NULL,
      risk_level TEXT NOT NULL CHECK (risk_level IN ('green', 'red')),
      masked_input TEXT NOT NULL,
      outcome TEXT NOT NULL CHECK (outcome IN ('success', 'failure')),
      code TEXT,
      user_message TEXT,
      reversible INTEGER NOT NULL DEFAULT 0,
      undo_action TEXT
    );
    CREATE INDEX IF NOT EXISTS audit_entries_timestamp_idx ON audit_entries(timestamp DESC);
    CREATE TABLE IF NOT EXISTS env_consents (
      project_id TEXT PRIMARY KEY,
      allow_for_project INTEGER NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS used_approval_nonces (
      nonce TEXT PRIMARY KEY,
      used_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS approved_envelopes (
      project_id TEXT PRIMARY KEY,
      envelope_json TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  const insert = db.prepare(`INSERT INTO audit_entries
    (id, timestamp, actor, tool_name, risk_level, masked_input, outcome, code, user_message, reversible, undo_action)
    VALUES (@id, @timestamp, @actor, @toolName, @riskLevel, @maskedInput, @outcome, @code, @userMessage, @reversible, @undoAction)`);
  const getConsent = db.prepare("SELECT project_id AS projectId, allow_for_project AS allowForProject, updated_at AS updatedAt FROM env_consents WHERE project_id = ?");
  const upsertConsent = db.prepare(`INSERT INTO env_consents(project_id, allow_for_project, updated_at) VALUES (?, ?, ?)
    ON CONFLICT(project_id) DO UPDATE SET allow_for_project=excluded.allow_for_project, updated_at=excluded.updated_at`);
  const deleteConsent = db.prepare("DELETE FROM env_consents WHERE project_id = ?");
  const useNonce = db.prepare("INSERT INTO used_approval_nonces(nonce, used_at) VALUES (?, ?)");
  const saveEnvelope = db.prepare(`INSERT INTO approved_envelopes(project_id, envelope_json, updated_at) VALUES (?, ?, ?)
    ON CONFLICT(project_id) DO UPDATE SET envelope_json=excluded.envelope_json, updated_at=excluded.updated_at`);
  const getEnvelope = db.prepare("SELECT envelope_json AS envelopeJson FROM approved_envelopes WHERE project_id = ?");
  const listEnvelopes = db.prepare("SELECT envelope_json AS envelopeJson FROM approved_envelopes");
  const deleteEnvelope = db.prepare("DELETE FROM approved_envelopes WHERE project_id = ?");

  return {
    write(entry: AuditEntry) {
      insert.run({
        id: entry.id ?? randomUUID(),
        timestamp: entry.timestamp,
        actor: entry.actor,
        toolName: entry.toolName,
        riskLevel: entry.riskLevel,
        maskedInput: JSON.stringify(entry.maskedInput),
        outcome: entry.outcome,
        code: entry.code ?? null,
        userMessage: entry.userMessage ?? null,
        reversible: entry.reversible ? 1 : 0,
        undoAction: entry.undoAction ?? null,
      });
    },
    list(limit = 100): AuditEntry[] {
      return db.prepare(`SELECT id, timestamp, actor, tool_name AS toolName, risk_level AS riskLevel,
        masked_input AS maskedInput, outcome, code, user_message AS userMessage,
        reversible, undo_action AS undoAction FROM audit_entries ORDER BY timestamp DESC LIMIT ?`).all(limit)
        .map((row) => {
          const rowData = row as Record<string, unknown>;
          return {
            id: String(rowData.id), timestamp: String(rowData.timestamp), actor: String(rowData.actor),
            toolName: String(rowData.toolName), riskLevel: rowData.riskLevel as AuditEntry["riskLevel"],
            maskedInput: JSON.parse(String(rowData.maskedInput)), outcome: rowData.outcome as AuditEntry["outcome"],
            code: rowData.code == null ? undefined : String(rowData.code),
            userMessage: rowData.userMessage == null ? undefined : String(rowData.userMessage),
            reversible: Boolean(rowData.reversible), undoAction: rowData.undoAction == null ? undefined : String(rowData.undoAction),
          };
        });
    },
    getEnvConsent(projectId: string): EnvConsent | undefined {
      const row = getConsent.get(projectId) as Record<string, unknown> | undefined;
      return row ? { projectId: String(row.projectId), allowForProject: Boolean(row.allowForProject), updatedAt: String(row.updatedAt) } : undefined;
    },
    setEnvConsent(projectId: string, allowForProject: boolean) {
      upsertConsent.run(projectId, allowForProject ? 1 : 0, new Date().toISOString());
    },
    revokeEnvConsent(projectId: string) { deleteConsent.run(projectId); },
    saveApprovedEnvelope(projectId: string, envelope: unknown) { saveEnvelope.run(projectId, JSON.stringify(envelope), new Date().toISOString()); },
    getApprovedEnvelope<T>(projectId: string): T | undefined {
      const row = getEnvelope.get(projectId) as { envelopeJson: string } | undefined;
      return row ? JSON.parse(row.envelopeJson) as T : undefined;
    },
    findApprovedEnvelope<T>(predicate: (envelope: unknown) => boolean): T | undefined {
      for (const row of listEnvelopes.all() as Array<{ envelopeJson: string }>) {
        try { const envelope = JSON.parse(row.envelopeJson) as unknown; if (predicate(envelope)) return envelope as T; } catch { /* Ignore corrupt legacy rows. */ }
      }
      return undefined;
    },
    revokeApprovedEnvelope(projectId: string) { deleteEnvelope.run(projectId); },
    consumeApprovalNonce(nonce: string) {
      try {
        useNonce.run(nonce, new Date().toISOString());
        return true;
      } catch {
        return false;
      }
    },
  };
}

export type AuditStore = ReturnType<typeof createAuditStore>;

let store: AuditStore | undefined;
export function installAuditStoreForTests(testStore: AuditStore | undefined) {
  if (process.env.NODE_ENV !== "test") throw new Error("Test audit stores can only be installed in the test environment.");
  store = testStore;
}

export function getAuditStore(): AuditStore {
  if (!store) {
    const path = resolve(process.env.AUDIT_DB_PATH || join(process.cwd(), "data", "audit.sqlite"));
    mkdirSync(dirname(path), { recursive: true });
    store = createAuditStore(new Database(path));
  }
  return store;
}

export const sqliteAuditSink: AuditSink = { async write(entry) { getAuditStore().write(entry); } };
