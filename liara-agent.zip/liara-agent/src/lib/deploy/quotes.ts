import "server-only";
import { createHmac, createHash, randomUUID, timingSafeEqual } from "node:crypto";
import type { ApprovedEnvelope } from "@/lib/approval/gate";
import type { LiaraPlan } from "@/lib/liara/plan-catalog";

export type DeploymentQuote = {
  id: string;
  projectId: string;
  appName: string;
  sourceName: string;
  environmentKeys: string[];
  platform: string;
  port: number;
  plan: LiaraPlan;
  rationale: string;
  expiresAt: number;
};

function key() {
  const secret = process.env.APPROVAL_SIGNING_SECRET;
  if (!secret || secret.length < 32) throw new Error("APPROVAL_SIGNING_SECRET must contain at least 32 characters.");
  return secret;
}

function mac(value: string) { return createHmac("sha256", key()).update(value).digest(); }
function constantTimeEqual(a: Buffer, b: Buffer) { return a.length === b.length && timingSafeEqual(a, b); }

function encode<T extends object>(value: T) {
  const payload = Buffer.from(JSON.stringify(value)).toString("base64url");
  const signature = mac(payload).toString("base64url");
  return `${payload}.${signature}`;
}

function decode<T>(token: string): T | undefined {
  const [payload, signature, extra] = token.split(".");
  if (!payload || !signature || extra) return undefined;
  try {
    if (!constantTimeEqual(mac(payload), Buffer.from(signature, "base64url"))) return undefined;
    return JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as T;
  } catch { return undefined; }
}

export function createDeploymentQuote(input: Omit<DeploymentQuote, "id" | "expiresAt">, now = Date.now()) {
  const quote: DeploymentQuote = { ...input, id: randomUUID(), expiresAt: now + 10 * 60_000 };
  return { quote, token: encode(quote) };
}

export function verifyDeploymentQuote(token: string, now = Date.now()): DeploymentQuote | undefined {
  const quote = decode<DeploymentQuote>(token);
  if (!quote || quote.expiresAt <= now || !quote.id || !quote.projectId || !quote.appName || !quote.plan.id || !quote.plan.bundlePlanID) return undefined;
  return quote;
}

export function createDeploymentTicket(envelope: ApprovedEnvelope, quote: DeploymentQuote) {
  return encode({
    envelope,
    id: randomUUID(),
    expiresAt: Math.min(envelope.expiresAt, Date.now() + 2 * 60 * 60_000),
    projectId: quote.projectId,
    appName: quote.appName,
    sourceName: quote.sourceName,
    platform: quote.platform,
    port: quote.port,
    environmentKeys: quote.environmentKeys,
  });
}

export function verifyDeploymentTicket(token: string, now = Date.now()): { envelope: ApprovedEnvelope; id: string; projectId: string; appName: string; sourceName: string; platform: string; port: number; environmentKeys: string[] } | undefined {
  const ticket = decode<{ envelope: ApprovedEnvelope; id: string; expiresAt: number; projectId: string; appName: string; sourceName: string; platform: string; port: number; environmentKeys: string[] }>(token);
  if (!ticket || ticket.expiresAt <= now || !ticket.id || !ticket.envelope || !ticket.projectId || !ticket.appName || !ticket.sourceName || !ticket.platform || !Number.isInteger(ticket.port) || !Array.isArray(ticket.environmentKeys)) return undefined;
  return ticket;
}

export function deploymentIdentity(sourceName: string) {
  const normalized = sourceName.trim().toLowerCase();
  const digest = createHash("sha256").update(normalized).digest("hex");
  const leaf = normalized.split(/[\\/]/u).filter(Boolean).at(-1)?.replace(/\.git$/u, "") ?? "project";
  const slug = leaf.normalize("NFKD").replace(/[^a-z0-9-]+/gu, "-").replace(/^-+|-+$/gu, "").replace(/-+/gu, "-").slice(0, 48) || "project";
  return { projectId: `repo-${digest.slice(0, 24)}`, appName: `${slug.slice(0, 54)}-${digest.slice(0, 7)}` };
}

export function platformForFramework(framework: string, hasDockerfile: boolean) {
  if (hasDockerfile) return "docker";
  if (framework === "Django") return "django";
  if (framework === "Flask") return "flask";
  if (framework === "Next.js") return "next";
  if (framework === "FastAPI") return "python";
  if (framework === "Go") return "go";
  if (framework === "PHP") return "php";
  return "node";
}

export function portForPlatform(platform: string) {
  return platform === "django" || platform === "flask" || platform === "python" ? 8000 : 3000;
}
