import "server-only";
import { createHash } from "node:crypto";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, isAbsolute, join, resolve, sep } from "node:path";
import * as yauzl from "yauzl";
import * as tar from "tar";
import { RepoAnalysisError } from "@/lib/repo/analyze-repo";

const MAX_ZIP_BYTES = 25 * 1024 * 1024;
const MAX_EXPANDED_BYTES = 120 * 1024 * 1024;
const MAX_SOURCE_BYTES = 256 * 1024 * 1024;
const MAX_ENTRIES = 10_000;

export async function fetchGithubZip(url: string, fetcher: typeof fetch = fetch): Promise<Buffer> {
  const parsed = new URL(url);
  if (parsed.protocol !== "https:" || parsed.hostname.toLowerCase() !== "github.com" || parsed.username || parsed.password || parsed.search || parsed.hash) {
    throw new RepoAnalysisError("Use an https://github.com/owner/repository URL.");
  }
  const parts = parsed.pathname.split("/").filter(Boolean);
  if (parts.length !== 2 || !/^[A-Za-z0-9_.-]+$/u.test(parts[0]) || !/^[A-Za-z0-9_.-]+$/u.test(parts[1].replace(/\.git$/iu, ""))) {
    throw new RepoAnalysisError("Use the repository root URL, without a branch or file path.");
  }
  const repository = parts[1].replace(/\.git$/iu, "");
  const headers = new Headers({ Accept: "application/vnd.github+json", "User-Agent": "liara-project-deployer" });
  if (process.env.GITHUB_TOKEN) headers.set("Authorization", `Bearer ${process.env.GITHUB_TOKEN}`);
  const response = await fetcher(`https://api.github.com/repos/${encodeURIComponent(parts[0])}/${encodeURIComponent(repository)}/zipball`, { headers, signal: AbortSignal.timeout(20_000) });
  if (!response.ok) throw new RepoAnalysisError(`GitHub returned HTTP ${response.status}; the source could not be downloaded.`, response.status === 404 ? 404 : 502);
  if (Number(response.headers.get("content-length") ?? 0) > MAX_ZIP_BYTES) throw new RepoAnalysisError("The GitHub ZIP exceeds the 25 MB limit.", 413);
  const reader = response.body?.getReader();
  if (!reader) throw new RepoAnalysisError("GitHub returned an empty source archive.");
  const chunks: Buffer[] = [];
  let bytes = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > MAX_ZIP_BYTES) { await reader.cancel(); throw new RepoAnalysisError("The GitHub ZIP exceeds the 25 MB limit.", 413); }
      chunks.push(Buffer.from(value));
    }
  } finally { reader.releaseLock(); }
  return Buffer.concat(chunks);
}

/** Reads only requested .env keys after the caller has obtained consent. */
export async function readEnvValuesFromZip(zipBytes: Buffer, keys: string[]): Promise<Record<string, string>> {
  const extracted = await collectZipFiles(zipBytes, { envOnly: true });
  try {
    if (!extracted.hasEnv) return {};
    const source = (await readFile(join(extracted.workspace, ".env"), "utf8")).split(/\r?\n/u);
    const wanted = new Set(keys);
    const values: Record<string, string> = {};
    for (const line of source) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const separator = trimmed.indexOf("=");
      if (separator < 1) continue;
      const key = trimmed.slice(0, separator).trim();
      if (!wanted.has(key) || !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(key)) continue;
      values[key] = trimmed.slice(separator + 1).trim().replace(/^(['"])(.*)\1$/u, "$2");
    }
    return values;
  } finally { await rm(extracted.temp, { recursive: true, force: true }); }
}

/** Builds the same tar.gz source format used by Liara CLI, always excluding local secrets. */
export async function packageSource(zipBytes: Buffer): Promise<{ archive: Buffer; sha256: string }> {
  const extracted = await collectZipFiles(zipBytes);
  const archivePath = join(extracted.temp, "source.tar.gz");
  try {
    await tar.c({ gzip: true, file: archivePath, cwd: extracted.workspace, portable: true }, ["."]);
    const archive = await readFile(archivePath);
    if (!archive.length || archive.length > MAX_SOURCE_BYTES) throw new RepoAnalysisError("The packaged source exceeds Liara's 256 MB upload limit.", 413);
    return { archive, sha256: createHash("sha256").update(archive).digest("hex") };
  } finally {
    await rm(extracted.temp, { recursive: true, force: true });
  }
}

async function collectZipFiles(bytes: Buffer, options: { envOnly?: boolean } = {}): Promise<{ temp: string; workspace: string; hasEnv: boolean }> {
  if (!bytes.length || bytes.length > MAX_ZIP_BYTES) throw new RepoAnalysisError("ZIP files must be between 1 byte and 25 MB.", 413);
  let zip: yauzl.ZipFile;
  try { zip = await yauzl.fromBufferPromise(bytes, { lazyEntries: true, autoClose: false, decodeStrings: true, validateEntrySizes: true, strictFileNames: true }); }
  catch { throw new RepoAnalysisError("The uploaded file is not a valid ZIP archive."); }

  const temp = await mkdtemp(join(tmpdir(), "liara-deploy-"));
  const entries: Array<{ path: string; entry: yauzl.Entry }> = [];
  let expanded = 0;
  try {
    let count = 0;
    for await (const entry of zip.eachEntry()) {
      if (++count > MAX_ENTRIES) throw new RepoAnalysisError("The source archive contains too many files.");
      const rawPath = entry.fileName.replace(/\\/gu, "/");
      if (rawPath.startsWith("/") || isAbsolute(rawPath) || /^[A-Za-z]:/u.test(rawPath) || rawPath.split("/").some((part) => part === "..")) throw new RepoAnalysisError("The ZIP contains an unsafe file path.");
      if (rawPath.endsWith("/")) continue;
      const mode = entry.externalFileAttributes >>> 16;
      if ((mode & 0o170000) === 0o120000) continue;
      expanded += entry.uncompressedSize;
      if (expanded > MAX_EXPANDED_BYTES) throw new RepoAnalysisError("The source archive expands beyond the 120 MB extraction limit.", 413);
      entries.push({ path: rawPath, entry });
    }
    const root = commonRoot(entries.map(({ path }) => path));
    const projectDir = join(temp, "project");
    await mkdir(projectDir, { recursive: true });
    let hasEnv = false;
    for (const { path: rawPath, entry } of entries) {
      const path = root && rawPath.startsWith(`${root}/`) ? rawPath.slice(root.length + 1) : rawPath;
      if (options.envOnly && path !== ".env") continue;
      if (shouldOmit(path, options.envOnly === true)) continue;
      const destination = resolve(projectDir, path);
      if (destination !== projectDir && !destination.startsWith(`${projectDir}${sep}`)) throw new RepoAnalysisError("The ZIP contains an unsafe file path.");
      if (entry.uncompressedSize > MAX_SOURCE_BYTES) throw new RepoAnalysisError("A source file exceeds Liara's upload limit.", 413);
      await mkdir(dirname(destination), { recursive: true });
      const stream = await zip.openReadStreamPromise(entry);
      const chunks: Buffer[] = [];
      let received = 0;
      for await (const chunk of stream) {
        const buffer = Buffer.from(chunk);
        received += buffer.length;
        if (received > entry.uncompressedSize + 1 || received > MAX_SOURCE_BYTES) throw new RepoAnalysisError("A source file exceeded its declared size.", 413);
        chunks.push(buffer);
      }
      await writeFile(destination, Buffer.concat(chunks), { mode: (entry.externalFileAttributes >>> 16) & 0o111 ? 0o755 : 0o644 });
      if (path === ".env") hasEnv = true;
    }
    return { temp, workspace: projectDir, hasEnv };
  } catch (error) {
    await rm(temp, { recursive: true, force: true });
    if (error instanceof RepoAnalysisError) throw error;
    throw new RepoAnalysisError("The source ZIP could not be extracted safely.");
  } finally { if (zip.isOpen) zip.close(); }
}

function commonRoot(paths: string[]) {
  if (!paths.length) return "";
  const first = paths[0].split("/")[0];
  return first && paths.every((path) => path.startsWith(`${first}/`)) ? first : "";
}

function shouldOmit(path: string, includeEnv: boolean) {
  const parts = path.split("/").map((part) => part.toLowerCase());
  const basename = parts.at(-1) ?? "";
  return (!includeEnv && basename === ".env") || basename.startsWith(".env.") || [".git", "node_modules", ".next", "dist", "build", "vendor", "coverage"].some((name) => parts.includes(name)) || basename.endsWith(".log");
}
