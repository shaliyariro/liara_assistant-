import "server-only";
import { randomBytes } from "node:crypto";
import { issueApproval, isValidEnvelope, type ApprovedEnvelope } from "@/lib/approval/gate";
import { setEnvConsent, type EnvConsentChoice } from "@/lib/approval/env-consent";
import { recordToolOutcome } from "@/lib/audit/record";
import { LiaraClient } from "@/lib/liara/client";
import { LiaraError } from "@/lib/liara/errors";
import { createReadEnvArchiveTool, createLiaraToolRegistry } from "@/lib/tools/liara-tools";
import type { ToolRegistry } from "@/lib/tools/registry";
import { packageSource, fetchGithubZip, readEnvValuesFromZip } from "./source";

export type DeployStage = "clone" | "build" | "push" | "run" | "health";
export type DeployEvent =
  | { type: "stage"; stage: DeployStage; state: "running" | "succeeded" | "failed"; message: string }
  | { type: "env"; values: Array<{ key: string; masked: string }> }
  | { type: "detail"; line: string }
  | { type: "complete"; url: string; httpStatus: 200 }
  | { type: "failure"; stage: DeployStage; message: string; retryable: boolean }
  | { type: "handoff"; target: "F03"; stage: DeployStage; summary: string; evidence: string[] };

export type DeploymentInput = {
  envelope: ApprovedEnvelope;
  projectId: string;
  appName: string;
  platform: string;
  port: number;
  environmentKeys: string[];
  ticketId: string;
  sourceZip?: Buffer;
  githubUrl?: string;
  envChoice: EnvConsentChoice;
  manualEnv?: Record<string, string>;
};

export type DeploymentDependencies = {
  client?: Pick<LiaraClient, "listApps" | "createApp" | "updateEnv" | "uploadSource" | "deployRelease" | "getRelease" | "getBuildLogs" | "getDomains" | "getLogs">;
  createRegistry?: (client: LiaraClient, archive: Blob) => ToolRegistry;
  fetcher?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
  maxBuildPolls?: number;
  maxHealthChecks?: number;
  healthCheck?: (url: string) => Promise<{ status: number }>;
};

export async function runDeployment(input: DeploymentInput, emit: (event: DeployEvent) => void, dependencies: DeploymentDependencies = {}) {
  const client = dependencies.client ?? new LiaraClient();
  const fetcher = dependencies.fetcher ?? fetch;
  const sleep = dependencies.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  const healthCheck = dependencies.healthCheck ?? (async (url) => {
    const response = await fetcher(url, { redirect: "manual", signal: AbortSignal.timeout(10_000) });
    return { status: response.status };
  });
  const environmentKeys = [...new Set(input.environmentKeys)].filter((key) => /^[A-Za-z_][A-Za-z0-9_]*$/u.test(key)).slice(0, 100);
  const secrets: string[] = [];
  let stage: DeployStage = "clone";
  let appCreated = false;
  let registry: ToolRegistry | undefined;
  let sourceZip = input.sourceZip;
  const protectedClient = client as LiaraClient;

  try {
    assertDeploymentScope(input);
    emit({ type: "stage", stage, state: "running", message: "در حال دریافت و آماده‌سازی سورس" });
    if (!sourceZip && input.githubUrl) sourceZip = await fetchGithubZip(input.githubUrl, fetcher);
    if (!sourceZip) throw new DeploymentError(stage, "سورس پروژه در دسترس نیست؛ دوباره فایل یا لینک را بفرست.", false);

    let variables: Record<string, string> = {};
    if (environmentKeys.length === 0) {
      variables = {};
    } else if (input.envChoice === "deny") {
      setEnvConsent(input.projectId, "deny");
      variables = validateManualEnv(input.manualEnv ?? {}, environmentKeys);
    } else {
      setEnvConsent(input.projectId, input.envChoice);
      const reader = createReadEnvArchiveTool((keys) => readEnvValuesFromZip(sourceZip!, keys));
      const readInput = { projectId: input.projectId, keys: environmentKeys };
      variables = await reader.execute(readInput, { approval: issueApproval(reader.name, readInput), actor: "user" });
    }
    for (const value of Object.values(variables)) if (value) secrets.push(value);
    addGeneratedSecrets(variables, environmentKeys, secrets);
    emit({ type: "env", values: Object.entries(variables).map(([key, value]) => ({ key, masked: maskSecret(value) })) });

    const packaged = await packageSource(sourceZip);
    const archive = new Blob([new Uint8Array(packaged.archive)], { type: "application/gzip" });
    registry = dependencies.createRegistry?.(protectedClient, archive) ?? createLiaraToolRegistry(protectedClient, archive);
    const envelopeContext = { envelope: input.envelope, actor: "agent" } as const;
    const appInput = { projectId: input.projectId, appName: input.appName, planID: approvedResource(input.envelope, input.appName).planID, bundlePlanID: approvedResource(input.envelope, input.appName).bundlePlanID!, platform: input.platform, monthlyCost: approvedResource(input.envelope, input.appName).monthlyCost };
    const app = await registry.execute("create_app", appInput, envelopeContext) as { created: boolean };
    appCreated = true;
    emit({ type: "stage", stage, state: "succeeded", message: app.created ? "اپ در چارچوب تأییدشده ساخته شد" : "اپ قبلی پیدا شد؛ اپ تکراری نساختیم" });

    if (Object.keys(variables).length) {
      const envInput = { projectId: input.projectId, appName: input.appName, variables: Object.entries(variables).map(([key, value]) => ({ key, value })) };
      await registry.execute("set_env", envInput, envelopeContext);
    }

    const uploadInput = { projectId: input.projectId, appName: input.appName, sourceDigest: packaged.sha256, sourceBytes: packaged.archive.length };
    const uploaded = await registry.execute("upload_source", uploadInput, envelopeContext) as { sourceID: string };
    stage = "build";
    emit({ type: "stage", stage, state: "running", message: "Liara در حال بیلد سورس است" });
    const release = await registry.execute("deploy_release", { projectId: input.projectId, appName: input.appName, sourceID: uploaded.sourceID, platform: input.platform, port: input.port }, envelopeContext) as { releaseID: string };

    let cursor: string | undefined;
    let state = "";
    for (let attempt = 0; attempt < (dependencies.maxBuildPolls ?? 360); attempt++) {
      const progress = await client.getBuildLogs(release.releaseID, cursor);
      state = progress.data.release.state.toUpperCase();
      for (const item of progress.data.buildOutput ?? []) {
        cursor = item.createdAt || cursor;
        if (item.line) {
          const clean = redact(item.line, secrets);
          if (/^(Successfully tagged|Pushing\.\.\.)/iu.test(clean)) {
            if (stage === "build") emit({ type: "stage", stage: "build", state: "succeeded", message: "بیلد تمام شد" });
            stage = "push";
            emit({ type: "stage", stage, state: "running", message: "در حال پوش تصویر" });
          }
          emit({ type: "detail", line: clean.slice(0, 1200) });
        }
      }
      if (state === "FAILED" || state === "UNHEALTHY" || state === "TIMEDOUT" || state === "CANCELED") {
        throw new DeploymentError(stage, readableReleaseFailure(state, progress.data.release.failReason, secrets), true);
      }
      if (state === "DEPLOYING") {
        if (stage === "build") emit({ type: "stage", stage, state: "succeeded", message: "بیلد تمام شد" });
        if (stage === "build" || stage === "push") emit({ type: "stage", stage: "push", state: "succeeded", message: "پوش تصویر تمام شد" });
        stage = "run";
        emit({ type: "stage", stage, state: "running", message: "کانتینر در حال اجرا و بررسی سلامت Liara است" });
      }
      if (state === "READY") break;
      await sleep(5_000);
    }
    if (state !== "READY") throw new DeploymentError(stage, "ساخت release در زمان مجاز به وضعیت آماده نرسید.", true);

    if (stage === "build") emit({ type: "stage", stage, state: "succeeded", message: "بیلد تمام شد" });
    if (stage === "build" || stage === "push") emit({ type: "stage", stage: "push", state: "succeeded", message: "پوش تصویر تمام شد" });
    if (stage !== "run") {
      stage = "run";
      emit({ type: "stage", stage, state: "running", message: "در انتظار راه‌اندازی کانتینر" });
    }
    emit({ type: "stage", stage, state: "succeeded", message: "release در Liara آماده شد" });

    stage = "health";
    emit({ type: "stage", stage, state: "running", message: "در حال بررسی HTTP اپ" });
    const url = await resolveAppUrl(client, input.appName, input.envelope.resources.find((item) => item.id === input.appName)?.planID);
    let httpStatus = 0;
    for (let attempt = 0; attempt < (dependencies.maxHealthChecks ?? 12); attempt++) {
      try { httpStatus = (await healthCheck(url)).status; } catch { httpStatus = 0; }
      if (httpStatus === 200) break;
      await sleep(5_000);
    }
    recordToolOutcome({ actor: "agent", toolName: "http_health_check", riskLevel: "green", parameters: { projectId: input.projectId, appName: input.appName, url, httpStatus }, outcome: httpStatus === 200 ? "success" : "failure", code: httpStatus === 200 ? undefined : "HEALTH_CHECK_FAILED", userMessage: httpStatus === 200 ? "The deployed app returned HTTP 200." : "The app did not return HTTP 200 after its release became ready." });
    if (httpStatus !== 200) throw new DeploymentError(stage, `release در Liara آماده است، اما health check واقعی HTTP 200 نداد (آخرین وضعیت: ${httpStatus || "بدون پاسخ"}).`, true);
    emit({ type: "stage", stage, state: "succeeded", message: "health check واقعی HTTP 200 داد" });
    emit({ type: "complete", url, httpStatus: 200 });
    return { ok: true as const, url };
  } catch (error) {
    const failure = error instanceof DeploymentError ? error : new DeploymentError(stage, error instanceof LiaraError ? error.userMessage : "مرحله‌ی دیپلوی ناموفق شد. جزئیات حساس پنهان شدند.", error instanceof LiaraError ? error.retryable : false);
    emit({ type: "stage", stage: failure.stage, state: "failed", message: failure.message });
    const evidence: string[] = [];
    if (appCreated) {
      try {
        const logResponse = await client.getLogs(input.appName);
        evidence.push(...extractSafeLines(logResponse.data, secrets).slice(-3));
      } catch { evidence.push("Liara deployment logs were not available for automatic diagnosis."); }
    }
    recordToolOutcome({ actor: "agent", toolName: "f03_deploy_failure_handoff", riskLevel: "green", parameters: { projectId: input.projectId, appName: input.appName, stage: failure.stage, deploymentTicket: input.ticketId }, outcome: "success", userMessage: "Deployment failure was automatically handed to the F03 diagnosis flow." });
    emit({ type: "handoff", target: "F03", stage: failure.stage, summary: failure.message, evidence });
    emit({ type: "failure", stage: failure.stage, message: failure.message, retryable: failure.retryable });
    return { ok: false as const, stage: failure.stage, message: failure.message };
  }
}

class DeploymentError extends Error {
  constructor(readonly stage: DeployStage, message: string, readonly retryable: boolean) { super(message); }
}

function assertDeploymentScope(input: DeploymentInput) {
  if (!isValidEnvelope(input.envelope) || !input.envelope.projectIds.includes(input.projectId) || !input.envelope.appNames.includes(input.appName)) throw new DeploymentError("clone", "چارچوب تأییدشده معتبر یا منطبق با این پروژه نیست.", false);
  const resource = approvedResource(input.envelope, input.appName);
  if (!resource.bundlePlanID) throw new DeploymentError("clone", "پلن bundle تأییدشده در چارچوب وجود ندارد.", false);
}

function approvedResource(envelope: ApprovedEnvelope, appName: string) {
  const resource = envelope.resources.find((item) => item.id === appName && item.kind === "app");
  if (!resource) throw new DeploymentError("clone", "اپ خارج از چارچوب تأییدشده است.", false);
  return resource;
}

function validateManualEnv(values: Record<string, string>, allowedKeys: string[]) {
  const allowed = new Set(allowedKeys);
  const variables: Record<string, string> = {};
  for (const [key, value] of Object.entries(values)) {
    if (!allowed.has(key) || !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(key) || typeof value !== "string" || value.length > 20_000) throw new DeploymentError("clone", "یکی از کلیدهای env با پروژه یا چارچوب تأییدشده هم‌خوانی ندارد.", false);
    if (value) variables[key] = value;
  }
  return variables;
}

function addGeneratedSecrets(values: Record<string, string>, keys: string[], secrets: string[]) {
  for (const key of keys) {
    if (!/^(SECRET_KEY|DJANGO_SECRET_KEY|NEXTAUTH_SECRET|JWT_SECRET)$/iu.test(key) || values[key]) continue;
    const value = randomBytes(48).toString("base64url");
    values[key] = value;
    secrets.push(value);
  }
}

function maskSecret(value: string) { return value ? `••••••${value.slice(-4)}` : ""; }

function redact(value: string, secrets: string[]) {
  let output = value;
  for (const secret of secrets.filter(Boolean)) output = output.split(secret).join("[REDACTED]");
  return output.replace(/(Bearer\s+)[^\s"']+/giu, "$1[REDACTED]").replace(/((?:password|secret|token|api[-_]?key|database[-_]?url)\s*[=:]\s*)[^\s"']+/giu, "$1[REDACTED]");
}

function extractSafeLines(value: unknown, secrets: string[]) {
  const text = typeof value === "string" ? value : JSON.stringify(value);
  return text.split(/\r?\n/u).filter(Boolean).map((line) => redact(line, secrets).slice(0, 500));
}

function readableReleaseFailure(state: string, reason: string | undefined, secrets: string[]) {
  const safeReason = reason ? redact(reason, secrets).slice(0, 300) : "";
  return `Liara release ${state.toLowerCase()}${safeReason ? `: ${safeReason}` : ". بررسی لاگ ساخت پیشنهاد می‌شود."}`;
}

async function resolveAppUrl(client: NonNullable<DeploymentDependencies["client"]>, appName: string, planID?: string) {
  try {
    const { data } = await client.getDomains(appName);
    const domain = data.domains?.[0];
    if (domain?.name) return `${domain.certificatesStatus === "ACTIVE" ? "https" : "http"}://${domain.name}`;
  } catch { /* Use Liara's documented default subdomain if custom domain lookup is unavailable. */ }
  const region = planID?.startsWith("eu-") || planID?.includes("germany") ? "" : ".iran";
  return `https://${appName}${region}.liara.run`;
}
