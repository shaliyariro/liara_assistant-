import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import Database from "better-sqlite3";
import { ZipFile } from "yazl";
import { createApprovedEnvelope } from "@/lib/approval/gate";
import { getAuditStore, createAuditStore, installAuditStoreForTests } from "@/lib/audit/sqlite";
import { getEnvConsentSettings, revokeProjectEnvConsent, setEnvConsent } from "@/lib/approval/env-consent";
import { createLiaraToolRegistry } from "@/lib/tools/liara-tools";
import { runDeployment } from "./pipeline";
import { verifyDeploymentQuote, createDeploymentQuote, deploymentIdentity } from "./quotes";
import { normalizeLiveCatalog } from "@/lib/liara/plan-catalog";
import { recommendPlan } from "@/lib/plan-rules";
import type { LiaraClient } from "@/lib/liara/client";

process.env.APPROVAL_SIGNING_SECRET = "f02-deployment-test-key-0123456789abcdef0123456789";
const secret = "F02_SECRET_SENTINEL_test_9f3a";
const db = new Database(":memory:");
const auditStore = createAuditStore(db);

function clearDatabase() { db.exec("DELETE FROM audit_entries; DELETE FROM env_consents; DELETE FROM used_approval_nonces; DELETE FROM approved_envelopes;"); }

function makeEnvelope(projectId = "repo-test") {
  return createApprovedEnvelope({
    projectIds: [projectId], appNames: ["sample-app-1234567"], planIDs: ["small-g2"], servicePlanIDs: [], approvedEnvKeys: ["DATABASE_URL", "SECRET_KEY"],
    resources: [{ id: "sample-app-1234567", kind: "app", planID: "small-g2", bundlePlanID: "basic", monthlyCost: 749_998 }], maxMonthlyCost: 749_998,
  });
}

function fakeLiara(options: { existing?: boolean; state?: string; buildLine?: string; deploymentLogs?: unknown; created?: (...args: unknown[]) => unknown } = {}) {
  const created = options.created ?? vi.fn();
  const uploadedArchives: Buffer[] = [];
  const uploaded = vi.fn(async (_name: string, file: Blob) => { uploadedArchives.push(Buffer.from(await file.arrayBuffer())); return { data: { sourceID: "source-1" }, status: 200, headers: new Headers() }; });
  const envPayloads: unknown[] = [];
  const client = {
    listApps: vi.fn(async () => ({ data: { projects: options.existing ? [{ project_id: "sample-app-1234567" }] : [] }, status: 200, headers: new Headers() })),
    createApp: vi.fn(async (input: unknown) => { created(input); return { data: undefined, status: 201, headers: new Headers() }; }),
    updateEnv: vi.fn(async (_name: string, variables: unknown) => { envPayloads.push(variables); return { data: {}, status: 200, headers: new Headers() }; }),
    uploadSource: uploaded,
    deployRelease: vi.fn(async () => ({ data: { releaseID: "release-1" }, status: 201, headers: new Headers() })),
    getRelease: vi.fn(async () => ({ data: { release: { state: options.state ?? "READY" } }, status: 200, headers: new Headers() })),
    getBuildLogs: vi.fn(async () => ({ data: { release: { state: options.state ?? "READY", ...(options.state === "FAILED" ? { failReason: "build failed" } : {}) }, buildOutput: options.buildLine ? [{ stream: "STDOUT", line: options.buildLine, createdAt: "2026-10-23T10:00:00.000Z" }] : [] }, status: 200, headers: new Headers() })),
    getDomains: vi.fn(async () => ({ data: { domains: [{ name: "sample-app.iran.liara.run", certificatesStatus: "ACTIVE" }] }, status: 200, headers: new Headers() })),
    getLogs: vi.fn(async () => ({ data: options.deploymentLogs ?? "build log", status: 200, headers: new Headers() })),
  };
  return { client: client as unknown as LiaraClient, created, uploaded, uploadedArchives, envPayloads };
}

async function zipProject(files: Record<string, string>) {
  const zip = new ZipFile();
  for (const [path, value] of Object.entries(files)) zip.addBuffer(Buffer.from(value), `project-root/${path}`, { compress: true });
  zip.end();
  const chunks: Buffer[] = [];
  for await (const chunk of zip.outputStream) chunks.push(Buffer.from(chunk));
  return Buffer.concat(chunks);
}

const source = zipProject({ "package.json": '{"name":"sample","scripts":{"start":"node server.js"}}', "server.js": "console.log('ready')", ".env.example": "DATABASE_URL=\nSECRET_KEY=\n", ".env": `DATABASE_URL=postgres://app:${secret}@db.example/app\nSECRET_KEY=${secret}\n` });

beforeAll(() => installAuditStoreForTests(auditStore));
beforeEach(clearDatabase);
afterAll(() => { installAuditStoreForTests(undefined); db.close(); });

describe("F02 deployment and env V1–V7", () => {
  it("V1: requires only the aggregate cost and env-read approvals; deployment tools stay green in scope", () => {
    const liara = fakeLiara();
    const registry = createLiaraToolRegistry(liara.client);
    for (const name of ["create_app", "set_env", "upload_source", "deploy_release"]) expect(registry.get(name).riskLevel).toBe("green");
    expect(registry.list().filter(({ riskLevel }) => riskLevel === "red").map(({ name }) => name)).toContain("read_env");
    const envelope = makeEnvelope();
    const quote = createDeploymentQuote({ projectId: "repo-test", appName: "sample-app-1234567", sourceName: "sample", environmentKeys: ["DATABASE_URL"], platform: "node", port: 3000, rationale: "Node project detected.", plan: { id: "small-g2", monthlyToman: 749_998, resourceMonthlyToman: 474_998, bundlePlanID: "basic", bundleMonthlyToman: 275_000, cpuCores: 0.5, memoryGb: 0.5, diskGb: 5, region: "iran", supportedEngines: [] } });
    expect(verifyDeploymentQuote(quote.token)?.plan.monthlyToman).toBe(749_998);
    expect(envelope.resources).toHaveLength(1);
  });

  it("V2: the secret is absent from SQLite audit, server events/logs, and any LLM payload while Liara receives it directly", async () => {
    const liara = fakeLiara({ buildLine: `Build detail echoed ${secret}`, deploymentLogs: `failure detail ${secret}` });
    const events: unknown[] = [];
    const consoleSpy = vi.spyOn(console, "info").mockImplementation(() => undefined);
    const result = await runDeployment({ envelope: makeEnvelope(), projectId: "repo-test", appName: "sample-app-1234567", platform: "node", port: 3000, environmentKeys: ["DATABASE_URL", "SECRET_KEY"], ticketId: "ticket-v2", sourceZip: await source, envChoice: "once" }, (event) => events.push(event), { client: liara.client, healthCheck: async () => ({ status: 200 }), sleep: async () => undefined });
    const audit = JSON.stringify(getAuditStore().list());
    const serverOutput = JSON.stringify({ events, logs: consoleSpy.mock.calls });
    const llmPayloads: string[] = [];
    expect(result.ok).toBe(true);
    expect(JSON.stringify(liara.envPayloads)).toContain(secret);
    expect(audit).not.toContain(secret);
    expect(serverOutput).not.toContain(secret);
    expect(JSON.stringify(llmPayloads)).not.toContain(secret);
    expect(events).toContainEqual(expect.objectContaining({ type: "env", values: expect.arrayContaining([expect.objectContaining({ key: "SECRET_KEY", masked: expect.stringContaining(secret.slice(-4)) })]) }));
    expect(liara.uploadedArchives).toHaveLength(1);
    expect(liara.uploadedArchives[0].includes(Buffer.from(secret))).toBe(false);
    consoleSpy.mockRestore();
  });

  it("V3: declining env read uses manual masked-input fields and project consent can be revoked", async () => {
    const liara = fakeLiara();
    const events: unknown[] = [];
    await runDeployment({ envelope: makeEnvelope(), projectId: "repo-test", appName: "sample-app-1234567", platform: "node", port: 3000, environmentKeys: ["DATABASE_URL"], ticketId: "ticket-v3", sourceZip: await source, envChoice: "deny", manualEnv: { DATABASE_URL: "postgres://manual-user:manual-secret@db/app" } }, (event) => events.push(event), { client: liara.client, healthCheck: async () => ({ status: 200 }), sleep: async () => undefined });
    expect(liara.envPayloads).toContainEqual([{ key: "DATABASE_URL", value: "postgres://manual-user:manual-secret@db/app" }]);
    expect(JSON.stringify(getAuditStore().list())).not.toContain("manual-secret");
    setEnvConsent("repo-test", "project");
    expect(getEnvConsentSettings("repo-test").allowForProject).toBe(true);
    revokeProjectEnvConsent("repo-test");
    expect(getEnvConsentSettings("repo-test").allowForProject).toBe(false);
  });

  it("V4: only an actual HTTP 200 emits deploy success", async () => {
    const liara = fakeLiara();
    const events: Array<{ type: string; [key: string]: unknown }> = [];
    const statuses = [503, 200];
    const result = await runDeployment({ envelope: makeEnvelope(), projectId: "repo-test", appName: "sample-app-1234567", platform: "node", port: 3000, environmentKeys: [], ticketId: "ticket-v4", sourceZip: await source, envChoice: "deny" }, (event) => events.push(event), { client: liara.client, healthCheck: async () => ({ status: statuses.shift() ?? 503 }), sleep: async () => undefined, maxHealthChecks: 2 });
    expect(result).toMatchObject({ ok: true, url: "https://sample-app.iran.liara.run" });
    expect(events.filter(({ type }) => type === "complete")).toHaveLength(1);
    const failed: Array<{ type: string; [key: string]: unknown }> = [];
    const badHealthLiara = fakeLiara();
    await runDeployment({ envelope: makeEnvelope(), projectId: "repo-test", appName: "sample-app-1234567", platform: "node", port: 3000, environmentKeys: [], ticketId: "ticket-v4-fail", sourceZip: await source, envChoice: "deny" }, (event) => failed.push(event), { client: badHealthLiara.client, healthCheck: async () => ({ status: 503 }), sleep: async () => undefined, maxHealthChecks: 1 });
    expect(failed.some(({ type }) => type === "complete")).toBe(false);
    expect(failed.some(({ type }) => type === "handoff")).toBe(true);
  });

  it("V5: failed builds automatically gather redacted evidence and hand off to F03", async () => {
    const liara = fakeLiara({ state: "FAILED", deploymentLogs: `password=${secret}` });
    const events: unknown[] = [];
    const result = await runDeployment({ envelope: makeEnvelope(), projectId: "repo-test", appName: "sample-app-1234567", platform: "node", port: 3000, environmentKeys: ["DATABASE_URL"], ticketId: "ticket-v5", sourceZip: await source, envChoice: "once" }, (event) => events.push(event), { client: liara.client, sleep: async () => undefined });
    expect(result).toMatchObject({ ok: false, stage: "build" });
    expect(events).toContainEqual(expect.objectContaining({ type: "handoff", target: "F03", evidence: expect.arrayContaining([expect.stringContaining("[REDACTED]")]) }));
    expect(JSON.stringify(events)).not.toContain(secret);
  });

  it("V6: rerunning with an existing deterministic app name reuses the app instead of creating a duplicate", async () => {
    const createCount = vi.fn();
    const liara = fakeLiara({ existing: true, created: createCount });
    for (const ticketId of ["ticket-first", "ticket-second"]) {
      await runDeployment({ envelope: makeEnvelope(), projectId: "repo-test", appName: "sample-app-1234567", platform: "node", port: 3000, environmentKeys: [], ticketId, sourceZip: await source, envChoice: "deny" }, () => undefined, { client: liara.client, healthCheck: async () => ({ status: 200 }), sleep: async () => undefined });
    }
    expect(liara.client.createApp).not.toHaveBeenCalled();
    expect(liara.client.listApps).toHaveBeenCalledTimes(2);
    expect(liara.client.deployRelease).toHaveBeenCalledTimes(2);
  });

  it("V7: derives project name/platform and recommends only plans with real available bundles", () => {
    expect(deploymentIdentity("https://github.com/example/my-project")).toMatchObject({ appName: expect.stringMatching(/^my-project-[a-f0-9]{7}$/u) });
    const analysis = { sourceName: "sample", language: ["JavaScript/TypeScript"], framework: "Next.js", hasDockerfile: false, databases: [], usesRedis: false, workers: [], cron: [], environmentKeys: [], fileCount: 4, sourceSizeMb: 0.1, buildEstimateMb: { min: 1, max: 2, note: "estimate" }, findings: [], databaseAmbiguous: true, staticSite: false };
    const catalog = normalizeLiveCatalog({ plans: { projects: {
      "old-plan": { available: true, price: 2, CPU: { amount: 1 }, RAM: { amount: 1 }, volume: 10 },
      "one-g2": { available: true, price: 3, CPU: { amount: 1 }, RAM: { amount: 2 }, volume: 10 },
      "two-g2": { available: true, price: 4, CPU: { amount: 2 }, RAM: { amount: 4 }, volume: 20 },
      "three-g2": { available: true, price: 5, CPU: { amount: 4 }, RAM: { amount: 8 }, volume: 40 },
    }, projectBundlePlans: { "one-g2": { basic: { available: true, displayPrice: 100 } }, "two-g2": { basic: { available: true, displayPrice: 200 } }, "three-g2": { basic: { available: true, displayPrice: 300 } } } } }, "2026-10-23T00:00:00.000Z");
    const selected = recommendPlan(analysis, { traffic: "dozens", priority: "balanced", domain: "temporary" }, catalog);
    expect(selected.options).toHaveLength(3);
    expect(selected.options[0].plan.id).toBe("one-g2");
    expect(selected.options[0].plan.monthlyToman).toBe(2_260);
    expect(selected.options.every(({ plan }) => Boolean(plan.bundlePlanID))).toBe(true);
  });
});
