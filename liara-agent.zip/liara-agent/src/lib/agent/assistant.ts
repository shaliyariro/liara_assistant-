import "server-only";
import { LiaraClient } from "@/lib/liara/client";
import { LiaraError } from "@/lib/liara/errors";
import { getLiaraPlanCatalog } from "@/lib/liara/plan-catalog";
import { createLiaraToolRegistry } from "@/lib/tools/liara-tools";
import { collectDiagnosis } from "@/lib/diagnosis/collect";
import { analyzeEvidence, redactDiagnosticLog } from "@/lib/diagnosis/analyze";
import type { ToolRegistry } from "@/lib/tools/registry";

/**
 * Conversational assistant on an OpenAI-compatible endpoint (Liara AI by default).
 * The model only gets READ-ONLY tools. Anything that changes infrastructure stays in the UI
 * behind the F04 approval cards, so the model can explain and propose but never act on its own.
 */

export type AssistantStep = { tool: string; appName?: string; ok: boolean; ms: number; note?: string };
export type AssistantReply = { answer: string; steps: AssistantStep[]; model: string };
export type AssistantMessage = { role: "user" | "assistant"; content: string };

type ChatMessage =
  | { role: "system" | "user"; content: string }
  | { role: "assistant"; content: string | null; tool_calls?: Array<{ id: string; type: "function"; function: { name: string; arguments: string } }> }
  | { role: "tool"; tool_call_id: string; content: string };

export class AssistantNotConfiguredError extends Error {
  constructor() { super("Liara AI is not configured. Set LIARA_AI_BASE_URL, LIARA_AI_API_KEY and LIARA_AI_MODEL in the server environment."); }
}

export function assistantConfig() {
  const baseUrl = process.env.LIARA_AI_BASE_URL?.replace(/\/$/u, "");
  const apiKey = process.env.LIARA_AI_API_KEY;
  const model = process.env.LIARA_AI_MODEL || "openai/gpt-4o-mini";
  return baseUrl && apiKey ? { baseUrl, apiKey, model } : undefined;
}

const appNameParam = { type: "object", properties: { appName: { type: "string", description: "Liara app name (project id), lowercase" } }, required: ["appName"], additionalProperties: false };

const TOOL_SPECS = [
  { name: "list_apps", description: "List the apps on the user's Liara account with their status and plan.", parameters: { type: "object", properties: {}, additionalProperties: false } },
  { name: "diagnose_app", description: "Collect status, logs, metrics, releases and a live HTTP probe for one app, then return ranked likely causes and suggested actions. Use this first for any 'slow / down / error / 500' question.", parameters: appNameParam },
  { name: "get_app_status", description: "Read one app's status, platform, plan and current release.", parameters: appNameParam },
  { name: "get_logs", description: "Read the last hour of one app's logs (secrets redacted).", parameters: appNameParam },
  { name: "get_metrics", description: "Read one app's CPU/RAM summary if Liara exposes it.", parameters: appNameParam },
  { name: "get_release_history", description: "Read one app's recent releases and their states.", parameters: appNameParam },
  { name: "http_probe", description: "Send one GET to the app's public URL and measure status and latency.", parameters: appNameParam },
  { name: "list_plans", description: "List currently purchasable Liara app plans with monthly price in Toman, CPU, RAM and disk.", parameters: { type: "object", properties: {}, additionalProperties: false } },
] as const;

const SYSTEM_PROMPT = `تو «دستیار لیارا» هستی؛ همکار فنی صاحب سایتی که دانش زیرساخت ندارد. همیشه فارسی، کوتاه و ساده جواب بده.
قواعد:
- قبل از هر ادعا، با ابزارها شواهد جمع کن. عدد یا وضعیتی را که ابزار برنگردانده نساز. اگر داده‌ای در دسترس نیست، صریح بگو «این داده از API لیارا در دسترس نیست».
- برای سؤال‌های «کند است / بالا نمی‌آید / خطا می‌دهد» اول diagnose_app را صدا بزن و علت‌های محتمل را به ترتیب احتمال با شواهدشان توضیح بده.
- تو هیچ ابزاری برای تغییر چیزی نداری. اقدام اصلاحی (ری‌استارت، ست env، تغییر پلن، رولبک، دیپلوی) را فقط پیشنهاد بده و بگو کاربر آن را از بخش «عیب‌یابی» یا «دیپلوی» همین پنل با کارت تأیید اجرا کند. هزینه یا ریسک اقدام را بگو.
- شارژ حساب، ثبت دامنه در ایرنیک و تنظیم DNS از API ممکن نیست؛ مراحل دستی را توضیح بده.
- هیچ‌وقت توکن، رمز یا مقدار env را تکرار نکن.
قالب جواب: یک جمله‌ی خلاصه، بعد «شواهد»، بعد «پیشنهاد من ⭐» و در صورت نیاز «گزینه‌های دیگر».`;

const MAX_STEPS = 6;
const MAX_TOOL_CHARS = 6_000;

export async function runAssistant(history: AssistantMessage[], options: { fetcher?: typeof fetch; registry?: ToolRegistry; client?: LiaraClient } = {}): Promise<AssistantReply> {
  const config = assistantConfig();
  if (!config) throw new AssistantNotConfiguredError();
  const fetcher = options.fetcher ?? fetch;
  const client = options.client ?? new LiaraClient();
  const registry = options.registry ?? createLiaraToolRegistry(client);
  const steps: AssistantStep[] = [];
  const messages: ChatMessage[] = [{ role: "system", content: SYSTEM_PROMPT }, ...history.slice(-10).map((message) => ({ role: message.role, content: message.content.slice(0, 4_000) }) as ChatMessage)];

  for (let round = 0; round < MAX_STEPS; round++) {
    const reply = await callModel(fetcher, config, messages);
    if (!reply.tool_calls?.length) return { answer: (reply.content ?? "").trim() || "پاسخی از مدل دریافت نشد.", steps, model: config.model };
    messages.push({ role: "assistant", content: reply.content ?? null, tool_calls: reply.tool_calls });
    for (const call of reply.tool_calls) {
      const started = performance.now();
      let args: { appName?: string } = {};
      try { args = JSON.parse(call.function.arguments || "{}"); } catch { /* handled as invalid input below */ }
      let content: string;
      try {
        const result = await runReadOnlyTool(call.function.name, args, { registry, client });
        content = redactForModel(result);
        steps.push({ tool: call.function.name, appName: args.appName, ok: true, ms: Math.round(performance.now() - started) });
      } catch (error) {
        const message = error instanceof LiaraError ? error.userMessage : error instanceof Error ? error.message.slice(0, 200) : "Tool failed.";
        content = JSON.stringify({ error: true, message });
        steps.push({ tool: call.function.name, appName: args.appName, ok: false, ms: Math.round(performance.now() - started), note: message });
      }
      messages.push({ role: "tool", tool_call_id: call.id, content });
    }
  }
  return { answer: "برای پاسخ به این سؤال به مراحل بیشتری نیاز بود. سؤال را دقیق‌تر بپرسید یا نام اپ را مشخص کنید.", steps, model: config.model };
}

async function runReadOnlyTool(name: string, args: { appName?: string }, deps: { registry: ToolRegistry; client: LiaraClient }): Promise<unknown> {
  const appName = typeof args.appName === "string" ? args.appName.trim().toLowerCase() : "";
  const needsApp = !["list_apps", "list_plans"].includes(name);
  if (needsApp && !/^[a-z0-9][a-z0-9-]{1,62}$/u.test(appName)) throw new Error("A valid Liara app name is required.");
  switch (name) {
    case "list_apps": {
      const projects = ((await deps.client.listApps()).data.projects ?? []) as Array<Record<string, unknown>>;
      const apps = projects.map((project) => ({ name: project.project_id ?? project.name, status: project.status, type: project.type, planID: project.planID }));
      return { count: apps.length, apps, ...(apps.length ? {} : { note: "The request succeeded and this account has zero apps. Nothing is down; no app has been created yet." }) };
    }
    case "list_plans": {
      const catalog = await getLiaraPlanCatalog();
      return { stale: catalog.isStale, plans: catalog.projects.map(({ id, monthlyToman, cpuCores, memoryGb, diskGb }) => ({ id, monthlyToman, cpuCores, memoryGb, diskGb })) };
    }
    case "diagnose_app": {
      const result = analyzeEvidence(await collectDiagnosis(appName, deps.registry));
      return { finding: result.finding, limitations: result.evidence.limitations, probe: result.evidence.probe, metrics: result.evidence.metrics };
    }
    case "get_app_status": case "get_logs": case "get_metrics": case "get_release_history": case "http_probe":
      return deps.registry.execute(name, { projectId: appName, appName }, { actor: "assistant" });
    default:
      throw new Error(`Tool ${name} is not available to the assistant.`);
  }
}

/** Every tool result passes the same redaction as diagnosis logs before it can reach the model. */
export function redactForModel(value: unknown): string {
  const text = typeof value === "string" ? value : JSON.stringify(value ?? null);
  const chunks: string[] = [];
  for (let index = 0; index < text.length && chunks.join("").length < MAX_TOOL_CHARS; index += 1_800) chunks.push(redactDiagnosticLog(text.slice(index, index + 1_800)));
  return chunks.join("").slice(0, MAX_TOOL_CHARS);
}

async function callModel(fetcher: typeof fetch, config: NonNullable<ReturnType<typeof assistantConfig>>, messages: ChatMessage[]) {
  let response: Response;
  try {
    response = await fetcher(`${config.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${config.apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: config.model, messages, tools: TOOL_SPECS.map((spec) => ({ type: "function", function: spec })), tool_choice: "auto", temperature: 0.2 }),
      signal: AbortSignal.timeout(60_000),
    });
  } catch {
    throw new LiaraError("AI_NETWORK_ERROR", "اتصال به Liara AI برقرار نشد. اینترنت سرور و آدرس LIARA_AI_BASE_URL را بررسی کنید.", true);
  }
  if (!response.ok) {
    const hint = response.status === 401 || response.status === 403 ? "کلید LIARA_AI_API_KEY معتبر نیست." : response.status === 402 ? "اعتبار سرویس هوش مصنوعی لیارا تمام شده است." : response.status === 404 ? "آدرس LIARA_AI_BASE_URL باید شکل https://ai.liara.ir/api/v1/<شناسه‌ی سرویس> داشته باشد (از صفحه‌ی سرویس هوش مصنوعی در کنسول) و نام مدل مثل openai/gpt-4o-mini باشد." : "سرویس هوش مصنوعی موقتاً پاسخ نداد.";
    throw new LiaraError(`AI_HTTP_${response.status}`, `Liara AI: HTTP ${response.status}. ${hint}`, response.status >= 500 || response.status === 429, response.status);
  }
  const data = await response.json() as { choices?: Array<{ message?: { content?: string | null; tool_calls?: Array<{ id: string; type: "function"; function: { name: string; arguments: string } }> } }> };
  const message = data.choices?.[0]?.message;
  if (!message) throw new LiaraError("AI_INVALID_RESPONSE", "Liara AI پاسخ قابل‌خواندنی برنگرداند.", true);
  return message;
}
