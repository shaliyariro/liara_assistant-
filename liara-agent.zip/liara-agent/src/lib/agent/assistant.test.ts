import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import Database from "better-sqlite3";
import { z } from "zod";
import { runAssistant, AssistantNotConfiguredError } from "./assistant";
import { createAuditStore, installAuditStoreForTests } from "../audit/sqlite";
import { ToolRegistry } from "../tools/registry";
import { defineTool } from "../tools/types";
import type { LiaraClient } from "../liara/client";

process.env.APPROVAL_SIGNING_SECRET = "assistant-test-key-0123456789abcdef0123456789abcdef";
const FAKE_SECRET = "sk_live_FAKE_9f8e7d6c5b4a";

const db = new Database(":memory:");
beforeAll(() => installAuditStoreForTests(createAuditStore(db)));
afterAll(() => { installAuditStoreForTests(undefined); db.close(); });

function registry() {
  const tools = new ToolRegistry();
  for (const name of ["get_app_status", "get_logs", "get_metrics", "get_release_history", "http_probe"]) {
    tools.register(defineTool({
      name, riskLevel: "green", requiresEnvelope: false,
      inputSchema: z.object({ projectId: z.string(), appName: z.string() }).strict(),
      describe: () => ({ action: name, consequence: "Read-only.", recommendation: "-", alternatives: [], reversible: true }),
      withinEnvelope: () => true,
      run: async () => name === "get_logs" ? { data: [{ values: [["1", `boot failed api_key=${FAKE_SECRET}`]] }] } : { status: "running" },
    }));
  }
  return tools;
}

function modelReplies(...messages: Array<Record<string, unknown>>) {
  const bodies: Array<{ tools: Array<{ function: { name: string } }>; messages: unknown[] }> = [];
  const fetcher = vi.fn(async (_url: string, init?: RequestInit) => {
    bodies.push(JSON.parse(String(init?.body)));
    return Response.json({ choices: [{ message: messages[bodies.length - 1] }] });
  });
  return { fetcher: fetcher as unknown as typeof fetch, bodies };
}

const call = (id: string, name: string, args: object) => ({ id, type: "function", function: { name, arguments: JSON.stringify(args) } });

describe("Liara AI assistant", () => {
  it("refuses to run without server configuration", async () => {
    delete process.env.LIARA_AI_BASE_URL;
    await expect(runAssistant([{ role: "user", content: "hi" }])).rejects.toBeInstanceOf(AssistantNotConfiguredError);
  });

  it("offers only read-only tools, redacts tool output, and blocks write tools the model invents", async () => {
    process.env.LIARA_AI_BASE_URL = "https://ai.example.test/v1";
    process.env.LIARA_AI_API_KEY = "ai-key";
    process.env.LIARA_AI_MODEL = "test-model";
    const { fetcher, bodies } = modelReplies(
      { content: null, tool_calls: [call("a", "get_logs", { appName: "shop" }), call("b", "restart_app", { appName: "shop" }), call("c", "delete_app", { appName: "shop" })] },
      { content: "خلاصه: بوت ناموفق است. ⭐ از بخش عیب‌یابی env را ست کنید." },
    );
    const reply = await runAssistant([{ role: "user", content: "چرا shop بالا نمی‌آید؟" }], { fetcher, registry: registry(), client: {} as LiaraClient });

    const offered = bodies[0].tools.map((tool) => tool.function.name);
    expect(offered).not.toEqual(expect.arrayContaining(["restart_app"]));
    for (const name of offered) expect(["list_apps", "diagnose_app", "get_app_status", "get_logs", "get_metrics", "get_release_history", "http_probe", "list_plans"]).toContain(name);

    expect(reply.steps).toEqual([
      expect.objectContaining({ tool: "get_logs", ok: true }),
      expect.objectContaining({ tool: "restart_app", ok: false }),
      expect.objectContaining({ tool: "delete_app", ok: false }),
    ]);
    expect(JSON.stringify(bodies[1].messages)).not.toContain(FAKE_SECRET);
    expect(JSON.stringify(bodies[1].messages)).toContain("[REDACTED]");
    expect(reply.answer).toContain("⭐");
  });
});
