import "server-only";
import { executeWithApproval } from "@/lib/approval/gate";
import { ToolRegistry } from "@/lib/tools/registry";
import type { ToolExecutionContext } from "@/lib/tools/types";
import { resolveToolExecutionContext } from "@/lib/tools/context";
import { ApprovalRequiredError, EnvelopeRequiredError } from "@/lib/approval/gate";
import { LiaraError } from "@/lib/liara/errors";
import { ToolInputError } from "@/lib/tools/types";

export type LLMMessage = { role: "system" | "user" | "assistant" | "tool"; content: string; name?: string };
export type ToolCall = { name: string; input: unknown };
export type ModelTurn = { text?: string; toolCalls?: ToolCall[] };
export type ToolDescription = { name: string; riskLevel: "green" | "red" };

export interface LLMProvider {
  next(messages: LLMMessage[], tools: ReadonlyArray<ToolDescription>, signal?: AbortSignal): Promise<ModelTurn>;
}

export type AgentOptions = {
  provider: LLMProvider;
  registry: ToolRegistry;
  resolveExecutionContext?: (toolName: string, input: unknown) => Promise<ToolExecutionContext> | ToolExecutionContext;
  maxSteps?: number;
  signal?: AbortSignal;
};

/** Iterative server-side tool-use loop. Tool risk is always read from the registry. */
export async function* runAgentLoop(messages: LLMMessage[], options: AgentOptions): AsyncIterable<string> {
  const { provider, registry, signal } = options;
  const maxSteps = options.maxSteps ?? 8;
  const history = [...messages];

  for (let step = 0; step < maxSteps; step++) {
    if (signal?.aborted) return;
    const turn = await provider.next(history, registry.list(), signal);
    if (turn.text) yield turn.text;
    if (!turn.toolCalls?.length) return;

    history.push({ role: "assistant", content: turn.text ?? "" });
    for (const call of turn.toolCalls) {
      if (signal?.aborted) return;
      const tool = registry.get(call.name);
      const context = await options.resolveExecutionContext?.(call.name, call.input) ?? resolveToolExecutionContext(call.input);
      try {
        const result = await executeWithApproval(tool, call.input, context);
        const description = tool.describe(tool.inputSchema.parse(call.input));
        yield `✓ انجام شد: ${description.action}`;
        history.push({ role: "tool", name: call.name, content: JSON.stringify(result) });
      } catch (error) {
        const message = error instanceof LiaraError || error instanceof ApprovalRequiredError || error instanceof EnvelopeRequiredError || error instanceof ToolInputError
          ? error.message
          : "اقدام انجام نشد. جزئیات حساس پنهان شدند.";
        yield `⚠ ${message}`;
        history.push({ role: "tool", name: call.name, content: JSON.stringify({ error: true, message }) });
      }
    }
  }

  throw new Error(`Agent exceeded its ${maxSteps}-step tool-use limit.`);
}
