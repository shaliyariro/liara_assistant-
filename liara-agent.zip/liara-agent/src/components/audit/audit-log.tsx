"use client";

import { useEffect, useState } from "react";
import type { AuditEntry } from "@/lib/audit";

export function AuditLog({ initialEntries = [] }: { initialEntries?: AuditEntry[] }) {
  const [entries, setEntries] = useState(initialEntries);
  useEffect(() => {
    let active = true;
    const refresh = () => fetch("/api/audit", { cache: "no-store" })
      .then((response) => response.ok ? response.json() as Promise<{ entries: AuditEntry[] }> : Promise.reject(new Error("Audit log request failed.")))
      .then((payload) => { if (active) setEntries(payload.entries); })
      .catch(() => undefined);
    void refresh();
    window.addEventListener("hitl:audit-updated", refresh);
    return () => { active = false; window.removeEventListener("hitl:audit-updated", refresh); };
  }, []);

  return (
    <section aria-labelledby="audit-heading" className="rounded-2xl border border-slate-200 bg-white">
      <div className="border-b border-slate-100 px-5 py-4">
        <h2 id="audit-heading" className="font-bold text-slate-950">دفترچه‌ی عملیات</h2>
        <p className="mt-1 text-xs text-slate-500">اقدام‌ها با پارامترهای ماسک‌شده ثبت می‌شوند.</p>
      </div>
      {entries.length === 0 ? (
        <p className="px-5 py-8 text-sm text-slate-500">هنوز اقدامی ثبت نشده است.</p>
      ) : (
        <ol className="divide-y divide-slate-100">
          {entries.map((entry) => (
            <li key={entry.id ?? `${entry.toolName}-${entry.timestamp}`} className="space-y-2 px-5 py-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span aria-label={entry.riskLevel === "red" ? "حساس" : "خودکار"} className={entry.riskLevel === "red" ? "h-2.5 w-2.5 rounded-full bg-rose-600" : "h-2.5 w-2.5 rounded-full bg-teal-600"} />
                  <span className="text-sm font-semibold text-slate-900">{entry.toolName}</span>
                </div>
                <time className="text-xs tabular-nums text-slate-500" dateTime={entry.timestamp}>{new Date(entry.timestamp).toLocaleString("fa-IR")}</time>
              </div>
              <p className="text-sm text-slate-700">{entry.userMessage ?? (entry.outcome === "success" ? "انجام شد." : "اقدام انجام نشد.")}</p>
              <details className="text-xs text-slate-500">
                <summary className="w-fit cursor-pointer py-1">جزئیات ماسک‌شده</summary>
                <pre dir="ltr" className="mt-2 max-h-40 overflow-auto rounded-lg bg-slate-50 p-3 text-left">{JSON.stringify(entry.maskedInput, null, 2)}</pre>
              </details>
              {entry.reversible && entry.undoAction && <button type="button" data-undo-action={entry.undoAction} className="rounded-md border border-slate-300 px-3 py-1.5 text-xs hover:bg-slate-50">برگردان</button>}
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
