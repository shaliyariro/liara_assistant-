"use client";

import { useState } from "react";
import type { RepoAnalysis } from "@/lib/repo/analyze-repo";
import type { DeployEvent } from "@/lib/deploy/pipeline";
import type { PlanAnswers } from "@/lib/plan-rules";
import { ProgressCard } from "./progress-card";

type PlanOption = { role: "economic" | "recommended" | "safer"; title: string; plan: { id: string; monthlyToman: number; resourceMonthlyToman?: number; bundlePlanID?: string; bundleMonthlyToman?: number; cpuCores: number; memoryGb: number; diskGb: number }; services: Array<{ name: string; plan: { id: string; monthlyToman: number; cpuCores: number; memoryGb: number; diskGb: number } }>; monthlyToman: number };
type DeploymentSource = { file: File | null; githubUrl: string };
type QuoteResponse = { token: string; quote: { id: string; projectId: string; appName: string; platform: string; port: number; expiresAt: number; plan: PlanOption["plan"]; rationale: string } };
type TicketResponse = { ticket: string; projectId: string; appName: string; sourceName: string; platform: string; port: number; environmentKeys: string[] };

export function DeploymentPanel({ analysis, answers, options, source }: { analysis: RepoAnalysis; answers: PlanAnswers; options: PlanOption[]; source: DeploymentSource }) {
  const [planID, setPlanID] = useState(options.find(({ role }) => role === "recommended")?.plan.id ?? options[0]?.plan.id ?? "");
  const [quote, setQuote] = useState<QuoteResponse | null>(null);
  const [ticket, setTicket] = useState<TicketResponse | null>(null);
  const [manualMode, setManualMode] = useState(false);
  const [manualValues, setManualValues] = useState<Record<string, string>>({});
  const [events, setEvents] = useState<DeployEvent[]>([]);
  const [running, setRunning] = useState(false);
  const [complete, setComplete] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function prepareQuote() {
    setBusy(true); setError(""); setQuote(null); setTicket(null); setEvents([]); setComplete(false);
    try {
      const response = await fetch("/api/deploy/quote", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ analysis, answers, planID }) });
      const result = await response.json() as QuoteResponse & { error?: string };
      if (!response.ok) throw new Error(result.error ?? "پیش‌فاکتور دیپلوی آماده نشد.");
      setQuote(result);
      window.dispatchEvent(new CustomEvent("demo-approval-card", { detail: { scenario: "A", id: "cost" } }));
    } catch (caught) { setError(caught instanceof Error ? caught.message : "پیش‌فاکتور آماده نشد."); }
    finally { setBusy(false); }
  }

  async function approveCost() {
    if (!quote) return;
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/deploy/approve", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ quoteToken: quote.token }) });
      const result = await response.json() as TicketResponse & { error?: string };
      if (!response.ok) throw new Error(result.error ?? "چارچوب هزینه ذخیره نشد.");
      setTicket(result);
      if (result.environmentKeys.length > 0) window.dispatchEvent(new CustomEvent("demo-approval-card", { detail: { scenario: "A", id: "env-read" } }));
      if (!result.environmentKeys.length) await deploy(result, "deny", {});
    } catch (caught) { setError(caught instanceof Error ? caught.message : "چارچوب هزینه ذخیره نشد."); }
    finally { setBusy(false); }
  }

  async function deploy(approved = ticket, envChoice: "once" | "project" | "deny" = "deny", manual: Record<string, string> = {}) {
    if (!approved || running) return;
    setError(""); setRunning(true); setEvents([]); setComplete(false); setManualMode(false);
    const form = new FormData();
    form.set("ticket", approved.ticket);
    form.set("projectId", approved.projectId);
    form.set("appName", approved.appName);
    form.set("platform", approved.platform);
    form.set("port", String(approved.port));
    form.set("envChoice", envChoice);
    form.set("manualEnv", JSON.stringify(manual));
    if (source.file) form.set("file", source.file);
    else form.set("githubUrl", source.githubUrl);
    try {
      const response = await fetch("/api/deploy/stream", { method: "POST", body: form });
      if (!response.ok || !response.body) {
        const result = await response.json() as { error?: string };
        throw new Error(result.error ?? "درخواست دیپلوی پذیرفته نشد.");
      }
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let succeeded = false;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const frames = buffer.split("\n\n");
        buffer = frames.pop() ?? "";
        for (const frame of frames) {
          const payload = frame.split("\n").find((line) => line.startsWith("data: "))?.slice(6);
          if (!payload) continue;
          const event = JSON.parse(payload) as DeployEvent;
          setEvents((current) => [...current, event]);
          if (event.type === "complete" && event.httpStatus === 200) succeeded = true;
        }
      }
      if (succeeded) {
        setComplete(true);
        window.dispatchEvent(new CustomEvent("demo-scenario-complete", { detail: { scenario: "A" } }));
      }
      else setError("دیپلوی با health check موفق تمام نشد؛ نتیجه‌ی عیب‌یابی در کارت نمایش داده شده است.");
    } catch (caught) { setError(caught instanceof Error ? caught.message : "اتصال دیپلوی قطع شد؛ وضعیت را در پنل Liara بررسی کن."); }
    finally { setRunning(false); }
  }

  return <div className="space-y-4 rounded-2xl border border-slate-200 bg-slate-50 p-4 sm:p-5">
    {!quote && !ticket && <div className="grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
      <label className="text-sm font-medium text-slate-700">پلن برای دیپلوی
        <select value={planID} onChange={(event) => setPlanID(event.target.value)} className="mt-1 min-h-11 w-full rounded-xl border border-slate-300 bg-white px-3">
          {options.map((option) => <option key={`${option.role}-${option.plan.id}`} value={option.plan.id}>{option.title} · {option.plan.id} · {money(option.monthlyToman)} تومان/ماه</option>)}
        </select>
      </label>
      <button type="button" disabled={busy || !planID} onClick={prepareQuote} className="min-h-11 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-50">{busy ? "در حال بررسی…" : "آماده‌سازی دیپلوی"}</button>
    </div>}

    {quote && !ticket && <section dir="rtl" className="rounded-2xl border border-rose-300 bg-white p-5 sm:p-6">
      <p className="text-xs font-semibold text-rose-800">تأیید هزینه و پلن · اقدام حساس</p>
      <h2 className="mt-2 text-lg font-bold text-slate-950">اپ {quote.quote.appName} روی پلن {quote.quote.plan.id}</h2>
      <p className="mt-2 rounded-lg bg-slate-50 p-3 text-sm leading-6 text-slate-700"><strong>Why this plan:</strong> {quote.quote.rationale}</p>
      <p className="mt-2 text-sm leading-6 text-slate-700">پلن زیرساخت + بسته‌ی {quote.quote.plan.bundlePlanID} انتخاب شده از کاتالوگ زنده‌ی Liara.</p>
      <div className="mt-4 divide-y divide-slate-100 rounded-xl border border-slate-200 px-4">
        <p className="flex justify-between gap-3 py-3 text-sm"><span>منابع پلن · {quote.quote.plan.cpuCores} CPU · {quote.quote.plan.memoryGb} GB RAM · {quote.quote.plan.diskGb} GB SSD</span><strong>{money(quote.quote.plan.resourceMonthlyToman ?? quote.quote.plan.monthlyToman)} تومان/ماه</strong></p>
        <p className="flex justify-between gap-3 py-3 text-sm"><span>بسته‌ی امکانات · {quote.quote.plan.bundlePlanID}</span><strong>{money(quote.quote.plan.bundleMonthlyToman ?? 0)} تومان/ماه</strong></p>
      </div>
      <p className="mt-4 text-sm leading-6 text-slate-700">پیامد: با تأیید، یک اپ با نام ثابت ساخته یا اپ قبلی همان ریپو دوباره استفاده می‌شود؛ سپس env، سورس و release به‌طور خودکار تنظیم می‌شوند. مصرف متغیر ممکن است جدا باشد.</p>
      <p className="mt-2 text-base font-bold text-slate-950">جمع ماهانه: {money(quote.quote.plan.monthlyToman)} تومان</p>
      <p className="mt-2 text-xs leading-5 text-slate-500">This approval covers the app plan and its required bundle. Suggested database or Redis services are not provisioned by this F02 flow.</p>
      <div className="mt-4 flex flex-wrap gap-2"><button type="button" disabled={busy} onClick={approveCost} className="min-h-11 rounded-xl bg-rose-700 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-50">{busy ? "در حال ثبت تأیید…" : "تأیید و ادامه"}</button><button type="button" disabled={busy} onClick={() => setQuote(null)} className="min-h-11 rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-medium">لغو</button></div>
    </section>}

    {ticket && !running && !complete && events.length === 0 && ticket.environmentKeys.length > 0 && !manualMode && <section dir="rtl" className="rounded-2xl border border-amber-300 bg-white p-5">
      <p className="text-xs font-semibold text-amber-900">اجازه‌ی خواندن env · اقدام حساس</p>
      <h2 className="mt-2 text-lg font-bold text-slate-950">{ticket.environmentKeys.length} نام کلید از `.env.example` پیدا شد</h2>
      <p className="mt-2 text-sm leading-6 text-slate-600">با اجازه، سرور فقط مقدارهای هم‌نام را از `.env` داخل سورس می‌خواند. مقدار خام به مرورگر یا LLM فرستاده نمی‌شود؛ در کارت فقط ماسک می‌بینی.</p>
      <p className="mt-2 text-xs text-slate-500">Generated keys such as SECRET_KEY are created on the server when their field is left blank.</p>
      <div className="mt-4 flex flex-wrap gap-2"><button type="button" disabled={busy} onClick={() => void deploy(ticket, "once")} className="min-h-11 rounded-xl bg-amber-800 px-4 py-2.5 text-sm font-semibold text-white">فقط یک‌بار</button><button type="button" disabled={busy} onClick={() => void deploy(ticket, "project")} className="min-h-11 rounded-xl border border-amber-500 px-4 py-2.5 text-sm font-semibold text-amber-950">برای این پروژه</button><button type="button" disabled={busy} onClick={() => setManualMode(true)} className="min-h-11 rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-800">نه، دستی وارد می‌کنم</button></div>
    </section>}

    {ticket && !running && !complete && (manualMode || ticket.environmentKeys.length === 0) && <section dir="rtl" className="rounded-2xl border border-slate-200 bg-white p-5">
      <h2 className="text-lg font-bold text-slate-950">مقداردهی دستی env</h2><p className="mt-1 text-sm text-slate-600">مقدارها از فیلد رمز عبور مستقیم به Liara فرستاده می‌شوند و در مسیر LLM نیستند.</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">{ticket.environmentKeys.map((key) => <label key={key} dir="ltr" className="text-left text-sm font-medium text-slate-700">{key}<input type="password" autoComplete="new-password" value={manualValues[key] ?? ""} onChange={(event) => setManualValues((current) => ({ ...current, [key]: event.target.value }))} className="mt-1 min-h-11 w-full rounded-xl border border-slate-300 px-3 text-left" /></label>)}</div>
      <button type="button" disabled={busy} onClick={() => void deploy(ticket, "deny", manualValues)} className="mt-4 min-h-11 rounded-xl bg-teal-800 px-4 py-2.5 text-sm font-semibold text-white">شروع دیپلوی با ورود دستی</button>
    </section>}

    {(running || events.length > 0 || complete) && <ProgressCard events={events} running={running} complete={complete} />}
    {complete && events.find((event) => event.type === "complete")?.type === "complete" && <p role="status" className="rounded-xl border border-teal-300 bg-teal-50 p-4 text-sm font-semibold text-teal-950">آنلاین ✅ · health check واقعی HTTP 200 · <a className="underline" href={(events.find((event) => event.type === "complete") as Extract<DeployEvent, { type: "complete" }>).url} target="_blank" rel="noreferrer" dir="ltr">{(events.find((event) => event.type === "complete") as Extract<DeployEvent, { type: "complete" }>).url}</a></p>}
    {error && <p role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-900">{error}</p>}
  </div>;
}

function money(value: number) { return new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0 }).format(value); }
