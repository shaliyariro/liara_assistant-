import { randomUUID } from "node:crypto";
import { buildApprovalCard, type ApprovalCardModel } from "@/lib/approval/cards";
import { getAuditStore } from "@/lib/audit/sqlite";
import { createLiaraToolRegistry } from "@/lib/tools/liara-tools";
import { approveToolAction, chooseAlternativeAction, rejectToolAction } from "@/app/actions/hitl";

type ServerAction = (formData: FormData) => void | Promise<void>;

/** Builds the red card on the server from the registered tool's schema and metadata. */
export function ToolApprovalCard({ toolName, input, rationale, approvalId }: {
  toolName: string;
  input: unknown;
  rationale?: string;
  approvalId?: string;
}) {
  const tool = createLiaraToolRegistry().get(toolName);
  const parsed = tool.inputSchema.parse(input);
  const projectId = parsed && typeof parsed === "object" && "projectId" in parsed && typeof parsed.projectId === "string" ? parsed.projectId : undefined;
  const envelope = projectId ? getAuditStore().getApprovedEnvelope<import("@/lib/approval/gate").ApprovedEnvelope>(projectId) : undefined;
  const model = buildApprovalCard(tool, parsed, { envelope, rationale });
  if (!model) return null;
  const id = approvalId ?? randomUUID();
  return (
    <ApprovalCard
      model={model}
      approvalId={id}
      onApprove={approveToolAction.bind(null, toolName, parsed)}
      onAlternative={chooseAlternativeAction.bind(null, toolName, parsed, model.alternatives[0] ?? "Explain only")}
      onReject={rejectToolAction.bind(null, toolName, parsed)}
    />
  );
}

export function ApprovalCard({
  model,
  approvalId,
  onApprove,
  onAlternative,
  onReject,
}: {
  model: ApprovalCardModel;
  approvalId: string;
  onApprove: ServerAction;
  onAlternative: ServerAction;
  onReject: ServerAction;
}) {
  return (
    <article aria-labelledby={`approval-${approvalId}`} className="overflow-hidden rounded-2xl border border-rose-300 bg-white shadow-[0_14px_40px_-28px_rgba(127,29,29,.55)]">
      <div className="border-b border-rose-100 bg-rose-50/70 px-6 py-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-rose-800">نیازمند تأیید شما</p>
            <h2 id={`approval-${approvalId}`} className="mt-2 text-lg font-bold text-slate-950">{model.action}</h2>
          </div>
          <span className="rounded-full border border-rose-200 bg-white px-3 py-1 text-xs font-medium text-rose-800">اقدام حساس</span>
        </div>
      </div>

      <div className="space-y-5 px-6 py-5">
        {model.rationale && (
          <section aria-label="دلیل پیشنهادی" className="rounded-xl border border-dashed border-sky-300 bg-sky-50/60 p-4">
            <h3 className="text-xs font-semibold text-sky-900">چرا؟ · دلیل پیشنهادی عامل</h3>
            <p className="mt-2 text-sm leading-7 text-sky-950">{model.rationale}</p>
          </section>
        )}

        {model.costLines && (
          <section aria-label="هزینه‌ی ماهانه" className="divide-y divide-slate-100 rounded-xl border border-slate-200 px-4">
            {model.costLines.map((line, index) => (
              <div key={`${line.kind}-${line.name}-${index}`} className="flex items-center justify-between gap-4 py-3 text-sm">
                <span className="text-slate-700">{line.name}</span>
                <span className="font-medium tabular-nums text-slate-950">{money(line.monthlyCost)} تومان / ماه</span>
              </div>
            ))}
          </section>
        )}

        <div className="grid gap-4 sm:grid-cols-2">
          <section>
            <h3 className="text-xs font-semibold text-slate-500">پیامد</h3>
            <p className="mt-2 text-sm leading-7 text-slate-800">{model.consequence}</p>
            {model.monthlyCost !== undefined && !model.costLines && <p className="mt-2 text-sm font-semibold text-slate-950">{money(model.monthlyCost)} تومان در ماه</p>}
          </section>
          <section className="rounded-xl bg-teal-50 p-4">
            <h3 className="text-xs font-semibold text-teal-900">⭐ پیشنهاد من</h3>
            <p className="mt-2 text-sm leading-7 text-teal-950">{model.recommendation}</p>
          </section>
        </div>

        {model.costLines && <p className="text-xs leading-6 text-slate-500">جمع ماهانه: <strong className="text-slate-800">{money(model.monthlyCost ?? 0)} تومان</strong>. هزینه‌ی مصرف متغیر ممکن است جداگانه محاسبه شود.</p>}
        <div className="flex flex-wrap gap-2" aria-label="گزینه‌ها">
          <form action={onApprove}>
            <input type="hidden" name="approvalId" value={approvalId} />
            <button className="rounded-lg bg-rose-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-rose-800 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-rose-800">تأیید</button>
          </form>
          <form action={onAlternative}>
            <input type="hidden" name="approvalId" value={approvalId} />
            <button className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-800 hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-700">{model.alternatives[0] ?? "نمایش جایگزین"}</button>
          </form>
          <form action={onReject}>
            <input type="hidden" name="approvalId" value={approvalId} />
            <button className="rounded-lg px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-700">نه</button>
          </form>
        </div>
      </div>
    </article>
  );
}

function money(amount: number) {
  return new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0 }).format(amount);
}
