"use client";

import { useMemo, useState, type FormEvent } from "react";
import { Renderer } from "@openuidev/react-lang";
import { AlertTriangle, ArrowUpRight, FileArchive, GitBranch, LoaderCircle, Search, Upload } from "lucide-react";
import { buildPlanQuestions } from "@/lib/plan-rules";
import type { RepoAnalysis } from "@/lib/repo/analyze-repo";
import type { PlanAnswers } from "@/lib/plan-rules";
import { planLibrary, projectLibrary, questionLibrary, recommendationLibrary } from "@/lib/openui-library";
import type { Recommendation } from "@/lib/recommendations/engine";
import { DeploymentPanel } from "./deployment-panel";

type PlanResult = {
  options: Array<{ role: "economic" | "recommended" | "safer"; title: string; plan: { id: string; monthlyToman: number; resourceMonthlyToman?: number; bundlePlanID?: string; bundleMonthlyToman?: number; cpuCores: number; memoryGb: number; diskGb: number; region: string; supportedEngines: string[] }; services: Array<{ name: string; plan: { id: string; monthlyToman: number; cpuCores: number; memoryGb: number; diskGb: number; region: string; supportedEngines: string[] } }>; monthlyToman: number; unsuitableWhen: string }>;
  reason: string;
  recommendations: Recommendation[];
  catalog: { source: "live" | "cache"; isStale: boolean; updatedAt: string };
  limitations: Array<{ title: string; detail: string; manualStep: string }>;
  balance: { current: number | null; rechargeUrl: string; userMustRecharge: true };
};

export function RepoAnalysisFlow() {
  const [githubUrl, setGithubUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState<RepoAnalysis | null>(null);
  const [planResult, setPlanResult] = useState<PlanResult | null>(null);
  const [answers, setAnswers] = useState<PlanAnswers | null>(null);
  const [error, setError] = useState("");
  const [stage, setStage] = useState<"idle" | "analyzing" | "plans">("idle");

  const questions = useMemo(() => analysis ? buildPlanQuestions(analysis) : [], [analysis]);

  async function analyze(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setAnalysis(null);
    setPlanResult(null);
    setStage("analyzing");
    const form = new FormData();
    if (githubUrl.trim()) form.set("githubUrl", githubUrl.trim());
    else if (file) form.set("file", file);
    else { setError("لینک گیت‌هاب یا فایل ZIP را انتخاب کن."); setStage("idle"); return; }

    try {
      const response = await fetch("/api/analyze", { method: "POST", body: form });
      const payload = await response.json() as { analysis?: RepoAnalysis; error?: string };
      if (!response.ok || !payload.analysis) throw new Error(payload.error ?? "تحلیل پروژه انجام نشد.");
      setAnalysis(payload.analysis);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "تحلیل پروژه انجام نشد. دوباره تلاش کن.");
    } finally { setStage("idle"); }
  }

  async function comparePlans(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!analysis) return;
    setError("");
    setStage("plans");
    const form = new FormData(event.currentTarget);
    const answers = {
      traffic: form.get("traffic"),
      priority: form.get("priority"),
      domain: form.get("domain"),
      ...(form.has("database") ? { database: form.get("database") } : {}),
    };
    setAnswers(answers as PlanAnswers);
    try {
      const response = await fetch("/api/plans", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ analysis, answers }) });
      const payload = await response.json() as PlanResult & { error?: string };
      if (!response.ok) throw new Error(payload.error ?? "دریافت پلن‌ها انجام نشد.");
      setPlanResult(payload);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "پیشنهاد پلن انجام نشد. دوباره تلاش کن.");
    } finally { setStage("idle"); }
  }

  return (
    <section className="space-y-5" aria-labelledby="analyze-heading">
      <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
        <div className="flex items-start gap-3">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-teal-50 text-teal-800"><Search size={20} aria-hidden="true" /></span>
          <div><p className="text-xs font-semibold text-teal-800">شروع راه‌اندازی</p><h2 id="analyze-heading" className="mt-1 text-xl font-bold text-slate-950">ریپو را بررسی کن</h2><p className="mt-1 text-sm leading-6 text-slate-600">لینک ریپوی عمومی گیت‌هاب یا ZIP حداکثر ۲۵ مگابایت بده. فایل .env خوانده نمی‌شود.</p></div>
        </div>
        <form onSubmit={analyze} className="mt-5 grid gap-3 sm:grid-cols-[1fr_auto]">
          <label className="block text-sm font-medium text-slate-700">
            لینک GitHub
            <span className="relative mt-1 block">
              <GitBranch size={17} aria-hidden="true" className="absolute right-3 top-3.5 text-slate-400" />
              <input value={githubUrl} onChange={(event) => { setGithubUrl(event.target.value); if (event.target.value) setFile(null); }} type="url" inputMode="url" placeholder="https://github.com/owner/repository" className="min-h-11 w-full rounded-xl border border-slate-300 bg-white py-2.5 pl-3 pr-10 text-left text-sm text-slate-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700" dir="ltr" />
            </span>
          </label>
          <button disabled={stage !== "idle"} className="mt-auto inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-teal-800 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-teal-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-800 disabled:cursor-wait disabled:opacity-60">
            {stage === "analyzing" ? <LoaderCircle size={17} className="animate-spin" aria-hidden="true" /> : <Search size={17} aria-hidden="true" />}
            {stage === "analyzing" ? "در حال بررسی…" : "تحلیل ریپو"}
          </button>
          <label className="flex min-h-11 cursor-pointer items-center gap-2 text-sm text-slate-600 sm:col-span-2">
            <FileArchive size={17} aria-hidden="true" className="text-slate-500" />
            <span>{file ? file.name : "یا فایل ZIP را انتخاب کن"}</span>
            <input type="file" accept=".zip,application/zip" className="sr-only" onChange={(event) => { const next = event.target.files?.[0] ?? null; setFile(next); if (next) setGithubUrl(""); }} />
            <Upload size={16} aria-hidden="true" className="text-teal-800" />
          </label>
        </form>
        {error && <p role="alert" className="mt-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-900">{error}</p>}
      </div>

      {analysis && (
        <>
          <Renderer response={openUi("ProjectCard", projectCardProps(analysis))} library={projectLibrary} isStreaming={false} />
          {!planResult && <form onSubmit={comparePlans} className="space-y-3">
            <div className="flex flex-wrap items-end justify-between gap-2 px-1"><div><p className="text-xs font-semibold text-slate-500">مرحله‌ی بعد · حداکثر ۴ سؤال</p><h2 className="mt-1 text-lg font-bold text-slate-950">چند انتخاب کوتاه</h2></div><span className="text-xs text-slate-500">پاسخ‌های پیشنهادی از قبل انتخاب شده‌اند</span></div>
            {questions.map((question) => <Renderer key={question.id} response={openUi("QuestionCard", question)} library={questionLibrary} isStreaming={false} />)}
            <button disabled={stage !== "idle"} className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-teal-800 px-5 py-3 text-sm font-bold text-white transition hover:bg-teal-900 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-800 disabled:opacity-60 sm:w-auto">
              {stage === "plans" ? <LoaderCircle size={18} aria-hidden="true" className="animate-spin" /> : <ArrowUpRight size={18} aria-hidden="true" />}
              {stage === "plans" ? "در حال دریافت پلن‌های لیارا…" : "مقایسه‌ی پلن‌ها"}
            </button>
          </form>}
        </>
      )}

      {planResult && (
        <div className="space-y-4">
          {planResult.limitations.map((notice, index) => <aside key={`${notice.title}-${index}`} role="note" className="rounded-2xl border border-amber-300 bg-amber-50 p-5 text-amber-950">
            <div className="flex items-start gap-3"><AlertTriangle size={19} aria-hidden="true" className="mt-0.5 shrink-0" /><div><h2 className="font-semibold">{notice.title}</h2><p className="mt-2 text-sm leading-6">{notice.detail}</p><p className="mt-2 text-sm"><strong>راه دستی:</strong> {notice.manualStep}</p></div></div>
          </aside>)}
          {planResult.options.length > 0 && <Renderer response={openUi("PlanCard", { options: planResult.options, reason: planResult.reason, isStale: planResult.catalog.isStale, updatedAt: planResult.catalog.updatedAt })} library={planLibrary} isStreaming={false} />}
          {planResult.recommendations.map((recommendation) => <Renderer key={recommendation.id} response={openUi("RecommendationCard", recommendation)} library={recommendationLibrary} isStreaming={false} />)}
          {analysis && answers && planResult.options.length > 0 && <DeploymentPanel analysis={analysis} answers={answers} options={planResult.options} source={{ file, githubUrl }} />}
          <aside className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-5">
            <div><h2 className="text-sm font-bold text-slate-950">بررسی موجودی حساب</h2><p className="mt-1 max-w-2xl text-sm leading-6 text-slate-600">{planResult.balance.current === null ? "موجودی از این API قابل‌خواندن نیست. قبل از خرید، خودت در پنل بررسی و در صورت نیاز حساب را شارژ کن." : `موجودی گزارش‌شده: ${money(planResult.balance.current)} تومان. شارژ را خودت در پنل انجام بده.`}</p></div>
            <a href={planResult.balance.rechargeUrl} target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-800 transition hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700">بازکردن پنل لیارا <ArrowUpRight size={16} aria-hidden="true" /></a>
          </aside>
          <button type="button" onClick={() => { setAnalysis(null); setPlanResult(null); setGithubUrl(""); setFile(null); }} className="min-h-11 rounded-xl px-4 text-sm font-medium text-slate-600 underline decoration-slate-300 underline-offset-4 hover:text-slate-950">تحلیل پروژه‌ی دیگری</button>
        </div>
      )}
    </section>
  );
}

function projectCardProps(analysis: RepoAnalysis) {
  const { sourceName, language, framework, hasDockerfile, databases, usesRedis, workers, cron, environmentKeys, fileCount, sourceSizeMb, buildEstimateMb, findings } = analysis;
  return { sourceName, language, framework, hasDockerfile, databases, usesRedis, workers, cron, environmentKeys, fileCount, sourceSizeMb, buildEstimateMb, findings };
}

function openUi(component: string, props: unknown) { return `root = ${component}(${JSON.stringify(props)})`; }
function money(value: number) { return new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0 }).format(value); }
