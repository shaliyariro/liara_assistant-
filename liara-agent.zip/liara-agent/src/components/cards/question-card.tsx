"use client";

import { useState } from "react";

export type QuestionCardProps = {
  question: string;
  options: string[];
  recommendation: string;
};

export function QuestionCard({ question, options, recommendation }: QuestionCardProps) {
  const [selected, setSelected] = useState(recommendation);

  return (
    <section aria-label="پرسش" className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
      <h2 className="text-lg font-semibold">{question}</h2>
      <p className="mt-2 text-sm text-slate-500">پیشنهاد من: {recommendation}</p>
      <div className="mt-5 flex flex-wrap gap-3">
        {options.map((option) => (
          <button
            key={option}
            type="button"
            aria-pressed={selected === option}
            onClick={() => setSelected(option)}
            className={`rounded-xl border px-4 py-2 text-sm transition ${selected === option ? "border-teal-700 bg-teal-50 text-teal-900" : "border-slate-200 hover:border-slate-400"}`}
          >
            {option}
          </button>
        ))}
      </div>
    </section>
  );
}
