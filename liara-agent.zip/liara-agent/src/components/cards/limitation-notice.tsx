export function LimitationNotice({ title, detail, manualStep }: { title: string; detail: string; manualStep: string }) {
  return (
    <aside role="note" className="rounded-xl border border-amber-300 bg-amber-50 p-5 text-amber-950">
      <h2 className="font-semibold">{title}</h2>
      <p className="mt-2 text-sm leading-7">{detail}</p>
      <p className="mt-2 text-sm"><strong>راه دستی:</strong> {manualStep}</p>
    </aside>
  );
}
