"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { LimitationNotice } from "./limitation-notice";

type Step = { tool: string; appName?: string; ok: boolean; ms: number; note?: string };
type Turn = { role: "user" | "assistant"; content: string; steps?: Step[] };
type Limitation = { title: string; detail: string; manualStep: string };

const TOOL_LABELS: Record<string, string> = {
  list_apps: "فهرست اپ‌ها", diagnose_app: "عیب‌یابی کامل", get_app_status: "وضعیت اپ", get_logs: "لاگ‌ها",
  get_metrics: "CPU/RAM", get_release_history: "تاریخچه‌ی release", http_probe: "تست HTTP", list_plans: "پلن‌ها و قیمت",
};

const EXAMPLES = ["اپ‌هایم در چه وضعیتی هستند؟", "چرا سایتم کند شده؟", "برای یک سایت Next.js کوچک کدام پلن مناسب است؟"];

export function AssistantPanel() {
  const [turns, setTurns] = useState<Turn[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [limitation, setLimitation] = useState<Limitation>();
  const [status, setStatus] = useState<{ configured: boolean; model: string | null }>();
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { void fetch("/api/assistant").then((response) => response.json()).then(setStatus).catch(() => undefined); }, []);
  useEffect(() => { endRef.current?.scrollIntoView({ block: "nearest" }); }, [turns, busy]);

  async function send(event?: FormEvent<HTMLFormElement>, text = input) {
    event?.preventDefault();
    const question = text.trim();
    if (!question || busy) return;
    const next: Turn[] = [...turns, { role: "user", content: question }];
    setTurns(next); setInput(""); setBusy(true); setError(""); setLimitation(undefined);
    try {
      const response = await fetch("/api/assistant", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages: next.map(({ role, content }) => ({ role, content })) }) });
      const payload = await response.json() as { answer?: string; steps?: Step[]; error?: string; limitation?: Limitation };
      if (!response.ok || !payload.answer) { setError(payload.error ?? "پاسخی دریافت نشد."); setLimitation(payload.limitation); return; }
      setTurns([...next, { role: "assistant", content: payload.answer, steps: payload.steps }]);
    } catch { setError("ارتباط با سرور برقرار نشد."); }
    finally { setBusy(false); }
  }

  return <section className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 sm:p-6" aria-label="Assistant">
    <header className="flex flex-wrap items-start justify-between gap-2">
      <div>
        <h2 className="text-xl font-bold text-slate-950">از دستیار بپرس</h2>
        <p className="mt-1 text-sm leading-6 text-slate-600">دستیار فقط می‌خواند و توضیح می‌دهد؛ هر تغییری (ری‌استارت، پلن، env، دیپلوی) با کارت تأیید شما انجام می‌شود.</p>
      </div>
      {status && <span className={`rounded-full px-3 py-1 text-xs font-semibold ${status.configured ? "bg-teal-50 text-teal-800" : "bg-amber-50 text-amber-900"}`} dir="ltr">{status.configured ? `Liara AI · ${status.model}` : "Liara AI: not configured"}</span>}
    </header>

    {turns.length === 0 && <div className="flex flex-wrap gap-2">{EXAMPLES.map((example) => <button key={example} type="button" disabled={busy} onClick={() => void send(undefined, example)} className="min-h-11 rounded-full border border-slate-300 px-4 text-sm text-slate-700 hover:bg-slate-50">{example}</button>)}</div>}

    <div className="space-y-3">
      {turns.map((turn, index) => <article key={index} className={turn.role === "user" ? "mr-auto max-w-[85%] rounded-2xl bg-teal-800 px-4 py-3 text-sm text-white" : "max-w-[95%] rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-7 text-slate-900"}>
        {turn.steps && turn.steps.length > 0 && <ul className="mb-2 flex flex-wrap gap-1.5" aria-label="ابزارهای اجراشده">{turn.steps.map((step, stepIndex) => <li key={stepIndex} title={step.note} className={`rounded-md px-2 py-0.5 text-xs ${step.ok ? "bg-white text-slate-600 ring-1 ring-slate-200" : "bg-rose-50 text-rose-800 ring-1 ring-rose-200"}`}>{step.ok ? "✓" : "⚠"} {TOOL_LABELS[step.tool] ?? step.tool}{step.appName ? ` · ${step.appName}` : ""} <span dir="ltr">{step.ms}ms</span></li>)}</ul>}
        {turn.role === "assistant" ? <FormattedAnswer text={turn.content} /> : <p className="whitespace-pre-wrap">{turn.content}</p>}
      </article>)}
      {busy && <p className="text-sm text-slate-500" role="status">دستیار در حال جمع‌آوری شواهد و فکر کردن است…</p>}
      <div ref={endRef} />
    </div>

    {error && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm text-rose-800">{error}</p>}
    {limitation && <LimitationNotice {...limitation} />}

    <form onSubmit={send} className="flex gap-2">
      <input value={input} onChange={(event) => setInput(event.target.value)} placeholder="مثلاً: اپ my-shop چرا خطای ۵۰۰ می‌دهد؟" className="min-h-11 flex-1 rounded-xl border border-slate-300 px-3 text-sm" maxLength={1_000} />
      <button disabled={busy || !input.trim()} className="min-h-11 rounded-lg bg-teal-800 px-5 text-sm font-semibold text-white disabled:opacity-50">بپرس</button>
    </form>
  </section>;
}

/** Minimal rendering for the model's markdown: **bold**, `code` and "- " bullet lines. No HTML is injected. */
function FormattedAnswer({ text }: { text: string }) {
  const inline = (line: string) => line.split(/(\*\*[^*]+\*\*|`[^`]+`)/gu).map((part, index) =>
    part.startsWith("**") && part.endsWith("**") ? <strong key={index}>{part.slice(2, -2)}</strong>
      : part.startsWith("`") && part.endsWith("`") ? <code key={index} dir="ltr" className="rounded bg-white px-1 text-xs ring-1 ring-slate-200">{part.slice(1, -1)}</code>
        : part);
  return <div className="space-y-1">{text.split(/\r?\n/u).map((line, index) => {
    if (!line.trim()) return <div key={index} className="h-2" />;
    const bullet = /^\s*[-*•]\s+/u.exec(line);
    return bullet ? <p key={index} className="pr-4 before:-mr-3 before:ml-1 before:content-['•']">{inline(line.slice(bullet[0].length))}</p> : <p key={index}>{inline(line.replace(/^#+\s*/u, ""))}</p>;
  })}</div>;
}
