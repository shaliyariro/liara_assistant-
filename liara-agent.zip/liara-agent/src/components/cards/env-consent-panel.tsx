"use client";

import { useEffect, useState } from "react";

type Consent = { allowForProject: boolean };

export function EnvConsentPanel() {
  const [projectId, setProjectId] = useState("local-project");
  const [consent, setConsent] = useState<Consent>({ allowForProject: false });
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/settings/env-consent?projectId=${encodeURIComponent(projectId)}`, { signal: controller.signal, cache: "no-store" })
      .then(async (response) => response.ok ? response.json() as Promise<Consent> : Promise.reject(new Error("Could not load permission settings.")))
      .then(setConsent).catch((error: unknown) => { if (!(error instanceof DOMException && error.name === "AbortError")) setNotice("تنظیمات اجازه بارگذاری نشد."); });
    return () => controller.abort();
  }, [projectId]);

  async function revoke() {
    setBusy(true);
    setNotice("");
    try {
      const response = await fetch("/api/settings/env-consent", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId, choice: "deny" }),
      });
      const result = await response.json() as Consent & { message?: string; error?: string };
      if (!response.ok) throw new Error(result.error ?? "Permission could not be updated.");
      setConsent(result);
      setNotice(result.message ?? "اجازه لغو شد.");
      window.dispatchEvent(new Event("hitl:audit-updated"));
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "اجازه به‌روز نشد.");
    } finally { setBusy(false); }
  }

  return (
    <section aria-labelledby="env-consent-heading" className="rounded-2xl border border-amber-300 bg-white p-6">
      <p className="text-xs font-semibold text-amber-900">تنظیم دسترسی</p>
      <h2 id="env-consent-heading" className="mt-2 text-lg font-bold text-slate-950">اجازه‌ی پروژه‌ای env</h2>
      <p className="mt-2 max-w-2xl text-sm leading-7 text-slate-600">مقدارها در کارت یا دفترچه‌ی عملیات نمایش داده نمی‌شوند و به مدل نمی‌رسند. اجازه‌ی یک‌باره یا پروژه‌ای هنگام درخواست خواندن از کارت تأیید داده می‌شود.</p>
      <label className="mt-4 block max-w-sm text-sm font-medium text-slate-700">
        شناسه‌ی پروژه
        <input value={projectId} onChange={(event) => setProjectId(event.target.value)} className="mt-1 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus-visible:outline-2 focus-visible:outline-teal-700" />
      </label>
      <p className="mt-3 text-xs text-slate-600">وضعیت این پروژه: {consent.allowForProject ? "اجازه‌ی پروژه‌ای فعال" : "اجازه‌ی ذخیره‌شده ندارد"}</p>
      <div className="mt-4 flex flex-wrap gap-2">
        {consent.allowForProject ? <button disabled={busy || !projectId.trim()} onClick={() => void revoke()} className="rounded-lg border border-rose-300 px-4 py-2 text-sm text-rose-900 hover:bg-rose-50 disabled:opacity-50">لغو اجازه‌ی این پروژه</button> : <p className="text-sm text-slate-500">برای خواندن، درخواست اجازه در کارت حساس نمایش داده می‌شود.</p>}
      </div>
      {notice && <p role="status" className="mt-3 text-sm text-slate-600">{notice}</p>}
    </section>
  );
}
