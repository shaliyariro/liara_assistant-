import type { DeployEvent, DeployStage } from "@/lib/deploy/pipeline";

const order: DeployStage[] = ["clone", "build", "push", "run", "health"];
const labels: Record<DeployStage, string> = { clone: "دریافت سورس", build: "بیلد", push: "پوش", run: "اجرا", health: "بررسی سلامت" };

export function ProgressCard({ events, running, complete }: { events: DeployEvent[]; running: boolean; complete: boolean }) {
  const stateByStage = new Map<DeployStage, "running" | "succeeded" | "failed">();
  for (const event of events) if (event.type === "stage") stateByStage.set(event.stage, event.state);
  const details = events.filter((event): event is Extract<DeployEvent, { type: "detail" }> => event.type === "detail").slice(-200);
  const environment = events.find((event): event is Extract<DeployEvent, { type: "env" }> => event.type === "env");
  const summary = events.find((event): event is Extract<DeployEvent, { type: "handoff" }> => event.type === "handoff");
  return (
    <section dir="rtl" aria-live="polite" className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
      <header><p className="text-xs font-semibold text-teal-800">پیشرفت زنده · Liara</p><h2 className="mt-1 text-lg font-bold text-slate-950">{complete ? "اپ آماده است" : running ? "در حال دیپلوی" : summary ? "تحویل به عیب‌یابی" : "وضعیت دیپلوی"}</h2></header>
      <ol className="grid gap-2 sm:grid-cols-5">
        {order.map((stage) => {
          const state = stateByStage.get(stage) ?? "pending";
          const label = state === "pending" ? "در انتظار" : state === "running" ? "در حال اجرا" : state === "succeeded" ? "موفق" : "ناموفق";
          return <li key={stage} className={`rounded-xl border px-3 py-3 text-sm ${state === "failed" ? "border-rose-300 bg-rose-50 text-rose-900" : state === "succeeded" ? "border-teal-200 bg-teal-50 text-teal-950" : state === "running" ? "border-sky-300 bg-sky-50 text-sky-950" : "border-slate-200 bg-slate-50 text-slate-600"}`}>
            <p className="font-semibold">{labels[stage]}</p><p className="mt-1 text-xs">{label}</p>
          </li>;
        })}
      </ol>
      <div className="space-y-2">{events.filter((event): event is Extract<DeployEvent, { type: "stage" }> => event.type === "stage").slice(-5).map((event, index) => <p key={`${event.stage}-${index}`} className="text-sm text-slate-700">{event.message}</p>)}</div>
      {environment && environment.values.length > 0 && <aside className="rounded-xl border border-slate-200 bg-slate-50 p-4"><p className="text-xs font-semibold text-slate-600">مقادیر env خوانده یا تولیدشده · ماسک‌شده</p><ul className="mt-2 grid gap-1 sm:grid-cols-2">{environment.values.map(({ key, masked }) => <li key={key} className="flex justify-between gap-3 text-xs"><span dir="ltr">{key}</span><code dir="ltr">{masked || "(empty)"}</code></li>)}</ul></aside>}
      {summary && <aside className="rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm text-amber-950"><p className="font-semibold">{summary.summary}</p><p className="mt-1">جریان عیب‌یابی F03 به‌طور خودکار آغاز شد.</p>{summary.evidence.length > 0 && <ul className="mt-2 list-disc space-y-1 pr-5 text-xs">{summary.evidence.map((line, index) => <li key={index} dir="ltr" className="text-left">{line}</li>)}</ul>}</aside>}
      {details.length > 0 && <details className="rounded-xl border border-slate-200"><summary className="cursor-pointer px-4 py-3 text-sm font-semibold text-slate-700">جزئیات لاگ ساخت ({details.length})</summary><pre dir="ltr" className="max-h-72 overflow-auto whitespace-pre-wrap border-t border-slate-200 bg-slate-950 p-4 text-xs leading-5 text-slate-100">{details.map(({ line }) => line).join("\n")}</pre></details>}
    </section>
  );
}
