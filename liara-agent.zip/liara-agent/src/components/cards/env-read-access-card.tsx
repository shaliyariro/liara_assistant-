type ServerAction = (formData: FormData) => void | Promise<void>;

export function EnvReadAccessCard({ projectId, workspacePath, keys, onChoice }: { projectId: string; workspacePath: string; keys: string[]; onChoice: ServerAction }) {
  return (
    <article className="rounded-2xl border border-amber-300 bg-white p-6">
      <p className="text-xs font-semibold text-amber-900">دسترسی به اطلاعات محرمانه</p>
      <h2 className="mt-2 text-lg font-bold text-slate-950">اجازه می‌دهی فایل env این پروژه خوانده شود؟</h2>
      <p className="mt-2 max-w-2xl text-sm leading-7 text-slate-600">مقدارها به عامل نمایش داده نمی‌شوند و در لاگ فقط به‌صورت ماسک ثبت می‌شوند. انتخاب پروژه‌ای را هر زمان می‌توانی از تنظیمات لغو کنی.</p>
      <div className="mt-5 flex flex-wrap gap-2">
        {([
          ["once", "فقط یک‌بار"],
          ["project", "برای این پروژه"],
          ["deny", "نه"],
        ] as const).map(([choice, label]) => (
          <form action={onChoice} key={choice}>
            <input type="hidden" name="projectId" value={projectId} />
            <input type="hidden" name="workspacePath" value={workspacePath} />
            <input type="hidden" name="keys" value={JSON.stringify(keys)} />
            <input type="hidden" name="choice" value={choice} />
            <button className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-medium text-slate-800 hover:border-teal-700 hover:bg-teal-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-800">{label}</button>
          </form>
        ))}
      </div>
    </article>
  );
}
