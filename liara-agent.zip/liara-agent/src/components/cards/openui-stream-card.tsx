"use client";

import { useState } from "react";
import { Renderer } from "@openuidev/react-lang";
import { questionLibrary } from "@/lib/openui-library";

export function OpenUIStreamCard() {
  const [response, setResponse] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);

  async function streamQuestion() {
    setResponse("");
    setIsStreaming(true);
    try {
      const result = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: "کدام اولویت برای پروژه مهم‌تر است؟" }),
      });
      if (!result.ok || !result.body) throw new Error("OpenUI stream unavailable");
      const reader = result.body.getReader();
      const decoder = new TextDecoder();
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        setResponse((current) => current + decoder.decode(value, { stream: true }));
      }
    } finally {
      setIsStreaming(false);
    }
  }

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <h2 className="font-semibold">OpenUI streaming spike</h2>
        <button onClick={streamQuestion} disabled={isStreaming} className="rounded-lg bg-teal-700 px-4 py-2 text-sm text-white disabled:opacity-60">
          {isStreaming ? "در حال دریافت…" : "نمایش کارت استریم‌شده"}
        </button>
      </div>
      {response && <div dir="rtl"><Renderer response={response} library={questionLibrary} isStreaming={isStreaming} /></div>}
    </section>
  );
}
