export function AutoActionNotice({ children }: { children: string }) {
  return <p role="status" className="rounded-lg border-r-2 border-teal-600 bg-teal-50 px-4 py-3 text-sm text-teal-950">✓ {children}</p>;
}
