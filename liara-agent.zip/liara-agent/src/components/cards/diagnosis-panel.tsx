"use client";

import { useEffect, useState, type FormEvent } from "react";
import { Renderer } from "@openuidev/react-lang";
import { findingLibrary, recommendationLibrary } from "@/lib/openui-library";
import type { DiagnosisResult, DiagnosisAction } from "@/lib/diagnosis/types";
import type { Recommendation } from "@/lib/recommendations/engine";
import { LimitationNotice } from "./limitation-notice";

type ApprovalCardModel = { action: string; consequence: string; recommendation: string; alternatives: string[]; monthlyCost?: number };
type PlanOption = { id: string; monthlyToman: number; resourceMonthlyToman?: number; bundlePlanID?: string; bundleMonthlyToman?: number; cpuCores: number; memoryGb: number; diskGb: number };
type FixResponse = { ok?: boolean; approvalCard?: ApprovalCardModel; planOptions?: PlanOption[]; rollbackOptions?: Array<{ id: string; tag: string; createdAt: string; state: string }>; limitation?: { title: string; detail: string; manualStep: string }; error?: string; verification?: { verified: boolean; http?: { before: number; after: number }; metric?: { name: string; before: number; after: number }; rollbackSuggested: boolean } };
type DiagnosisResponse = DiagnosisResult & { recommendations: Recommendation[] };

export function DiagnosisPanel() {
  const [appName, setAppName] = useState("");
  const [result, setResult] = useState<DiagnosisResponse | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [limitation, setLimitation] = useState<FixResponse["limitation"]>();
  const [pendingAction, setPendingAction] = useState<DiagnosisAction & { planID?: string; releaseID?: string }>();
  const [approval, setApproval] = useState<ApprovalCardModel>();
  const [envValue, setEnvValue] = useState("");
  const [verification, setVerification] = useState<FixResponse["verification"]>();
  const [planOptions, setPlanOptions] = useState<PlanOption[]>([]);
  const [rollbackOptions, setRollbackOptions] = useState<NonNullable<FixResponse["rollbackOptions"]>>([]);

  async function diagnose(event?: FormEvent<HTMLFormElement>) {
    event?.preventDefault();
    setBusy(true); setError(""); setLimitation(undefined); setApproval(undefined); setVerification(undefined); setPlanOptions([]);
    try {
      const response = await fetch("/api/diagnosis", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ appName }) });
      const payload = await response.json() as DiagnosisResponse & { error?: string };
      if (!response.ok) throw new Error(payload.error ?? "Evidence collection failed.");
      setResult(payload);
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Diagnosis could not be completed."); }
    finally { setBusy(false); }
  }

  async function runAction(action: DiagnosisAction & { planID?: string; releaseID?: string }, approve = false) {
    if (action.id === "issue") return;
    if (action.id === "set_env" && !envValue && !approve) { setPendingAction(action); return; }
    const body = { appName, action: action.id, ...(action.envKey ? { envKey: action.envKey, envValue } : {}), ...(action.planID ? { planID: action.planID } : {}), ...(action.releaseID ? { releaseID: action.releaseID } : {}), ...(approve ? { approve: true } : {}) };
    setBusy(true); setError(""); setLimitation(undefined); setApproval(undefined);
    try {
      const response = await fetch("/api/diagnosis/action", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const payload = await response.json() as FixResponse;
      if (payload.planOptions) { setPlanOptions(payload.planOptions); setPendingAction(action); return; }
      if (payload.rollbackOptions) { setRollbackOptions(payload.rollbackOptions); setPendingAction(action); return; }
      if (payload.approvalCard) { setPendingAction(action); setApproval(payload.approvalCard); return; }
      if (payload.limitation) setLimitation(payload.limitation);
      if (!response.ok) throw new Error(payload.error ?? "The corrective action failed.");
      setVerification(payload.verification);
      setPendingAction(undefined); setEnvValue("");
      await diagnose();
    } catch (caught) { setError(caught instanceof Error ? caught.message : "The corrective action failed."); }
    finally { setBusy(false); }
  }

  useEffect(() => {
    const listener = (event: Event) => {
      const action = (event as CustomEvent<{ action?: DiagnosisAction }>).detail?.action;
      if (action) void runAction(action);
    };
    window.addEventListener("liara-finding-action", listener);
    const recommendationListener = (event: Event) => {
      const recommendation = (event as CustomEvent<{ recommendation?: Recommendation }>).detail?.recommendation;
      if (!recommendation) return;
      if (recommendation.toolName === "get_app_status") { void diagnose(); return; }
      if (["change_plan", "restart", "rollback", "set_env"].includes(recommendation.toolName)) {
        void runAction({ id: recommendation.toolName, title: recommendation.action, riskLevel: recommendation.riskLevel, rationale: recommendation.proposal, cost: recommendation.financialEffect, downtime: recommendation.downtimeEffect, reversible: recommendation.toolName !== "rollback" });
      }
    };
    window.addEventListener("liara-recommendation-action", recommendationListener);
    return () => { window.removeEventListener("liara-finding-action", listener); window.removeEventListener("liara-recommendation-action", recommendationListener); };
  });

  return <section className="space-y-4 rounded-2xl border border-slate-200 bg-slate-50 p-5 sm:p-6" aria-labelledby="diagnosis-heading">
    <header><p className="text-xs font-semibold text-teal-800">F03 · SRE</p><h2 id="diagnosis-heading" className="mt-1 text-xl font-bold text-slate-950">بررسی سلامت اپ</h2><p className="mt-1 text-sm leading-6 text-slate-600">وضعیت، لاگ، متریک، release و پاسخ HTTP هم‌زمان جمع‌آوری می‌شوند. داده‌های در دسترس نبودن، صریح گزارش می‌شوند.</p></header>
    <form onSubmit={diagnose} className="grid gap-3 sm:grid-cols-[1fr_auto]">
      <label className="text-sm font-medium text-slate-700">نام اپ در Liara<input required pattern="[a-z0-9][a-z0-9-]{1,62}" dir="ltr" value={appName} onChange={(event) => setAppName(event.target.value)} placeholder="my-app" className="mt-1 min-h-11 w-full rounded-xl border border-slate-300 bg-white px-3 text-left" /></label>
      <button type="submit" disabled={busy || !appName} className="mt-auto min-h-11 rounded-xl bg-teal-800 px-5 py-2.5 text-sm font-semibold text-white disabled:opacity-50">{busy ? "در حال جمع‌آوری شواهد…" : "بررسی سلامت"}</button>
    </form>
    {error && <p role="alert" className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-sm text-rose-900">{error}</p>}
    {result && <div className="space-y-3"><Renderer response={openUi(result)} library={findingLibrary} isStreaming={false} />
      {result.recommendations.map((recommendation) => <Renderer key={recommendation.id} response={openRecommendation(recommendation)} library={recommendationLibrary} isStreaming={false} />)}
      {result.evidence.limitations.map((notice, index) => <LimitationNotice key={`${notice.title}-${index}`} {...notice} />)}
      {verification && <div role="status" className={`rounded-xl border p-4 text-sm ${verification.verified ? "border-teal-200 bg-teal-50 text-teal-950" : "border-amber-300 bg-amber-50 text-amber-950"}`}><strong>{verification.verified ? "اصلاح تأیید شد" : "اصلاح هنوز تأیید نشده"}</strong><p className="mt-2">{verification.http ? `HTTP قبل/بعد: ${verification.http.before} → ${verification.http.after}. ` : "وضعیت HTTP قبل و بعد کامل در دسترس نیست. "}{verification.metric ? `${verification.metric.name} قبل/بعد: ${verification.metric.before} → ${verification.metric.after}.` : "متریک قابل مقایسه در دسترس نیست؛ عددی جعل نشده است."}</p>{verification.rollbackSuggested && <p className="mt-2">پیشنهاد بعدی: بررسی rollback به release قبلی (نیازمند تأیید و دسترسی API).</p>}</div>}
    </div>}
    {pendingAction?.id === "set_env" && pendingAction.envKey && !approval && <form onSubmit={(event) => { event.preventDefault(); void runAction(pendingAction); }} className="rounded-xl border border-slate-200 bg-white p-4"><label className="text-sm font-semibold text-slate-800">مقدار {pendingAction.envKey} (در پیام یا لاگ نمایش داده نمی‌شود)<input type="password" autoComplete="new-password" value={envValue} onChange={(event) => setEnvValue(event.target.value)} className="mt-2 min-h-11 w-full rounded-xl border border-slate-300 px-3" /></label><button disabled={busy || !envValue} className="mt-3 min-h-11 rounded-lg bg-teal-800 px-4 text-sm font-semibold text-white disabled:opacity-50">ست env و بررسی مجدد</button></form>}
    {pendingAction?.id === "change_plan" && planOptions.length > 0 && !approval && <section className="rounded-xl border border-rose-200 bg-white p-4"><h3 className="font-bold text-slate-900">پلن جدید را از کاتالوگ زنده انتخاب کن</h3><div className="mt-3 grid gap-2">{planOptions.map((plan) => <button type="button" key={plan.id} disabled={busy} onClick={() => void runAction({ ...pendingAction, planID: plan.id })} className="flex min-h-11 flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 px-3 py-2 text-left text-sm hover:bg-slate-50"><span dir="ltr">{plan.id} · {plan.cpuCores} CPU · {plan.memoryGb} GB RAM · {plan.bundlePlanID}</span><strong>{new Intl.NumberFormat("fa-IR").format(plan.monthlyToman)} تومان/ماه</strong></button>)}</div></section>}
    {pendingAction?.id === "rollback" && rollbackOptions.length > 0 && !approval && <section className="rounded-xl border border-rose-200 bg-white p-4"><h3 className="font-bold text-slate-900">release قبلی را انتخاب کن</h3><div className="mt-3 grid gap-2">{rollbackOptions.map((release) => <button type="button" key={release.id} disabled={busy} onClick={() => void runAction({ ...pendingAction, releaseID: release.id })} className="flex min-h-11 flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-200 px-3 py-2 text-left text-sm hover:bg-slate-50"><span dir="ltr">{release.tag}</span><span>{release.createdAt} · {release.state}</span></button>)}</div></section>}
    {approval && pendingAction && <article className="rounded-2xl border border-rose-300 bg-white p-5" aria-label="ApprovalCard"><p className="text-xs font-bold text-rose-800">ApprovalCard · تأیید لازم است</p><h3 className="mt-2 font-bold text-slate-950">{approval.action}</h3><p className="mt-2 text-sm leading-6 text-slate-700">{approval.consequence}</p>{approval.monthlyCost !== undefined && <p className="mt-2 font-semibold">{new Intl.NumberFormat("fa-IR").format(approval.monthlyCost)} تومان در ماه</p>}<p className="mt-2 text-sm text-teal-900">⭐ {approval.recommendation}</p><div className="mt-4 flex gap-2"><button type="button" disabled={busy} onClick={() => void runAction(pendingAction, true)} className="min-h-11 rounded-lg bg-rose-700 px-4 text-sm font-semibold text-white">تأیید و اجرا</button><button type="button" onClick={() => { setApproval(undefined); setPendingAction(undefined); }} className="min-h-11 rounded-lg border border-slate-300 px-4 text-sm">لغو</button></div></article>}
    {limitation && <LimitationNotice {...limitation} />}
  </section>;
}

function openUi(result: DiagnosisResult) {
  const { appName, finding, elapsedMs } = result;
  return `root = FindingCard(${JSON.stringify({ appName, severity: finding.severity, summary: finding.summary, causes: finding.causes, evidence: finding.evidence, actions: finding.actions, issuePrompt: finding.issuePrompt, elapsedMs })})`;
}

function openRecommendation(recommendation: Recommendation) { return `root = RecommendationCard(${JSON.stringify(recommendation)})`; }
