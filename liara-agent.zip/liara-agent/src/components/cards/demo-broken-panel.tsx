"use client";

import { useEffect, useState } from "react";
import { Renderer } from "@openuidev/react-lang";
import type { DiagnosisResult } from "@/lib/diagnosis/types";
import type { Recommendation } from "@/lib/recommendations/engine";
import { findingLibrary, recommendationLibrary } from "@/lib/openui-library";

type DemoDiagnosis = { result: DiagnosisResult; recommendations: Recommendation[]; sessionId: string };
type DemoFix = { before: { probe: DiagnosisResult["evidence"]["probe"]; metrics: Record<string, number> | null }; after: { probe: DiagnosisResult["evidence"]["probe"]; metrics: Record<string, number> | null }; verification: { verified: boolean; http?: { before: number; after: number }; metric?: { name: string; before: number; after: number }; rollbackSuggested: boolean } };

export function DemoBrokenPanel({ onTimerStart, onComplete }: { onTimerStart: () => void; onComplete: () => void }) {
  const [active, setActive] = useState(false);
  const [diagnosis, setDiagnosis] = useState<DemoDiagnosis | null>(null);
  const [fix, setFix] = useState<DemoFix | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function post(path: string, body?: unknown) {
    const response = await fetch(path, { method: "POST", headers: body === undefined ? undefined : { "Content-Type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
    const payload = await response.json() as Record<string, unknown> & { error?: string };
    if (!response.ok) throw new Error(payload.error ?? "The local demo request failed.");
    return payload;
  }

  async function activate() {
    setBusy(true); setError(""); setDiagnosis(null); setFix(null); setMessage(""); onTimerStart();
    try { const result = await post("/api/demo/activate"); setActive(true); setMessage(`Failure active: ${(result.failures as string[] | undefined)?.join(", ") ?? "slow"}.`); window.dispatchEvent(new Event("hitl:audit-updated")); }
    catch (caught) { setError(caught instanceof Error ? caught.message : "Could not activate failure."); }
    finally { setBusy(false); }
  }

  async function diagnose() {
    setBusy(true); setError(""); setFix(null);
    try {
      const result = await post("/api/demo/diagnose") as unknown as DemoDiagnosis;
      setDiagnosis(result); setMessage(`Finding prepared in ${result.result.elapsedMs} ms from a measured local HTTP probe.`);
    } catch (caught) { setError(caught instanceof Error ? caught.message : "Local demo diagnosis failed."); }
    finally { setBusy(false); }
  }

  async function applyRecommendation(recommendation: Recommendation) {
    if (!diagnosis || recommendation.id !== "demo-slow-fix" || busy) return;
    setBusy(true); setError(""); setMessage("Running the linked green demo tool and verifying before/after evidence…");
    try {
      const result = await post("/api/demo/fix", { sessionId: diagnosis.sessionId, recommendationId: recommendation.id }) as unknown as DemoFix;
      setFix(result); setMessage(result.verification.verified ? "Fix verified from the local HTTP probe and measured metric." : "The fix did not meet both verification requirements.");
      window.dispatchEvent(new Event("hitl:audit-updated"));
      if (result.verification.verified) onComplete();
    } catch (caught) { setError(caught instanceof Error ? caught.message : "The local fix failed."); }
    finally { setBusy(false); }
  }

  async function reset() {
    setBusy(true); setError("");
    try { await post("/api/demo/reset"); setActive(false); setDiagnosis(null); setFix(null); setMessage("Local demo state reset."); window.dispatchEvent(new Event("hitl:audit-updated")); }
    catch (caught) { setError(caught instanceof Error ? caught.message : "Could not reset the local demo."); }
    finally { setBusy(false); }
  }

  useEffect(() => {
    const listener = (event: Event) => {
      const recommendation = (event as CustomEvent<{ recommendation?: Recommendation }>).detail?.recommendation;
      if (recommendation?.id === "demo-slow-fix") void applyRecommendation(recommendation);
    };
    window.addEventListener("liara-recommendation-action", listener);
    return () => window.removeEventListener("liara-recommendation-action", listener);
  });

  return <section className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6" aria-labelledby="demo-broken-heading">
    <header><p className="text-xs font-semibold text-teal-800">سناریو B · محلی و قابل تکرار</p><h2 id="demo-broken-heading" className="mt-1 text-xl font-bold text-slate-950">سایت کند شده است</h2><p className="mt-2 text-sm leading-6 text-slate-600">خرابی کنترل‌شده‌ی `/slow` فعال می‌شود؛ FindingCard بر اساس پاسخ HTTP و متریک زمان پاسخ واقعی ساخته می‌شود. اصلاح فقط failure محلی را خاموش می‌کند.</p></header>
    <div className="flex flex-wrap gap-2"><button type="button" disabled={busy} onClick={() => void activate()} className="min-h-11 rounded-xl bg-amber-800 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">فعال‌کردن خرابی کندی</button><button type="button" disabled={busy || !active} onClick={() => void diagnose()} className="min-h-11 rounded-xl bg-teal-800 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">سایت کنده؛ جمع‌آوری شواهد</button><button type="button" disabled={busy} onClick={() => void reset()} className="min-h-11 rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-800 disabled:opacity-50">ریست محلی</button></div>
    {message && <p role="status" aria-atomic="true" className="rounded-xl bg-slate-50 px-4 py-3 text-sm text-slate-700">{message}</p>}
    {error && <p role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-900">{error}</p>}
    {diagnosis && <div className="space-y-3"><Renderer response={findingResponse(diagnosis.result)} library={findingLibrary} isStreaming={false} />{diagnosis.recommendations.map((recommendation) => <Renderer key={recommendation.id} response={recommendationResponse(recommendation)} library={recommendationLibrary} isStreaming={false} />)}</div>}
    {fix && <section aria-label="نتیجه‌ی verify قبل و بعد" className={`rounded-xl border p-4 ${fix.verification.verified ? "border-teal-300 bg-teal-50" : "border-amber-300 bg-amber-50"}`}><h3 className="font-bold text-slate-950">{fix.verification.verified ? "Verify موفق" : "Verify ناموفق"}</h3><p className="mt-2 text-sm leading-6 text-slate-800">{fix.verification.http ? `HTTP قبل/بعد: ${fix.verification.http.before} → ${fix.verification.http.after}. ` : "HTTP قبل و بعد قابل مقایسه نبود. "}{fix.verification.metric ? `${fix.verification.metric.name} قبل/بعد: ${fix.verification.metric.before} → ${fix.verification.metric.after}.` : "متریک قابل مقایسه در دسترس نبود."}</p></section>}
    <p className="text-xs leading-5 text-slate-500">پیش‌نیاز: اجرای `npm run demo:broken` در ترمینال جدا. این سناریو به Liara API وصل نمی‌شود.</p>
  </section>;
}

function findingResponse(result: DiagnosisResult) {
  const { appName, finding, elapsedMs } = result;
  return `root = FindingCard(${JSON.stringify({ appName, severity: finding.severity, summary: finding.summary, causes: finding.causes, evidence: finding.evidence, actions: finding.actions, issuePrompt: finding.issuePrompt, elapsedMs })})`;
}

function recommendationResponse(recommendation: Recommendation) { return `root = RecommendationCard(${JSON.stringify(recommendation)})`; }
