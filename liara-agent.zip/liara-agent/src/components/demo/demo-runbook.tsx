"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { RepoAnalysisFlow } from "@/components/cards/repo-analysis-flow";
import { DemoBrokenPanel } from "@/components/cards/demo-broken-panel";
import { AuditLog } from "@/components/audit/audit-log";

type ApprovalEntry = { scenario: "A" | "B"; id: string };
type Props = { liaraTokenConfigured: boolean; approvalSecretConfigured: boolean; demoGithubRepoConfigured: boolean; spikePlanConfigured: boolean };

export function DemoRunbook(props: Props) {
  const [aStarted, setAStarted] = useState<number | null>(null);
  const [bStarted, setBStarted] = useState<number | null>(null);
  const [aElapsed, setAElapsed] = useState(0);
  const [bElapsed, setBElapsed] = useState(0);
  const [approvals, setApprovals] = useState<ApprovalEntry[]>([]);

  useEffect(() => {
    const interval = window.setInterval(() => {
      const now = Date.now();
      if (aStarted !== null) setAElapsed(now - aStarted);
      if (bStarted !== null) setBElapsed(now - bStarted);
    }, 250);
    return () => window.clearInterval(interval);
  }, [aStarted, bStarted]);

  useEffect(() => {
    const cardListener = (event: Event) => {
      const detail = (event as CustomEvent<ApprovalEntry>).detail;
      if (detail?.scenario && detail?.id) setApprovals((current) => current.some((item) => item.scenario === detail.scenario && item.id === detail.id) ? current : [...current, detail]);
    };
    const completeListener = (event: Event) => {
      const scenario = (event as CustomEvent<{ scenario?: "A" | "B" }>).detail?.scenario;
      if (scenario === "A") setAStarted(null);
      if (scenario === "B") setBStarted(null);
    };
    window.addEventListener("demo-approval-card", cardListener);
    window.addEventListener("demo-scenario-complete", completeListener);
    return () => { window.removeEventListener("demo-approval-card", cardListener); window.removeEventListener("demo-scenario-complete", completeListener); };
  }, []);

  function startA() { setAStarted(Date.now()); setAElapsed(0); setApprovals([]); }
  function startB() { setBStarted((current) => current ?? Date.now()); setBElapsed(0); }

  const totalApprovals = approvals.length;
  return <main className="mx-auto min-h-screen w-full max-w-5xl space-y-8 px-5 py-8 sm:px-8 sm:py-10">
    <header className="space-y-3"><p className="text-xs font-bold uppercase tracking-wide text-teal-800">Five-minute demo · F01–F04</p><h1 className="text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">Demo runbook</h1><p className="max-w-3xl text-sm leading-7 text-slate-600">Follow the roadmap order. The live Liara flow and the local failure demo are kept separate so the second scene cannot mutate a real app.</p><Link href="/capabilities" className="inline-flex min-h-11 items-center rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-800 hover:bg-slate-50">What I can / cannot do</Link></header>

    <section className="grid gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:grid-cols-3" aria-label="Demo timing and approvals">
      <div><p className="text-xs font-bold text-slate-500">Scenario A timer</p><p role="timer" className="mt-1 font-mono text-2xl font-bold tabular-nums text-slate-950">{formatTime(aElapsed)}</p><button type="button" onClick={startA} className="mt-2 min-h-11 rounded-lg border border-slate-300 px-3 text-sm font-semibold">Start / reset A clock</button></div>
      <div><p className="text-xs font-bold text-slate-500">Scenario B timer</p><p role="timer" className="mt-1 font-mono text-2xl font-bold tabular-nums text-slate-950">{formatTime(bElapsed)}</p><p className="mt-2 text-sm text-slate-600">Starts when failure activation begins.</p></div>
      <div><p className="text-xs font-bold text-slate-500">Approval cards shown</p><p role="status" aria-atomic="true" className="mt-1 text-2xl font-bold tabular-nums text-slate-950">A: {approvals.filter(({ scenario }) => scenario === "A").length} · B: {approvals.filter(({ scenario }) => scenario === "B").length} · Total: {totalApprovals}/3</p><p className="mt-2 text-sm text-slate-600">Expected ceiling: 2 in A (cost + env consent), 0 in B (green local fix).</p></div>
    </section>

    <section className="space-y-4 rounded-2xl border border-slate-200 bg-slate-50 p-5 sm:p-6" aria-labelledby="scenario-a-heading">
      <header><p className="text-xs font-semibold text-teal-800">۰:۳۰–۲:۳۰ · F01 + F02 + F04</p><h2 id="scenario-a-heading" className="mt-1 text-xl font-bold text-slate-950">سناریو A · از GitHub تا آنلاین</h2><ol className="mt-3 list-inside list-decimal space-y-1 text-sm leading-6 text-slate-700"><li>واردکردن لینک ریپوی عمومی و نمایش ProjectCard.</li><li>پاسخ به حداکثر چهار QuestionCard.</li><li>بررسی کارت تجمیعی هزینه و تأیید پلن.</li><li>اجازه‌ی یک‌باره برای خواندن env؛ مقدارها ماسک می‌شوند.</li><li>مشاهده‌ی clone/build/push/run/health check تا HTTP 200 واقعی.</li></ol></header>
      <ul className="grid gap-2 text-sm sm:grid-cols-2"><Readiness ok={props.liaraTokenConfigured} label="LIARA_API_TOKEN روی سرور تنظیم شده" /><Readiness ok={props.approvalSecretConfigured} label="کلید امضای Approval Gate تنظیم شده" /><Readiness ok={props.demoGithubRepoConfigured} label="DEMO_GITHUB_REPO_URL برای ریپوی نمایشی تنظیم شده" /><Readiness ok={props.spikePlanConfigured} label="LIARA_TEST_PLAN_ID برای spike پولی تنظیم شده (برای انتخاب در UI لازم نیست)" /><Readiness ok={false} label="ساخت و دیپلوی زنده‌ی Liara با اپ دورریختنی هنوز تأیید نشده" /></ul>
      <p className="rounded-xl border border-amber-300 bg-amber-50 p-4 text-sm leading-6 text-amber-950">برای کارت اجازه‌ی env، ریپو باید `.env.example` و یک `.env` با مقدار نمایشیِ غیرحساس داشته باشد. از secrets واقعی برای ریپوی عمومی استفاده نکن. پیش از ضبط زنده، پلن را از کاتالوگ بگیر و هزینه را در ApprovalCard ببین؛ هیچ عملیات پولی خودکار نیست.</p>
      <div><button type="button" onClick={startA} className="mb-3 min-h-11 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white">Start A timer, then analyze the GitHub repo</button><RepoAnalysisFlow /></div>
    </section>

    <section className="space-y-4" aria-labelledby="scenario-b-heading"><header><p className="text-xs font-semibold text-teal-800">۲:۳۰–۴:۰۰ · F03 + F05</p><h2 id="scenario-b-heading" className="mt-1 text-xl font-bold text-slate-950">سناریو B · «سایت کند شده» تا verify</h2></header><DemoBrokenPanel onTimerStart={startB} onComplete={() => setBStarted(null)} /></section>

    <section className="space-y-4 rounded-2xl border border-slate-200 bg-white p-5"><p className="text-xs font-semibold text-teal-800">۴:۰۰–۴:۴۵ · F04 · Audit + محدودیت‌ها</p><h2 className="mt-1 text-lg font-bold text-slate-950">تأییدها و دفترچه‌ی عملیات</h2><p className="text-sm leading-6 text-slate-600">پارامترها ماسک می‌شوند و نتیجه‌ی هر اقدام از SQLite نمایش داده می‌شود. برای خودکارها و تأییدهای A مرور کنید.</p><AuditLog /><div className="border-t border-slate-100 pt-4"><p className="text-xs font-semibold text-teal-800">۴:۴۵–۵:۰۰ · جمع‌بندی</p><h3 className="mt-1 font-bold text-slate-950">محدودیت API و آمادگی فعلی</h3><p className="mt-2 text-sm leading-6 text-slate-600">لیست اپ و پلن با HTTP 200 تأیید شده‌اند. create/upload/deploy/env/logs/metrics/restart هنوز با اپ دورریختنی تست نشده‌اند؛ سناریوی A را فعلاً نباید به‌عنوان اجرای زنده‌ی تأییدشده معرفی کرد. جزئیات و مسیر هر API:</p><Link href="/capabilities" className="mt-3 inline-flex min-h-11 items-center rounded-lg border border-slate-300 px-4 text-sm font-semibold">Open API capability table</Link></div></section>
    <p className="text-center text-xs text-slate-500">Local demo only: `npm run demo:broken` · reset: `npm run demo:reset` · record scenario B: `npm run demo:validate`</p>
  </main>;
}

function Readiness({ ok, label }: { ok: boolean; label: string }) { return <li className={`rounded-xl border px-3 py-2 ${ok ? "border-teal-200 bg-teal-50 text-teal-950" : "border-amber-200 bg-amber-50 text-amber-950"}`}>{ok ? "✅" : "⚠️"} {label}</li>; }
function formatTime(milliseconds: number) { const seconds = Math.floor(milliseconds / 1000); return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`; }
