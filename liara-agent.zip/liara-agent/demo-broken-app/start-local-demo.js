process.env.REQUIRE_DATABASE_URL = "0";
process.env.DEMO_FAILURE = "off";
await import("./server.js");
