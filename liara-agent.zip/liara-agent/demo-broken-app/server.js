import { createServer } from "node:http";

const port = Number(process.env.PORT ?? 3001);
const requiresDatabase = process.env.REQUIRE_DATABASE_URL !== "0";
if (requiresDatabase && !process.env.DATABASE_URL) {
  console.error("Startup failed: DATABASE_URL is required. Set it or use REQUIRE_DATABASE_URL=0 for a local demo.");
  process.exit(1);
}

const failures = new Set((process.env.DEMO_FAILURE ?? "off").split(",").map((value) => value.trim()).filter((value) => value && value !== "off"));
const leakedChunks = [];
const recentLogs = [];
const processStartedAt = Date.now();
let slowResponseMs = 0;

function log(level, message, details = {}) {
  const entry = { timestamp: new Date().toISOString(), level, message, ...details };
  recentLogs.push(entry);
  if (recentLogs.length > 100) recentLogs.shift();
  console[level === "error" ? "error" : "log"](JSON.stringify(entry));
}

function canControl(request) {
  const address = request.socket.remoteAddress ?? "";
  const isLocal = address === "::1" || address === "127.0.0.1" || address === "::ffff:127.0.0.1";
  const controlToken = process.env.DEMO_CONTROL_TOKEN;
  return isLocal || Boolean(controlToken && request.headers.authorization === `Bearer ${controlToken}`);
}

function sendJson(response, status, body) {
  response.writeHead(status, { "content-type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(body));
}

const server = createServer(async (request, response) => {
  const url = new URL(request.url ?? "/", `http://${request.headers.host ?? "localhost"}`);
  if (request.method === "GET" && url.pathname === "/health") {
    return sendJson(response, 200, { status: "ok", failures: [...failures], leakedChunks: leakedChunks.length });
  }
  if (request.method === "GET" && url.pathname === "/metrics") {
    const usage = process.memoryUsage();
    return sendJson(response, 200, { rssBytes: usage.rss, heapUsedBytes: usage.heapUsed, heapTotalBytes: usage.heapTotal, externalBytes: usage.external, leakedChunks: leakedChunks.length, leakedMegabytes: leakedChunks.length, slowResponseMs, uptimeSeconds: Math.floor((Date.now() - processStartedAt) / 1000) });
  }
  if (request.method === "GET" && url.pathname === "/demo-logs") {
    if (!canControl(request)) return sendJson(response, 403, { error: "Local access or a DEMO_CONTROL_TOKEN is required." });
    return sendJson(response, 200, { logs: recentLogs.slice(-50) });
  }
  if (request.method === "POST" && url.pathname === "/controls") {
    if (!canControl(request)) return sendJson(response, 403, { error: "Local access or a DEMO_CONTROL_TOKEN is required." });
    let raw = "";
    for await (const chunk of request) raw += chunk;
    try {
      const input = JSON.parse(raw);
      if (input.reset === true) {
        failures.clear();
        leakedChunks.length = 0;
        slowResponseMs = 0;
        recentLogs.length = 0;
        log("info", "Demo failures and measured state reset");
        return sendJson(response, 200, { failures: [], leakedChunks: 0, slowResponseMs });
      }
      const { failure, enabled } = input;
      if (!["leak", "error500", "slow"].includes(failure) || typeof enabled !== "boolean") {
        return sendJson(response, 400, { error: "Use failure=leak|error500|slow and enabled=true|false." });
      }
      if (enabled) failures.add(failure);
      else failures.delete(failure);
      if (failure === "slow" && !enabled) slowResponseMs = 0;
      return sendJson(response, 200, { failures: [...failures] });
    } catch {
      return sendJson(response, 400, { error: "Expected a JSON request body." });
    }
  }
  if (request.method === "POST" && url.pathname === "/leak") {
    if (!canControl(request)) return sendJson(response, 403, { error: "Local access or a DEMO_CONTROL_TOKEN is required." });
    if (!failures.has("leak")) return sendJson(response, 409, { error: "Memory leak is disabled." });
    const chunkCount = Math.min(100, Math.max(1, Number(url.searchParams.get("chunks") ?? 10)));
    for (let index = 0; index < chunkCount; index++) leakedChunks.push(Buffer.alloc(1024 * 1024, "x"));
    log("warn", "Intentional memory leak allocated", { leakedChunks: leakedChunks.length, leakedMegabytes: leakedChunks.length });
    return sendJson(response, 200, { leakedMegabytes: leakedChunks.length });
  }
  if (request.method === "GET" && url.pathname === "/error500") {
    if (!failures.has("error500")) return sendJson(response, 409, { error: "HTTP 500 failure is disabled." });
    const error = new Error("Intentional demo failure in GET /error500");
    log("error", error.message, { stack: error.stack, path: url.pathname });
    return sendJson(response, 500, { error: error.message, stack: error.stack });
  }
  if (request.method === "GET" && url.pathname === "/slow") {
    const delayedMilliseconds = failures.has("slow") ? Number(process.env.DEMO_SLOW_MS ?? 2_500) : 0;
    if (delayedMilliseconds > 0) await new Promise((resolve) => setTimeout(resolve, delayedMilliseconds));
    slowResponseMs = delayedMilliseconds;
    return sendJson(response, 200, { delayedMilliseconds });
  }
  return sendJson(response, 404, { error: "Not found." });
});

server.listen(port, process.env.HOST ?? "127.0.0.1",() => log("info", `Demo Broken App listening on port ${port}`));
