# Demo Broken App

Requires `DATABASE_URL` at startup by default. Run with `npm start` after setting it, or set `REQUIRE_DATABASE_URL=0` for a local demo without a database.

For the isolated local video demo, run `npm run demo:broken` from the repository root. It starts on loopback with `REQUIRE_DATABASE_URL=0` and failures disabled. Do not point it at a real workload.

Set `DEMO_FAILURE=leak,error500,slow` at startup, or toggle individual failures while running. Remote `/controls` and `/leak` requests require `Authorization: Bearer $DEMO_CONTROL_TOKEN`; local loopback requests do not:

```sh
curl -X POST http://localhost:3001/controls -H "Content-Type: application/json" -d '{"failure":"error500","enabled":true}'
curl http://localhost:3001/error500
```

Endpoints: `GET /health`, `GET /metrics`, `GET /demo-logs`, `POST /leak?chunks=10`, `GET /error500`, `GET /slow`, and `POST /controls`. Each `/leak` request retains up to 100 MiB in process memory. `/metrics` reports measured RSS/heap values, retained chunks, `slowResponseMs`, and uptime; `/demo-logs` returns structured logs. `/slow` returns HTTP 200 and delays for `DEMO_SLOW_MS` milliseconds when enabled (2,500 by default), then returns immediately when disabled. `POST /controls` accepts `{"reset":true}` to clear all local failures and retained chunks. The server binds to loopback for local validation. Keep this demo isolated from real workloads.
