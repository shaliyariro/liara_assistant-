// Read-only Liara probe: never creates, changes, or deletes anything.
// Prints plan IDs/prices and, for one existing app, the HTTP status and top-level shape of each
// diagnosis route. Response bodies, tokens and env values are never printed.
import { loadEnvConfig } from "@next/env";
import { LiaraClient } from "../src/lib/liara/client";
import { LiaraError } from "../src/lib/liara/errors";
import { normalizeLiveCatalog } from "../src/lib/liara/plan-catalog";

loadEnvConfig(process.cwd());

type Row = { operation: string; path: string; status: number | "ERR"; note: string };
const rows: Row[] = [];

function shape(value: unknown, depth = 0): string {
  if (Array.isArray(value)) return `array(${value.length})${value.length && depth < 1 ? `<${shape(value[0], depth + 1)}>` : ""}`;
  if (value && typeof value === "object") {
    const keys = Object.keys(value as Record<string, unknown>).slice(0, 8);
    return depth < 1 ? `{${keys.map((key) => `${key}:${shape((value as Record<string, unknown>)[key], depth + 1)}`).join(", ")}}` : `{${keys.join(",")}}`;
  }
  return typeof value;
}

async function probe<T>(operation: string, path: string, call: () => Promise<{ status: number; data: T }>, describe: (data: T) => string = (data) => shape(data)) {
  const started = performance.now();
  try {
    const response = await call();
    rows.push({ operation, path, status: response.status, note: `${describe(response.data)} · ${Math.round(performance.now() - started)} ms` });
    return response.data;
  } catch (error) {
    const e = error instanceof LiaraError ? error : undefined;
    rows.push({ operation, path, status: e?.status ?? "ERR", note: e?.userMessage ?? "Request failed; details withheld." });
    return undefined;
  }
}

async function main() {
  if (!process.env.LIARA_API_TOKEN) { console.log("LIARA_API_TOKEN is not set in .env.local. Nothing was sent."); process.exitCode = 2; return; }
  const client = new LiaraClient({ logger: () => undefined });

  const apps = await probe("List apps", "GET /v1/projects", () => client.listApps(), (data) => `${data.projects?.length ?? 0} app(s)`);
  const me = await probe("List plans", "GET /v1/me", () => client.listPlans(), () => "catalog received") as Parameters<typeof normalizeLiveCatalog>[0] | undefined;
  await probe("List databases", "GET /v1/databases", () => client.request<{ databases?: unknown[] }>("/v1/databases"), (data) => `${data.databases?.length ?? 0} database(s) · ${shape(data)}`);

  const appName = process.argv[2] ?? (apps?.projects?.[0] as { project_id?: string; name?: string } | undefined)?.project_id;
  if (appName) {
    await probe("App status", "GET /v1/projects/{name}", () => client.getAppStatus(appName));
    await probe("App logs", "GET /v2/projects/{name}/logs", () => client.getLogs(appName));
    await probe("App metrics", "GET /v1/projects/{name}/metrics/summary", () => client.getMetrics(appName));
    await probe("Release history", "GET /v1/projects/{name}/releases", () => client.getReleaseHistory(appName));
    await probe("Domains", "GET /v1/domains?project={name}", () => client.getDomains(appName));
  } else {
    rows.push({ operation: "Per-app routes", path: "/v1/projects/{name}/*", status: "ERR", note: "No existing app on this account; per-app reads need an app (pass a name as argument)." });
  }

  console.log("\nLiara read-only probe" + (appName ? ` (app: ${appName})` : ""));
  for (const row of rows) console.log(`${typeof row.status === "number" && row.status < 300 ? "✅" : "⚠️"} ${row.operation.padEnd(16)} ${row.path.padEnd(40)} HTTP ${String(row.status).padEnd(4)} ${row.note}`);

  // Same normalization the app uses, so these are exactly the plans the UI can offer.
  const catalog = me ? normalizeLiveCatalog(me, new Date().toISOString()) : undefined;
  if (catalog?.projects.length) {
    console.log("\nAvailable app plans (id · monthly Toman incl. bundle · CPU · RAM GB · disk GB · bundle):");
    for (const plan of catalog.projects) {
      console.log(`  ${plan.id.padEnd(18)} ${plan.monthlyToman.toLocaleString("en-US").padStart(12)}  ${String(plan.cpuCores).padStart(5)}  ${String(plan.memoryGb).padStart(5)}  ${String(plan.diskGb).padStart(5)}  ${plan.bundlePlanID ?? "-"}`);
    }
  }
}

main().catch(() => { console.error("Probe stopped; details withheld to avoid credential disclosure."); process.exitCode = 1; });
