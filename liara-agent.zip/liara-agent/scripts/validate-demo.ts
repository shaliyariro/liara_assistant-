import { spawn, type ChildProcess } from "node:child_process";
import { once } from "node:events";
import { createServer } from "node:net";
import { mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { loadEnvConfig } from "@next/env";
import { activateDemoSlowFailure, diagnoseDemoSlowFailure, executeDemoRecommendation, resetDemoService } from "@/lib/demo/local-slow-scenario";

loadEnvConfig(process.cwd());

async function main() {
  const port = await freePort();
  const baseUrl = `http://127.0.0.1:${port}`;
  const oldBaseUrl = process.env.DEMO_BROKEN_APP_URL;
  process.env.DEMO_BROKEN_APP_URL = baseUrl;
  const child = spawn(process.execPath, ["demo-broken-app/start-local-demo.js"], {
    cwd: process.cwd(), stdio: "ignore", windowsHide: true,
    env: { ...process.env, PORT: String(port), REQUIRE_DATABASE_URL: "0", DEMO_FAILURE: "off", DEMO_SLOW_MS: "2500" },
  });
  try {
    await waitReady(child, `${baseUrl}/health`);
    const startedAt = Date.now();
    const active = await activateDemoSlowFailure();
    assert(active.active, "The slow failure did not activate.");
    const diagnosis = await diagnoseDemoSlowFailure();
    assert(diagnosis.result.finding.causes[0]?.id === "slow_response", "The measured /slow response did not produce the expected FindingCard cause.");
    assert(diagnosis.recommendations[0]?.toolName === "disable_demo_failure", "The finding did not link to the local green fix tool.");
    const fix = await executeDemoRecommendation(diagnosis.sessionId, diagnosis.recommendations[0].id);
    assert(fix.verification.verified, "Before/after HTTP and metric verification failed.");
    assert(fix.verification.http?.before === 200 && fix.verification.http.after === 200, "The HTTP status did not remain healthy before and after.");
    assert(fix.verification.metric?.name === "slowResponseMs" && fix.verification.metric.before >= 2_000 && fix.verification.metric.after === 0, "Measured slowResponseMs did not improve to zero.");
    const elapsedMs = Date.now() - startedAt;
    assert(elapsedMs < 30_000, "Scenario B exceeded its 30-second FindingCard target.");
    const artifact = { createdAt: new Date().toISOString(), scenario: "B", source: "local demo-broken-app; no Liara API calls", approvals: 0, elapsedMs, finding: diagnosis.result.finding, recommendation: diagnosis.recommendations[0], verification: fix.verification };
    const outputDirectory = resolve("artifacts");
    await mkdir(outputDirectory, { recursive: true });
    const outputPath = resolve(outputDirectory, "demo-scenario-b.json");
    await writeFile(outputPath, `${JSON.stringify(artifact, null, 2)}\n`, "utf8");
    console.log(`Scenario B: PASSED in ${elapsedMs} ms`);
    console.log(`HTTP: ${fix.verification.http?.before} -> ${fix.verification.http?.after}`);
    console.log(`Metric: ${fix.verification.metric?.name} ${fix.verification.metric?.before} -> ${fix.verification.metric?.after}`);
    console.log(`Approval cards: 0`);
    console.log(`Evidence: ${outputPath}`);
  } finally {
    try { await resetDemoService(); } catch { /* The child may already have exited. */ }
    await stop(child);
    if (oldBaseUrl === undefined) delete process.env.DEMO_BROKEN_APP_URL;
    else process.env.DEMO_BROKEN_APP_URL = oldBaseUrl;
  }
}

async function freePort() {
  const server = createServer();
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("Could not allocate a local demo port.");
  await new Promise<void>((resolveClose, reject) => server.close((error) => error ? reject(error) : resolveClose()));
  return address.port;
}

async function waitReady(child: ChildProcess, url: string) {
  for (let attempt = 0; attempt < 60; attempt++) {
    if (child.exitCode !== null) throw new Error("The local demo server exited before becoming ready.");
    try { const response = await fetch(url, { signal: AbortSignal.timeout(500) }); if (response.ok) return; } catch { /* Startup is still in progress. */ }
    await new Promise((resolveDelay) => setTimeout(resolveDelay, 100));
  }
  throw new Error("The local demo server did not become ready in 6 seconds.");
}

async function stop(child: ChildProcess) {
  if (child.exitCode !== null) return;
  const exited = once(child, "exit").catch(() => undefined);
  child.kill();
  await Promise.race([exited, new Promise((resolveDelay) => setTimeout(resolveDelay, 2_000))]);
  if (child.exitCode === null) child.kill("SIGKILL");
}

function assert(condition: boolean, message: string): asserts condition { if (!condition) throw new Error(message); }

main().catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : "Demo validation failed.");
  process.exitCode = 1;
});
