// Ask the Liara AI assistant one question from the terminal: npm run assistant -- "سؤال"
import { loadEnvConfig } from "@next/env";
import { runAssistant } from "../src/lib/agent/assistant";

loadEnvConfig(process.cwd());

runAssistant([{ role: "user", content: process.argv[2] ?? "اپ‌هایم در چه وضعیتی هستند؟" }])
  .then((reply) => {
    console.log(`model: ${reply.model}`);
    for (const step of reply.steps) console.log(`${step.ok ? "✓" : "⚠"} ${step.tool}${step.appName ? ` (${step.appName})` : ""} ${step.ms} ms${step.note ? ` — ${step.note}` : ""}`);
    console.log(`\n${reply.answer}`);
  })
  .catch((error: Error & { userMessage?: string }) => { console.error(error.userMessage ?? error.message); process.exitCode = 1; });
