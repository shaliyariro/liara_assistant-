import { spawn, type ChildProcess } from "node:child_process";
import { once } from "node:events";
import { createServer } from "node:net";
import { mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { analyzeEvidence, verifyFix } from "@/lib/diagnosis/analyze";
import type { DiagnosisEvidence } from "@/lib/diagnosis/types";

type Child = { process: ChildProcess; logs: string[] };
const repoRoot = process.cwd();
const serverFile = resolve(repoRoot, "demo-broken-app/server.js");
const scenarios: Array<Record<string, unknown>> = [];
const activeChildren: Child[] = [];

function assert(condition: unknown, message: string): asserts condition { if (!condition) throw new Error(message); }

async function freePort() {
  const server = createServer();
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  const address = server.address();
  assert(address && typeof address === "object", "Could not reserve a local TCP port.");
  await new Promise<void>((resolveClose, reject) => server.close((error) => error ? reject(error) : resolveClose()));
  return address.port;
}

function startApp(port: number, databaseUrl?: string): Child {
  const child = spawn(process.execPath, [serverFile], { cwd: resolve(repoRoot, "demo-broken-app"), env: { ...process.env, PORT: String(port), REQUIRE_DATABASE_URL: "1", DATABASE_URL: databaseUrl ?? "" }, stdio: ["ignore", "pipe", "pipe"] });
  const logs: string[] = [];
  child.stdout?.on("data", (chunk: Buffer) => logs.push(chunk.toString("utf8")));
  child.stderr?.on("data", (chunk: Buffer) => logs.push(chunk.toString("utf8")));
  const handle = { process: child, logs };
  activeChildren.push(handle);
  return handle;
}

async function stopApp(child: Child) {
  if (child.process.exitCode !== null) return;
  child.process.kill();
  await Promise.race([once(child.process, "exit"), new Promise((resolveExit) => setTimeout(resolveExit, 2_000))]);
  const index = activeChildren.indexOf(child);
  if (index >= 0) activeChildren.splice(index, 1);
}

async function waitReady(child: Child, base: string) {
  const deadline = Date.now() + 8_000;
  while (Date.now() < deadline) {
    if (child.process.exitCode !== null) throw new Error(`Demo app exited early: ${child.logs.join("").slice(-600)}`);
    try { const response = await fetch(`${base}/health`, { signal: AbortSignal.timeout(500) }); if (response.ok) return; } catch { /* Wait until the child binds. */ }
    await new Promise((resolveWait) => setTimeout(resolveWait, 50));
  }
  throw new Error("Demo app did not start within eight seconds.");
}

async function json<T>(url: string, init?: RequestInit): Promise<{ response: Response; body: T; durationMs: number }> {
  const start = performance.now();
  const response = await fetch(url, init);
  const body = await response.json() as T;
  return { response, body, durationMs: Math.round(performance.now() - start) };
}

function evidence(appName: string, input: Partial<DiagnosisEvidence>): DiagnosisEvidence {
  return { appName, status: null, logs: [], metrics: null, releases: null, probe: null, limitations: [], observedAt: new Date().toISOString(), ...input };
}

async function run() {
  const v2StartedAt = Date.now();
  const missingEnvPort = await freePort();
  const missingEnv = startApp(missingEnvPort);
  const [exitCode] = await once(missingEnv.process, "exit");
  const startupLog = missingEnv.logs.join("").trim();
  const v2 = analyzeEvidence(evidence("demo-env", { logs: startupLog.split(/\r?\n/u) }), v2StartedAt);
  assert(exitCode !== 0 && v2.finding.causes[0]?.id === "incomplete_env", "V2 did not identify the missing DATABASE_URL from startup output.");
  const recoveredPort = await freePort();
  const recovered = startApp(recoveredPort, "postgres://demo:demo@127.0.0.1/demo");
  const recoveredBase = `http://127.0.0.1:${recoveredPort}`;
  await waitReady(recovered, recoveredBase);
  const recoveredHealth = await json<{ status: string }>(`${recoveredBase}/health`);
  assert(recoveredHealth.response.status === 200 && recoveredHealth.body.status === "ok", "V2 did not recover after supplying DATABASE_URL.");
  scenarios.push({ id: "V2", trigger: "Start without DATABASE_URL, then restart with a demo-only DATABASE_URL.", result: "passed", finding: v2.finding, recovery: { httpStatus: recoveredHealth.response.status, status: recoveredHealth.body.status }, elapsedMs: v2.elapsedMs, startupLog });

  const leakPort = await freePort();
  const leakApp = startApp(leakPort, "postgres://demo:demo@127.0.0.1/demo");
  const leakBase = `http://127.0.0.1:${leakPort}`;
  await waitReady(leakApp, leakBase);
  const beforeMetrics = await json<Record<string, number>>(`${leakBase}/metrics`);
  const v1StartedAt = Date.now();
  await json(`${leakBase}/controls`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ failure: "leak", enabled: true }) });
  await json(`${leakBase}/leak?chunks=12`, { method: "POST" });
  const afterMetrics = await json<Record<string, number>>(`${leakBase}/metrics`);
  const leakLog = await json<{ logs: Array<Record<string, unknown>> }>(`${leakBase}/demo-logs`);
  const v1 = analyzeEvidence(evidence("demo-oom", {
    status: { status: "running" },
    logs: leakLog.body.logs.map((line) => JSON.stringify(line)),
    metrics: { ...afterMetrics.body, rssGrowthBytes: afterMetrics.body.rssBytes - beforeMetrics.body.rssBytes },
    probe: { status: 200, durationMs: afterMetrics.durationMs, url: `${leakBase}/health` },
  }), v1StartedAt);
  assert(v1.finding.causes.some(({ id }) => id === "oom") && v1.finding.severity === "critical", "V1 did not identify measured retained memory as critical memory growth.");
  await stopApp(leakApp);
  const restartedPort = await freePort();
  const restarted = startApp(restartedPort, "postgres://demo:demo@127.0.0.1/demo");
  const restartedBase = `http://127.0.0.1:${restartedPort}`;
  await waitReady(restarted, restartedBase);
  const restartedMetrics = await json<Record<string, number>>(`${restartedBase}/metrics`);
  const restartedHealth = await json<{ status: string }>(`${restartedBase}/health`);
  const v1Verification = verifyFix(
    evidence("demo-oom", { metrics: { rssBytes: afterMetrics.body.rssBytes, leakedMegabytes: afterMetrics.body.leakedMegabytes }, probe: { status: 200, durationMs: afterMetrics.durationMs } }),
    evidence("demo-oom", { metrics: { rssBytes: restartedMetrics.body.rssBytes, leakedMegabytes: restartedMetrics.body.leakedMegabytes }, probe: { status: restartedHealth.response.status, durationMs: restartedHealth.durationMs } }),
  );
  assert(v1Verification.verified, "V1 restart did not verify with HTTP status and the measured leaked-memory metric.");
  scenarios.push({ id: "V1", trigger: "Enable leak and retain 12 measured 1 MiB chunks.", result: "passed", finding: v1.finding, measurements: { before: beforeMetrics.body, after: afterMetrics.body, afterRestart: restartedMetrics.body, retainedMegabytes: 12 }, fix: "Restarted the demo process.", verification: v1Verification, elapsedMs: v1.elapsedMs });

  const errorPort = await freePort();
  const errorApp = startApp(errorPort, "postgres://demo:demo@127.0.0.1/demo");
  const errorBase = `http://127.0.0.1:${errorPort}`;
  await waitReady(errorApp, errorBase);
  const v3StartedAt = Date.now();
  await json(`${errorBase}/controls`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ failure: "error500", enabled: true }) });
  const errorResponse = await json<{ error: string; stack: string }>(`${errorBase}/error500`);
  const errorLogs = await json<{ logs: Array<Record<string, unknown>> }>(`${errorBase}/demo-logs`);
  const v3 = analyzeEvidence(evidence("demo-error500", {
    status: { status: "running" },
    logs: errorLogs.body.logs.map((line) => JSON.stringify(line)),
    probe: { status: errorResponse.response.status, durationMs: errorResponse.durationMs, url: `${errorBase}/error500` },
  }), v3StartedAt);
  assert(errorResponse.response.status === 500 && v3.finding.causes[0]?.id === "application_500" && Boolean(v3.finding.issuePrompt), "V3 did not create a code issue prompt from the actual 500 stack trace.");
  scenarios.push({ id: "V3", trigger: "Enable intentional GET /error500 failure and capture the HTTP response and app log.", result: "passed", finding: v3.finding, issuePrompt: v3.finding.issuePrompt, elapsedMs: v3.elapsedMs, httpStatus: errorResponse.response.status });

  await Promise.all([stopApp(recovered), stopApp(restarted), stopApp(errorApp)]);
  const artifact = { createdAt: new Date().toISOString(), source: "local demo-broken-app; no Liara API writes", scenarios, allUnder30Seconds: scenarios.every((scenario) => Number(scenario.elapsedMs) < 30_000) };
  assert(artifact.allUnder30Seconds, "At least one scenario exceeded the 30-second finding target.");
  const outputDir = resolve(repoRoot, "artifacts");
  await mkdir(outputDir, { recursive: true });
  const outputFile = resolve(outputDir, "f03-validation.json");
  await writeFile(outputFile, `${JSON.stringify(artifact, null, 2)}\n`, "utf8");
  for (const scenario of scenarios) console.log(`${scenario.id}: passed in ${scenario.elapsedMs} ms`);
  console.log(`Saved evidence: ${outputFile}`);
}

run().catch(async (error: unknown) => {
  await Promise.all(activeChildren.map(stopApp));
  console.error(error instanceof Error ? error.message : "F03 validation failed.");
  process.exitCode = 1;
});
