import { randomBytes } from "node:crypto";
import { loadEnvConfig } from "@next/env";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { LiaraClient } from "../src/lib/liara/client";
import { LiaraError } from "../src/lib/liara/errors";

const execFileAsync = promisify(execFile);
type Result = { operation: string; path: string; status: number | "BLOCKED"; ok: boolean | null; note: string };
const results: Result[] = [];

loadEnvConfig(process.cwd());

function record(operation: string, path: string, status: number | "BLOCKED", ok: boolean | null, note: string) {
  results.push({ operation, path, status, ok, note });
  console.log(`${ok === null ? "⚠️" : ok ? "✅" : "❌"} ${operation} | ${path} | HTTP ${status} | ${note}`);
}

async function main() {
  if (!process.env.LIARA_API_TOKEN) {
    console.log("Liara spike: BLOCKED (LIARA_API_TOKEN is not set). No credential was requested or printed.");
    for (const [operation, path] of [
      ["List apps", "/v1/projects"], ["List plans", "/v1/me"], ["Create test app", "POST /v1/projects"],
      ["Upload source", "POST /v2/projects/{name}/sources"], ["Deploy release", "POST /v2/projects/{name}/releases"],
      ["Set env", "POST /v1/projects/update-envs"], ["Read logs", "GET /v1/projects/{name}/logs"],
      ["Read metrics", "GET /v1/projects/{name}/metrics/summary"], ["Restart app", "POST /v1/projects/{name}/actions/restart"],
      ["Delete test app", "DELETE /v1/projects/{name}"],
    ] as const) record(operation, path, "BLOCKED", null, "Skipped: no token in server environment.");
    process.exitCode = 2;
    return;
  }

  const name = process.env.LIARA_TEST_APP_NAME || `liara-spike-${randomBytes(4).toString("hex")}`;
  const planID = process.env.LIARA_TEST_PLAN_ID;
  const client = new LiaraClient();
  let created = false;
  let sourceID = "";
  const fixture = resolve("demo-broken-app");
  const temp = await mkdtemp(join(tmpdir(), "liara-spike-"));

  async function step(operation: string, path: string, action: () => Promise<{ status: number; data?: unknown; note?: string }>) {
    try {
      const response = await action();
      record(operation, path, response.status, true, response.note ?? "Request succeeded.");
      return response;
    } catch (error) {
      const e = error instanceof LiaraError ? error : undefined;
      record(operation, path, e?.status ?? "BLOCKED", false, e?.userMessage ?? "Request failed. Details were withheld to avoid exposing credentials.");
      return undefined;
    }
  }

  try {
    await step("List apps", "/v1/projects", async () => {
      const r = await client.listApps(); return { status: r.status, data: r.data };
    });

    const plansResponse = await step("List plans", "GET /v1/me", async () => {
      const r = await client.listPlans(); return { status: r.status, data: r.data };
    });

    if (!planID) {
      record("Create test app", "POST /v1/projects", "BLOCKED", null, "Set LIARA_TEST_PLAN_ID to an existing low-cost plan before creating a billable test app.");
      for (const [operation, path] of [["Upload source", "/v2/projects/{name}/sources"], ["Deploy release", "/v2/projects/{name}/releases"], ["Set env", "/v1/projects/update-envs"], ["Read logs", "/v1/projects/{name}/logs"], ["Read metrics", "/v1/projects/{name}/metrics/summary"], ["Restart app", "/v1/projects/{name}/actions/restart"], ["Delete test app", "DELETE /v1/projects/{name}"]] as const) {
        record(operation, path, "BLOCKED", null, "Skipped because no test app was created.");
      }
      return;
    }

    const planCatalog = plansResponse?.data as {
      plans?: { projects?: Record<string, { available?: boolean }> };
    } | undefined;
    const selectedPlan = planCatalog?.plans?.projects?.[planID];
    if (!selectedPlan || selectedPlan.available !== true) {
      const note = !selectedPlan
        ? "Configured plan ID is not present in the account's project-plan catalog. No create request was sent."
        : "Configured plan is marked unavailable in the account's project-plan catalog. No create request was sent.";
      record("Create test app", "POST /v1/projects", "BLOCKED", null, note);
      for (const [operation, path] of [["Upload source", "/v2/projects/{name}/sources"], ["Deploy release", "/v2/projects/{name}/releases"], ["Set env", "/v1/projects/update-envs"], ["Read logs", "/v1/projects/{name}/logs"], ["Read metrics", "/v1/projects/{name}/metrics/summary"], ["Restart app", "/v1/projects/{name}/actions/restart"], ["Delete test app", "DELETE /v1/projects/{name}"]] as const) {
        record(operation, path, "BLOCKED", null, "Skipped because the configured plan was not validated and no test app was created.");
      }
      return;
    }

    // G2 plans are sold with a bundle plan; use the configured one or the cheapest available.
    const bundles = (plansResponse?.data as { plans?: { projectBundlePlans?: Record<string, Record<string, { available?: boolean; price?: number }>> } } | undefined)?.plans?.projectBundlePlans?.[planID] ?? {};
    const bundlePlanID = process.env.LIARA_TEST_BUNDLE_PLAN_ID || Object.entries(bundles).filter(([, b]) => b.available).sort(([, a], [, b]) => (a.price ?? 0) - (b.price ?? 0))[0]?.[0];
    console.log(`Creating disposable app "${name}" on plan ${planID}${bundlePlanID ? ` + bundle ${bundlePlanID}` : ""}. It is deleted at the end.`);
    const create = await step("Create test app", "POST /v1/projects", async () => {
      const r = await client.createApp({ name, planID, ...(bundlePlanID ? { bundlePlanID } : {}), platform: "node" }); return { status: r.status };
    });
    created = Boolean(create);
    if (!created) return;

    const archivePath = join(temp, "source.tar.gz");
    const archive = await execFileAsync("tar", ["-czf", archivePath, "--exclude=node_modules", "--exclude=.env", "--exclude=*.log", "."], { cwd: fixture });
    if (archive.stderr?.trim()) console.log("Archive note: tar reported a message; contents are not printed.");
    const bytes = await readFile(archivePath);
    const uploaded = await step("Upload source", "/v2/projects/{name}/sources", async () => {
      const r = await client.uploadSource(name, new Blob([new Uint8Array(bytes)]), "source.tar.gz");
      sourceID = r.data.sourceID;
      return { status: r.status, data: r.data };
    });
    if (!uploaded || !sourceID) return;

    // Env goes in before the first release so the fixture boots (it requires DATABASE_URL and must bind 0.0.0.0).
    await step("Set env", "/v1/projects/update-envs", async () => {
      const r = await client.updateEnv(name, [
        { key: "SPIKE_MARKER", value: "phase-0" },
        { key: "HOST", value: "0.0.0.0" },
        { key: "DATABASE_URL", value: "postgres://demo:demo@127.0.0.1:5432/demo" },
      ]); return { status: r.status };
    });
    let releaseID = "";
    await step("Deploy release", "/v2/projects/{name}/releases", async () => {
      const r = await client.deployRelease(name, { sourceID, port: 3001, type: "node" });
      releaseID = r.data.releaseID; return { status: r.status };
    });
    if (releaseID) {
      const started = Date.now();
      let state = "";
      while (Date.now() - started < 300_000) {
        try { state = String((await client.getRelease(releaseID)).data.release.state).toUpperCase(); } catch { state = "UNKNOWN"; }
        if (["READY", "FAILED", "CANCELED", "UNHEALTHY"].includes(state)) break;
        await new Promise((done) => setTimeout(done, 5_000));
      }
      record("Release state", "GET /v1/releases/{id}", state === "READY" ? 200 : "BLOCKED", state === "READY", `Final state ${state || "unknown"} after ${Math.round((Date.now() - started) / 1000)} s.`);
    }
    const url = `https://${name}.iran.liara.run/health`;
    for (let attempt = 0; attempt < 12; attempt++) {
      const response = await fetch(url, { signal: AbortSignal.timeout(10_000) }).catch(() => undefined);
      if (response?.ok || attempt === 11) {
        record("Public HTTP check", "GET https://{name}.iran.liara.run/health", response?.status ?? "BLOCKED", Boolean(response?.ok), response ? "Measured live response." : "No response from the default subdomain.");
        break;
      }
      await new Promise((done) => setTimeout(done, 5_000));
    }
    await step("App status", "GET /v1/projects/{name}", async () => {
      const r = await client.getAppStatus(name); return { status: r.status };
    });
    await step("Read logs", "GET /v2/projects/{name}/logs", async () => {
      const r = await client.getLogs(name);
      const lines = JSON.stringify(r.data).match(/Demo Broken App listening/u) ? "startup line found" : "startup line not found";
      return { status: r.status, note: lines };
    });
    await step("Read metrics", "GET /v1/projects/{name}/metrics/summary", async () => {
      const r = await client.getMetrics(name); return { status: r.status };
    });
    await step("Release history", "GET /v1/projects/{name}/releases", async () => {
      const r = await client.getReleaseHistory(name); return { status: r.status };
    });
    await step("Domains", "GET /v1/domains?project={name}", async () => {
      const r = await client.getDomains(name); return { status: r.status };
    });
    await step("Restart app", "POST /v1/projects/{name}/actions/restart", async () => {
      const r = await client.restartApp(name); return { status: r.status };
    });
  } finally {
    if (created) await step("Delete test app", "DELETE /v1/projects/{name}", async () => {
      const r = await client.deleteApp(name); return { status: r.status };
    });
    await rm(temp, { recursive: true, force: true });
    console.log("\nJSON_RESULT=" + JSON.stringify(results));
  }
}

main().catch(() => {
  console.error("Liara spike stopped. Error details were withheld to avoid credential disclosure.");
  process.exitCode = 1;
});
