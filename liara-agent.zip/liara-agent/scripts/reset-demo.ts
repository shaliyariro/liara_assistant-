import { loadEnvConfig } from "@next/env";
import { resetDemoService } from "@/lib/demo/local-slow-scenario";

loadEnvConfig(process.cwd());

resetDemoService().then((result) => {
  console.log("Local demo state reset.");
  console.log(`Active failures: ${(result.failures ?? []).join(", ") || "none"}`);
  console.log(`Retained leak chunks: ${result.leakedChunks ?? 0}`);
  console.log(`Slow response metric: ${result.slowResponseMs ?? 0} ms`);
  console.log("No Liara resources were changed.");
}).catch((error: unknown) => {
  console.error(error instanceof Error ? error.message : "Local demo reset failed.");
  process.exitCode = 1;
});
