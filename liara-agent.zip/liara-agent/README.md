# دستیار هوشمند راه‌اندازی، دیپلوی و پایش با زیرساخت لیارا

دستیاری که مثل یک همکار فنی، برنامه‌نویسی را که دیپلوی بلد نیست از اولین دیپلوی تا عیب‌یابی سایت همراهی می‌کند: **اول تحلیل، بعد پرسش؛ اول پیشنهاد، بعد تأیید؛ اول اندازه‌گیری، بعد گزارش.**

این پروژه به روش **Spec-Driven Development** (Specification-Driven، مطابق رویکرد دوره‌ی DeepLearning.AI) ساخته می‌شود: ابتدا spec نوشته می‌شود و عامل کدنویس طبق آن پیاده‌سازی و با معیارهای validation بررسی می‌کند.

## ساختار مستندات

```
specs/
├── mission.md        ← چرا و برای چه کسی؛ اصول محصول؛ معیار موفقیت
├── tech-stack.md     ← تصمیم‌های فنی، امنیت، جدول قابلیت‌های API لیارا
├── roadmap.md        ← فازها، ترتیب، نقشه‌ی دمو، ریسک‌ها
└── features/
    ├── 01-analyze-and-plan.md   تحلیل پروژه + پیشنهاد پلن
    ├── 02-deploy-and-env.md     دیپلوی + مدیریت امن env
    ├── 03-sre-diagnosis.md      عیب‌یابی هوشمند + verify
    ├── 04-hitl-approvals.md     تأیید انسانی فقط برای موارد حساس + audit log
    └── 05-recommendation-engine.md   موتور «⭐ پیشنهاد من»
```

هر `feature` سه بخش دارد: **Plan** (چطور)، **Requirements** (چه)، **Validation** (چطور بفهمیم تمام شد).

## Prompt های توسعه

برای هر مرحله prompt آماده در `prompts/DEV_PROMPTS.md` است (فاز ۰، F04، F01، F02، F03، F05، دمو، بازبینی).

## دستور کار برای عامل کدنویس

1. قبل از هر کاری `specs/mission.md`، `tech-stack.md` و `roadmap.md` را بخوان.
2. فقط روی ویژگی‌ای کار کن که در `roadmap.md` نوبتش است.
3. هر انحراف از spec را **اول** در همان فایل ثبت کن، بعد کد بزن.
4. ویژگی وقتی تمام است که همه‌ی تیک‌های Validation خورده باشد.

## نیازمندی‌های مستند چالش و محل پوشش

| الزام چالش | محل |
|---|---|
| مستندات کوتاه معماری | `specs/tech-stack.md` §۱ و §۳ |
| نحوه‌ی اتصال به APIهای لیارا | `specs/tech-stack.md` §۲ |
| محدودیت‌های راهکار | `specs/tech-stack.md` جدول قابلیت‌ها (ردیف‌های ⚠️/❌) و `specs/mission.md` §۶ |
| نحوه‌ی تعامل کاربر با سیستم | `specs/mission.md` §۴ و `specs/features/*` (کارت‌های GenUI) |

## وضعیت

هسته‌ی F01–F05 و UI محلی پیاده‌سازی شده‌اند. تست‌ها، lint، typecheck و production build اجرا می‌شوند. تماس زنده‌ی Liara فقط برای لیست اپ‌ها و پلن‌ها (`HTTP 200`) تأیید شده است؛ عملیات ساخت اپ و دیپلوی واقعی هنوز با اپ دورریختنی آزمایش نشده‌اند. سناریوی محلی B به‌صورت کامل و ضبط‌پذیر validate شده است. وضعیت ریز در `/capabilities` و `specs/tech-stack.md` است.

| Demo area | Status |
|---|---|
| Project analysis, questions, plan comparison | Implemented; uses live/cached Liara catalog and displays stale status |
| Live deployment and env approval | Implemented and mock-validated; live Liara write path not verified |
| Local slow failure → FindingCard → green fix → before/after verify | Implemented and replayed in under 30 seconds |
| Liara list apps / list plans | Live HTTP 200 |
| OpenUI with the final hosted LLM provider | Not verified; the UI uses typed, allow-listed components |

**Recording status:** Scenario A is not yet cleared for a live recording. A connected Liara token is configured, but no demo GitHub repository is configured, `LIARA_TEST_PLAN_ID` is empty, and no disposable app has been created to validate write operations. The app will still show selectable plans from the live catalog, and every paid deployment requires the in-product approval.

## اجرای پروژه

نیازمند Node.js 20 یا جدیدتر است. پس از دسترسی به npm registry:

```sh
npm install
npm run dev
npm test
npm run build
```

پروژه RTL است و از فونت Vazirmatn استفاده می‌کند. تنظیمات محلی در `.env.local` قرار می‌گیرند (فایل از Git مستثنا است). توکن فقط در `LIARA_API_TOKEN` (بدون پیشوند `NEXT_PUBLIC_`) قرار می‌گیرد.

## Spike لیارا

```sh
npm run spike:liara
```

اسکریپت `.env.local` را بارگذاری می‌کند. برای ساخت و حذف اپ تستی، `LIARA_TEST_PLAN_ID` باید به یک پلن موجود اشاره کند. نام اختیاری اپ تستی را با `LIARA_TEST_APP_NAME` مشخص کنید. خروجی فقط نام عملیات، مسیر، status، نتیجه و یادداشت را چاپ می‌کند؛ توکن و بدنه‌ی پاسخ چاپ نمی‌شوند. اگر توکن تنظیم نشده باشد، اسکریپت همه‌ی عملیات را با وضعیت `BLOCKED` گزارش می‌کند.

## Demo Broken App

راهنمای runbook پنج‌دقیقه‌ای در `http://localhost:3000/demo` و جدول قابلیت‌ها در `http://localhost:3000/capabilities` است.

برای اجرای دستی سناریو B، در یک ترمینال:

```sh
npm run demo:broken
```

سپس در ترمینال دیگر `npm run dev` را اجرا و در `/demo` این مراحل را بزنید: فعال‌کردن کندی → جمع‌آوری شواهد → اجرای RecommendationCard → بررسی HTTP و متریک قبل/بعد. این سناریو فقط به سرویس لوکال وصل می‌شود و کارت تأیید ندارد.

برای اجرای ضبط‌پذیر و خودکار سناریو B:

```sh
npm run demo:validate
```

این اسکریپت سرویس را روی پورت آزاد موقت اجرا می‌کند، خرابی را فعال و رفع می‌کند، verify را assert می‌کند و transcript را در `artifacts/demo-scenario-b.json` می‌نویسد. برای reset حالت سرویس دستی، وقتی `demo:broken` در حال اجراست:

```sh
npm run demo:reset
```

Reset فقط state سرویس loopback را پاک می‌کند و هیچ منبع Liara را حذف یا تغییر نمی‌دهد. ابزارها و endpointهای نمونه در `demo-broken-app/README.md` شرح داده شده‌اند.

**Scenario A** از همین runbook با لینک GitHub آغاز می‌شود. برای ضبط تکرارپذیر، `DEMO_GITHUB_REPO_URL` را در `.env.local` تنظیم و ریپویی انتخاب کنید که `.env.example` و `.env` نمایشیِ غیرحساس داشته باشد. مقدار واقعی `.env` را در ریپوی عمومی نگذارید. ساخت/deploy زنده هزینه‌دار است؛ تنها پس از بررسی قیمت در کارت تأیید ادامه دهید. `LIARA_TEST_PLAN_ID` برای `spike:liara` لازم است و تا وقتی خالی است، spike هیچ write در Liara ارسال نمی‌کند.

## دستیار گفت‌وگو (Liara AI)

پنل «از دستیار بپرس» در صفحه‌ی اصلی، و همچنین دستور `npm run assistant -- "چرا سایتم کند شده؟"`، سؤال کاربر را به یک مدل زبانی روی Liara AI (سازگار با OpenAI) می‌فرستند.

مدل فقط این ابزارهای **خواندنی** را در اختیار دارد:
- فهرست اپ‌ها
- عیب‌یابی کامل
- وضعیت، لاگ و متریک
- تاریخچه‌ی release
- تست HTTP
- پلن‌ها و قیمت

هر نتیجه‌ی ابزار، پیش از رسیدن به مدل، از فیلتر حذف اطلاعات محرمانه عبور می‌کند. ابزارهای تغییردهنده اصلاً به مدل داده نمی‌شوند. اجرای اقدام‌ها از بخش‌های عیب‌یابی و دیپلوی و با کارت تأیید انجام می‌شود. ابزارهای اجراشده، به همراه زمان و نتیجه‌ی هرکدام، کنار هر پاسخ نمایش داده می‌شوند.

تنظیمات در `.env.local`:
- `LIARA_AI_BASE_URL=https://ai.liara.ir/api/v1/<شناسه>`
- `LIARA_AI_API_KEY`
- `LIARA_AI_MODEL`: فقط مدل‌هایی که در پلن سرویس هوش مصنوعی شما فعال‌اند کار می‌کنند. این پروژه با `anthropic/claude-sonnet-5.5` تست شده است.
- `LIARA_EXCLUDED_PLANS` (اختیاری): پلن‌هایی که حساب نمی‌تواند بخرد، مثلاً `*-g2`. این پلن‌ها از همه‌ی پیشنهادها حذف می‌شوند.

## ابزارهای بررسی لیارا

- `npm run probe:liara`: فقط خواندنی است. وضعیت مسیرهای API را نشان می‌دهد و پلن‌های قابل‌خرید را با قیمت ماهانه چاپ می‌کند.
- `LIARA_TEST_PLAN_ID=ir-small npm run spike:liara`: یک اپ آزمایشی می‌سازد و این مراحل را روی آن تست می‌کند:
  - env، آپلود و دیپلوی
  - وضعیت release و HTTP عمومی
  - لاگ، متریک، تاریخچه و دامنه
  - ری‌استارت

  در پایان، اپ را حذف می‌کند. این دستور **هزینه دارد**.

## دیپلوی روی سرور

راهنمای کامل در [deploy/DEPLOY.md](deploy/DEPLOY.md) است. به‌طور خلاصه:

```bash
sudo bash deploy/deploy.sh
```
