# Validation Handoff: Outstanding Tests and Jobs

**Purpose:** Give the next contributor a concrete checklist for finishing validation across phase 0 and F01–F05, including API probes, local jobs, browser checks, and full demo end-to-end (E2E) coverage.

**Status snapshot:** 2026-10-23, based on the repository specs and recorded run notes. This document does not claim that pending checks have been run. Re-run the commands below in the current environment and attach sanitized results before changing a checkbox in a feature spec.

## 1. Current state and handoff rules

- F01 unit/mock validations V1–V8 are recorded as passing. Live plan retrieval returned HTTP 200, but current account balance was not exposed; recharge remains a user action in the Liara console.
- F02 V1–V7 are recorded as passing against a mocked Liara API. The real-account app create, upload, release, env, and HTTP health-check path remains unverified.
- F03 local demo V1–V3 and demo scenario B are recorded as passing. F03 V4–V7 remain unchecked. Recorded trigger-to-Finding payload timings are under 30 seconds, but those timings do not measure browser paint.
- F04 V1–V10 are unchecked in its feature spec. Some related gate, audit, and secret-masking unit tests exist; run and map them to each requirement before marking any validation complete.
- F05 V1–V4 are recorded as passing at unit/model level. V4 does not exercise browser approval. V5 only tests idempotency with injected existing-service state; the production `/api/plans` route does not supply that state, and the three-click DBaaS flow is not implemented.
- Phase 0 live checks confirm `GET /v1/projects` and `GET /v1/me` returned HTTP 200. The remaining app write/read operations below are blocked or skipped, not proven unsupported.
- OpenUI CLI scaffolding and a deterministic typed RTL stream fixture exist. Runtime with the final LLM provider is not verified; no provider/key is configured for the project.
- Demo scenario B is local and replayable. Scenario A is not cleared for live recording: `DEMO_GITHUB_REPO_URL` and `LIARA_TEST_PLAN_ID` are not configured in the documented state.

### Safety and evidence rules

1. Never paste `LIARA_API_TOKEN`, `.env.local`, raw `.env` values, or private repository credentials into chat, tickets, test output, or this document. Keep secrets in local server-only environment variables.
2. Do not send a Liara write request until the user has selected a disposable test app name and reviewed the current plan price. Creating a project can incur charges. Delete only the disposable app created for this validation, after collecting the sanitized evidence.
3. Never create, change, or delete paid DBaaS services as part of the default runbook. `GET/POST /v1/databases` remain unverified in phase 0; validate read-only behavior first and keep service setup manual until separately approved.
4. Record operation, endpoint, HTTP status, pass/fail, elapsed time, and sanitized note. Do not print response bodies, auth headers, tokens, env values, or source archives.
5. Update feature checkboxes only when the stated assertion was actually executed. A unit test with fixtures does not prove live provider behavior or browser E2E.

## 2. Baseline local checks

Run from the project root and save terminal output without environment values:

```sh
npm test -- --reporter=dot
npx tsc --noEmit
npm run lint
npm run build
npm run demo:validate
npm run validate:f03
```

Expected outcomes:

- Every command exits successfully.
- `demo:validate` writes a replayable scenario B record to `artifacts/demo-scenario-b.json` and verifies HTTP plus the measured `slowResponseMs` before/after.
- `validate:f03` writes `artifacts/f03-validation.json`; inspect its assertions and timings, not only the exit code.
- Keep artifacts sanitized. Do not commit tokens, raw env, or private source content.

**Outstanding job:** Re-run this baseline on the handoff branch and record command versions, exit codes, test count, and artifact paths in the pull request or a separate sanitized results file.

## 3. Phase 0: Liara API and OpenUI spike

### API capability matrix to finish

| Operation | Current recorded state | Required validation job |
|---|---|---|
| List apps `GET /v1/projects` | ✅ Live HTTP 200 | Re-run read-only spike; confirm sanitized status only. |
| List plans `GET /v1/me` | ✅ Live HTTP 200 | Re-run and verify the returned available project-plan IDs. Do not treat an old catalog as current pricing. |
| Create disposable app `POST /v1/projects` | ⚠️ Not sent; plan unset in recorded state | After explicit price/name selection, create one disposable app and record status/name without response body. |
| Upload source `POST /v2/projects/{name}/sources` | ⚠️ Skipped | On that disposable app, upload the demo fixture and record HTTP status plus source ID only if safe to expose. |
| Deploy release `POST /v2/projects/{name}/releases` | ⚠️ Skipped | Deploy the uploaded fixture; verify response status and final readiness. |
| Set env `POST /v1/projects/update-envs` | ⚠️ Skipped | Use a synthetic sentinel secret, inspect only whether it was set, and verify sentinel absence from logs/audit/UI/model payload. |
| Read logs `GET /v1/projects/{name}/logs` | ⚠️ Skipped | Read a bounded window, redact secrets, compare the returned shape to the parser. |
| Read metrics `GET /v1/projects/{name}/metrics/summary` or CPU/RAM routes | ⚠️ Skipped; shape/granularity unknown | Probe supported route(s); record units, sampling window, and missing-field behavior. Do not invent values. |
| Restart `POST /v1/projects/{name}/actions/restart` | ⚠️ Skipped | Restart the disposable app and verify resulting state/health. |
| Delete disposable app `DELETE /v1/projects/{name}` | ⚠️ Skipped | Delete only the app created by this run and verify it no longer appears in the app list. |
| Start/stop scale, domains, rollback | ⚠️ Documented or unknown; not live-verified | Probe only if needed by a feature, with separate disposable-resource plan and approval. Rollback is currently unknown; do not guess an endpoint. |
| List DBaaS `GET /v1/databases` | ⚠️ Not live-verified | Read-only authenticated probe; record schema and existing-service identifiers in a private local artifact, not in public output. |
| Create DBaaS `POST /v1/databases` | ⚠️ Not live-verified | Keep out of this validation by default. Requires a separately approved paid-service test. |

### Spike runbook

1. Keep `LIARA_API_TOKEN` in `.env.local`; never put it in a command line or print it.
2. Inspect `LIARA_TEST_PLAN_ID` against the current live project-plan catalog. Plan IDs recorded in `specs/tech-stack.md` are historical and may change; check current availability and price in Liara.
3. Set `LIARA_TEST_APP_NAME` to a clearly disposable, unique name. Do not reuse a user app name.
4. Run `npm run spike:liara` only after deciding whether to authorize the full create/deploy/env/restart/delete sequence. The script performs writes when a valid plan ID is configured.
5. Capture only the script's operation/status/note table. Confirm cleanup succeeded; manually inspect the Liara console if deletion was not confirmed.
6. Update `specs/tech-stack.md` and `/capabilities` rows individually: ✅ only on successful live response; ❌ only when a confirmed unsupported operation exists; leave ⚠️ for untested/blocked behavior.

**Implementation follow-up:** The current spike reports whether plan listing succeeded but does not print available plan IDs. Improve the sanitized output or add a separate read-only plan-inspection command that prints only `{id, available, price, resources}`—never account identity, token, or raw response.

### OpenUI spike

- [ ] Open the root app and render the Persian/RTL `QuestionCard` from the deterministic streaming fixture; capture browser screenshot and console errors.
- [ ] Confirm chunked stream updates render in order and Zod rejects malformed/unknown component props.
- [ ] Decide/configure the final `LLMProvider` and run one model-backed stream with a non-secret prompt; record provider, latency, HTTP result, and failure handling.
- [ ] Confirm model output cannot name arbitrary React components and that fallback typed JSON renders the same card if provider/CLI runtime fails.
- [ ] Mark the roadmap OpenUI spike complete only after runtime/provider checks, or record the typed JSON fallback decision and its limits.

## 4. F01: Analyze and plan

The feature spec records V1–V8 as passing. Re-run or strengthen these checks during handoff:

- [ ] V1: Run the committed Django+Postgres, Next.js, and Node fixtures through the actual analyze API; assert language/framework, database, Dockerfile, Redis/worker/cron, env **names**, and build-size estimate.
- [ ] V2/V3: Browser E2E across all three fixtures; assert no more than four question cards and that each question has a visible “My recommendation” choice.
- [ ] V4: Place a sentinel only in a test `.env` and prove the analyzer reads `.env.example` names but never opens or emits `.env` values. Verify no value appears in request logs, UI, audit, or agent payload.
- [ ] V5: Force the live plan request to fail with and without cache. Assert a server-side `LimitationNotice`, no guessed plan IDs/prices, and a stale label when cached values are shown.
- [ ] V6/R8: Test the unavailable/low-balance path. Current Liara `/v1/me` response did not expose balance, so expected behavior may remain a console link plus an explicit user recharge task; after user returns, refresh plan/account data if supported.
- [ ] V7/R9: Measure trigger-to-first-ProjectCard browser paint on each fixture and a representative medium repository; target <30 seconds, excluding user wait time.
- [ ] V8: Usability test: a first-time user reaches PlanCard without facilitator instruction; capture task completion and time.
- [ ] Verify prices/resources shown in PlanCard match the current API response. Test cache stale state and timezone/time display.

## 5. F02: Deploy and environment

Mock suite V1–V7 and sentinel checks are recorded as passing, but the live Liara deployment portion is not. Run these jobs:

- [ ] V1: Browser E2E from analyzed GitHub repository to deployment. Count confirmation cards: only aggregate cost/plan and env-read consent; no separate create/set-env/upload/deploy cards. Keep total demo confirmations ≤3.
- [ ] V2: Repeat a unique env sentinel test end to end. Search SQLite audit rows, browser-visible text, server logs, captured model request, event stream, and uploaded source archive. Expected: zero raw sentinel occurrences except the direct Liara set-env request fixture/target. Ensure output files do not persist the sentinel.
- [ ] V3/R3/R4: Choose “No” on env read and assert manual masked form path. Choose project-scoped consent, confirm it is visible in settings, revoke it, and assert next read asks again. Confirm one-time consent is consumed once and cannot authorize another project.
- [ ] Generated secrets: assert they are generated on server, bypass the LLM, are masked in UI/audit/logs, and reach only Liara set-env payload.
- [ ] V4/R5/R6: On the disposable Liara app, observe named progress stages (clone/build/push/run/health). Make the app return 503, then 200. Never show success before a real HTTP health response succeeds. Record timings and sanitized build details.
- [ ] V5/R7: Deliberately make a fixture build fail. Confirm a user-readable error, next action, and automatic transfer into F03 without another prompt. If F03 cannot retrieve live evidence, show its limitation notice.
- [ ] V6/R9: Submit the same deployment twice and assert no duplicate app is created; verify behavior after timeout/retry and after a partial failure.
- [ ] V7: First-time user usability run from GitHub URL to live app URL. Only ask for GitHub URL and env values when necessary; record completion and total duration.
- [ ] Failure matrix: simulate failure at create, env update, upload, release, and health probe. Check cleanup/retry behavior and audit outcomes for each partial state.
- [ ] Verify the app's final public URL returns HTTP 200 from outside the process. Do not equate Liara release state with health.
- [ ] Delete the disposable Liara app after recording evidence and verify cleanup in console/list response.

## 6. F03: SRE diagnosis and verification

Local demo V1–V3 are recorded as passing. Run pending F03 spec validations and identify what can be tested only locally versus against Liara:

- [ ] V4/R8: Force a fix that does not change health/metrics. Verify the system reports failure and presents a red rollback ApprovalCard; verify no rollback occurs before approval. When Liara does not provide source/release fields or a verified rollback API, assert a limitation notice instead of sending a guessed request.
- [ ] V5/R9: Mock each missing metric field and a total metrics API failure. FindingCard must explicitly state CPU/RAM unavailable and include no fabricated numeric value. Verify evidence limitations appear in UI.
- [ ] V6/R10: Feed logs containing synthetic bearer token, password, API key, URL credentials, and env values. Capture the exact payload passed to a fake LLM provider and assert every sentinel is absent; preserve useful redacted context.
- [ ] V7: Usability test with a non-technical user. They should explain the finding, understand evidence vs hypothesis, and choose a safe action without facilitator help.
- [ ] R2: Assert at least three distinct evidence collectors are attempted in parallel; record individual failures as limitations without failing the whole finding.
- [ ] R3/R4: Validate cause ordering, confidence bounds (0–100), severity, and explicit uncertainty with OOM, crash-loop, missing env, database refusal, app 500, CPU/latency, and build failure fixtures.
- [ ] R6: Directly invoke each red action without valid approval (plan change, rollback, deletion) and assert rejection. Invoke green restart/set-env/redeploy only inside the valid project envelope and assert user notice plus audit record.
- [ ] R7: For successful repairs, compare real HTTP status and at least one actual resource/error metric before and after. Never use a metric that the provider did not return.
- [ ] R11: Measure browser-visible FindingCard time from user trigger, not just server payload creation. Target <30 seconds across the three demo failure types.
- [ ] Live read APIs: validate status, logs, release history, and metrics against a disposable app. Record schema, timestamp window, units, and missing-data behavior. The metrics summary route remains unverified.
- [ ] Confirm issue/prompt generation uses redacted stack traces and structured reproduction steps. GitHub issue creation is optional/stretch; copying a structured prompt is sufficient unless separately approved.

## 7. F04: Approval Gate, Approved Envelope, and audit

Run the unchecked V1–V10 from `specs/features/04-hitl-approvals.md`. Related unit tests exist, but that does not complete the unchecked spec validations.

- [ ] V1/R1: Directly call each red Tool with missing, malformed, expired, replayed, or mismatched approval; expect failure before side effects. Attempt to override `riskLevel` from the LLM/request and prove server Tool metadata remains authoritative.
- [ ] V2/R2: Full Scenario A browser trace. Exactly the aggregate cost/plan and env-read consent confirmations appear. Green create/set-env/upload/deploy inside the approved envelope show no approval card.
- [ ] V3/R3: Try second app, higher plan, extra service, and cost beyond envelope. Each must become red and ask for new approval; no mutation before approval.
- [ ] V4/R4–R5: Aggregate app plan + database + Redis costs and resources in one card using verified current catalog data. If DBaaS pricing/creation is not verified, show a limitation/manual item and do not imply that approval can provision it.
- [ ] V5/R6: Run a timed approval test with three users; report sample size and median click-to-accept time (<5 seconds). Do not count page load time as approval time.
- [ ] V6/R7: Prove “remember for this project” exists only for env consent; test project isolation, persistence, and revocation. Confirm no remember option for cost or destructive actions.
- [ ] V7/R8–R9: After scenarios A and B, inspect audit UI and SQLite rows. Every green/red action must include timestamp, actor, masked parameters, outcome, and user-visible result. Search for sentinel secrets in DB and rendered UI.
- [ ] V8/R10: Reject each approval type. Assert no action is executed, no extra “why?” question appears, and a safe alternative or explanation is offered.
- [ ] V9/R11: Record a complete five-minute demo and count rendered approval cards: Scenario A ≤2; Scenario B 0; total ≤3.
- [ ] V10/R12: Trigger unsupported balance/recharge, rollback, and DBaaS operations. Confirm a server-sourced `LimitationNotice` is displayed before any unsupported write request.
- [ ] Verify audit “undo” is present only when a tested inverse operation exists; never advertise undo for irreversible actions.
- [ ] Concurrency/replay tests: two approval submissions, stale approval ID, altered Tool input after card render, and duplicate HTTP request must not duplicate the side effect.

## 8. F05: Recommendation Engine

- [ ] V1/R1/R4: Django+Postgres+Celery+Redis E2E from analysis through recommendation. Ensure evidence refers to actual detected files/dependencies; verify proposed service steps stay manual while DBaaS write API is unverified.
- [ ] V2/R2: Connection-refused diagnosis must recommend endpoint/service checks, not a RAM upgrade. Add cases where restart/env repair succeeds before any paid-plan suggestion.
- [ ] V3/R2: Static project chooses the lowest currently available plan; reason explicitly references static files; price/resources match live or clearly stale catalog data.
- [ ] V4/R3: Browser click on a strong OOM recommendation must display the server-generated F04 ApprovalCard. Approve and reject paths must both be tested; no plan mutation on rejection.
- [ ] V5/R5: Wire existing-service detection into the production `/api/plans` flow. Test projects with Postgres+Redis already connected, each one individually connected, and neither connected. Repeated requests must not repeat service recommendations. If live DBaaS list cannot be verified, explicitly leave this automated behavior blocked and retain manual guidance.
- [ ] R1 guard: Expand validation beyond a short phrase blacklist. Test arbitrary vague reasons and require structured evidence + rule + proposal; do not allow unsupported prices or claims.
- [ ] R3: Assert each recommendation maps to a registered Tool. Green actions must execute the described safe action or clearly be guidance-only; red paid/destructive actions must route through ApprovalCard.
- [ ] R4: Test dependency mappings (`psycopg2`/Postgres, `celery` or `bullmq`/Redis) and avoid duplicate suggestions when service state says already connected.
- [ ] R6: Verify unsupported provider actions return manual guidance/limitation; no assumed DBaaS create/list endpoint or fabricated catalog price.
- [ ] UI E2E: RecommendationCard shows action, two-line evidence-based reason, financial/stability/downtime impact, alternative, and correct risk/action treatment. Confirm manual DBaaS guidance does not imply that a paid service was created.

## 9. Full demo E2E rehearsal

### Scenario A: GitHub repository to live app (target 0:30–2:30)

- [ ] Configure a public, disposable demo repository with `.env.example` and synthetic-only sample env data. Never commit real secrets.
- [ ] Set `DEMO_GITHUB_REPO_URL` locally. Choose a current available app plan, check price, and set `LIARA_TEST_PLAN_ID` only for the authorized test run.
- [ ] Start app, open `/demo`, and follow GitHub URL → ProjectCard → no more than four QuestionCards → PlanCard → aggregate cost card → env consent → deployment ProgressCard.
- [ ] Confirm only two approval cards appear (cost/plan and env permission). Check approval count in UI and audit log.
- [ ] Confirm env values never appear raw in UI, audit, logs, archive, or LLM request; verify synthetic values reach only the direct set-env path.
- [ ] Confirm progress stream reflects actual server events and the final “online” state requires external HTTP health success.
- [ ] Record total elapsed time, user wait time, app URL, sanitized API operation table, and final cleanup result.
- [ ] After recording, delete only the test app and confirm it is gone. Avoid leaving billable services running.

### Scenario B: Broken app to verified fix (target 2:30–4:00)

- [ ] Run `npm run demo:validate`; assert `/slow` returns measured slow response before the fix and HTTP 200 plus `slowResponseMs: 0` after `disable_demo_failure`.
- [ ] Open `/demo` for browser E2E: activate failure → enter “the site is slow” → collect evidence → FindingCard → recommended action → execute → verify before/after.
- [ ] Confirm evidence and RecommendationCard figures match probe output; no Liara metrics are claimed in this local scenario.
- [ ] Capture timer from user trigger to browser-visible FindingCard and final verification; capture zero approval cards for this reversible local fix.
- [ ] Reset via UI or `npm run demo:reset`; verify repeated rehearsal starts cleanly.

### Wrap-up (target 4:00–5:00)

- [ ] Open `/capabilities`; verify statuses match `specs/tech-stack.md` and use ⚠️ for untested (not unsupported) APIs.
- [ ] Show audit history and limitation messages; do not claim live deployment success if Scenario A did not use Liara.
- [ ] Keep recording within five minutes and total confirmations ≤3.
- [ ] Export sanitized demo transcript and validation timing artifacts; confirm they contain no secrets or private repository content.

## 10. Suggested execution order

1. Baseline local commands and current unit coverage.
2. Finish local F04 direct-gate, masking, envelope, consent-revocation, and rejection tests.
3. Finish F03 V4–V7 locally with fake provider/metrics and browser timing.
4. Fix F05 production existing-service-state wiring or document the blocker; add actual-route tests and RecommendationCard E2E.
5. Run F01 browser usability and first-card timing checks.
6. Perform read-only Liara probes and update the capability table.
7. Only after explicit cost/name selection, run the disposable Liara write/deploy/health/delete sequence for F02 and phase 0.
8. Rehearse scenarios A/B, update roadmap/spec checkboxes, and attach sanitized evidence.

## 11. Handoff notes / known implementation gaps

- The F05 production route currently calls `recommendForProject` with answers but omits `existingServices`; the V5 test injects existing service names directly. This is the main functional gap to close for idempotent recommendations.
- F05's helper Tool `manual_service_setup` only returns instructions. It does not create a service. Keep this distinction visible in UI and tests.
- F03 rollback depends on release source fields and has no verified general Liara rollback endpoint. Test the limitation branch; do not infer API support.
- F03 live metrics summary path and metric granularity are not verified; missing metric values must remain unknown.
- F02 live Liara deployment and health verification remain pending; mock 503→200 does not prove provider behavior.
- The Liara spike currently reports that plan listing succeeded but does not show IDs. A contributor needs a safe read-only way to inspect current available plan IDs before selecting a paid test plan.
- The final model provider is not configured. Until a provider is selected and tested, describe model-backed OpenUI/LLM checks as pending and keep deterministic typed fixtures clearly labeled as fixtures.

## 12. GitHub publication status

This workspace currently has no `.git` directory and no configured Git remote, so it cannot create a commit or push from this checkout yet. Once opened as the correct Git clone (or provided with its intended GitHub remote URL), add this file, review the diff for secrets, commit it, and push the branch for the next contributor.
