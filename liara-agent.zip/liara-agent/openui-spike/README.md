# OpenUI Spike

The official CLI command attempted from the repository root was:

```sh
npx @openuidev/cli@latest create openui-spike --name openui-spike --backend-framework vercel-ai-sdk --no-interactive --no-immediate --no-telemetry
```

The CLI produced no output and did not create the scaffold in this environment; a dependency install confirmed npm registry access fails with `EACCES`. The root app contains the minimal equivalent spike: a Zod-defined Persian `QuestionCard`, OpenUI Lang `Renderer`, and a chunked streaming route. Run `npm run dev` and click “نمایش کارت استریم‌شده” to inspect it after installing dependencies.

The stream is deterministic fixture data; the project has no selected final LLM provider yet. Once that provider is selected and configured, replace the fixture in `src/app/api/chat/route.ts` with its server-side stream.
