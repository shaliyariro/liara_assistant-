# Tech Stack — تصمیم‌های فنی و محدودیت‌ها

> بخشی از «constitution» (SDD). تصمیم‌ها اینجا ثبت می‌شوند؛ ویژگی‌ها باید با آن‌ها سازگار باشند.
> علامت ⚠️ یعنی «هنوز با مستندات رسمی لیارا تأیید نشده»؛ قبل از پیاده‌سازی باید تأیید شود.

## ۱. انتخاب‌ها

| لایه | انتخاب | دلیل |
|---|---|---|
| رابط کاربری | Next.js + TypeScript + Tailwind، RTL و فونت فارسی | دمو قوی، کارت‌های GenUI، سرعت توسعه |
| Generative UI | **OpenUI** (`@openuidev/react-lang`، و `react-ui` در صورت نیاز به اجزای آماده) | کتابخانه‌ی کامپوننت با schema Zod؛ system prompt از روی آن ساخته می‌شود؛ کارت‌ها همزمان با استریم رندر می‌شوند؛ اسکفولدر و چیدمان چت آماده → توسعه‌ی سریع‌تر |
| ارتباط زنده | Server-Sent Events (SSE) | نمایش پیشرفت دیپلوی و استریم پاسخ عامل |
| هسته‌ی عامل | حلقه‌ی LLM با tool use (سمت سرور) | تصمیم‌گیری و فراخوانی ابزارها |
| ابزارها (Tools) | ماژول‌های TypeScript با schema مشخص (Zod) | تست‌پذیر؛ بعداً قابل‌تبدیل به MCP |
| کلاینت لیارا | یک wrapper نازک روی REST API لیارا | یک نقطه‌ی کنترل برای احراز هویت، خطا و محدودیت‌ها |
| ذخیره‌سازی | SQLite (یا فایل JSON) برای audit log و تنظیمات | MVP ساده، بدون زیرساخت اضافه |
| زمان‌بندی | یک job سبک (cron داخل پروسه) برای health check | پایش سبک، نه ۲۴ ساعته‌ی سنگین |

**ریسک LLM:** دسترسی به API برخی ارائه‌دهندگان از ایران ممکن است محدود باشد. LLM را پشت یک interface (`LLMProvider`) بگذار تا تعویض ممکن باشد. ⚠️ ارائه‌دهنده‌ی نهایی باید قبل از دمو آزمایش شود.

**نتیجه‌ی Spike OpenUI:** کامپوننت RTL با Zod و renderer استریم در `src/lib/openui-library.tsx` و `src/components/cards/openui-stream-card.tsx` اسکفولد شده است. CLI رسمی `@openuidev/cli` در این محیط به‌دلیل خطای دسترسی npm (`EACCES`) اجرا نشد و نصب وابستگی‌ها هم ممکن نبود؛ بنابراین رندر runtime تأیید نشده. مسیر فعلی از fixture استریم‌شده استفاده می‌کند، نه ارائه‌دهنده‌ی نهایی LLM که هنوز انتخاب نشده است. اگر سازگاری runtime یا RTL تأیید نشد، fallback مصوب JSON تایپ‌شده و همان کامپوننت React است.

## ۲. اتصال به لیارا

- **Base URL:** `https://api.liara.ir` (تأیید از OpenAPI رسمی PaaS). ناحیه‌ی آلمان جداست (`--region` در CLI).
- **احراز هویت:** API Token از `console.liara.ir/API` ← «ساخت کلید جدید». برای تیم، شناسه‌ی تیم (Team ID) هم لازم است.
- **نگهداری توکن:** فقط سمت سرور در متغیر محیطی؛ هرگز به مرورگر یا پرامپت LLM نمی‌رود.
- **مرجع رفتار:** [OpenAPI رسمی لیارا](https://github.com/liara-cloud/openapi/blob/main/spec/paas.yaml) مرجع مسیرهای PaaS است؛ کد [CLI رسمی](https://github.com/liara-cloud/cli) هم برای عملیات پلن و جزئیات کلاینت استفاده شده است. مستندات وجود مسیر را نشان می‌دهند، اما موفقیت تماس با حساب واقعی را ثابت نمی‌کنند.

### جدول قابلیت‌ها و وضعیت تأیید API

مرجع رسمی مسیرها: [Liara OpenAPI PaaS](https://github.com/liara-cloud/openapi/blob/main/spec/paas.yaml). وضعیت تماس‌های احرازشده‌ی واقعی در جدول زیر آمده است؛ برای عملیات نوشتنی که هزینه دارند هنوز باید پلن تست انتخاب شود.

| قابلیت | مسیر رسمی مستندشده | وضعیت زنده |
|---|---|---|
| لیست اپ | `GET /v1/projects` | ✅ تماس زنده موفق؛ HTTP 200 |
| ساخت اپ | `POST /v1/projects` | ⚠️ اجرا نشد؛ `LIARA_TEST_PLAN_ID` خالی است؛ درخواست ساخت ارسال نشد |
| حذف اپ | `DELETE /v1/projects/{name}` | ⚠️ اجرا نشد؛ اپ تستی ساخته نشد |
| آپلود سورس و ساخت release | `POST /v2/projects/{name}/sources`, `POST /v2/projects/{name}/releases` | ⚠️ اجرا نشد؛ اپ تستی ساخته نشد |
| تنظیم env | `POST /v1/projects/update-envs` | ⚠️ اجرا نشد؛ اپ تستی ساخته نشد |
| restart | `POST /v1/projects/{name}/actions/restart` | ⚠️ اجرا نشد؛ اپ تستی ساخته نشد |
| start / stop | `POST /v1/projects/{name}/actions/scale` (`scale=1|0`) | ⚠️ مستندشده؛ در spike زنده اجرا نشده |
| لاگ اپ | `GET /v1/projects/{name}/logs?since=...` | ⚠️ اجرا نشد؛ اپ تستی ساخته نشد |
| متریک CPU/RAM | `GET /v1/projects/{name}/metrics/summary` یا `/metrics/cpu`, `/metrics/memory` | ⚠️ اجرا نشد؛ اپ تستی ساخته نشد و granularity تأیید نشده |
| لیست پلن‌ها | CLI رسمی `liara plan list` از `GET /v1/me` استفاده می‌کند | ✅ تماس زنده موفق؛ `GET /v1/me`، HTTP 200 |
| دامنه (افزودن/حذف/تأیید) | `GET/POST /v1/domains`, `GET /v1/domains/{id}/check` | ⚠️ مستندشده؛ تماس زنده انجام نشده |
| rollback به release قبلی | مسیر عملیاتی در فایل رسمی PaaS بررسی‌شده پیدا نشد | ⚠️ نامشخص؛ تماس زنده انجام نشده |
| شارژ حساب | — | ❌ فرض: ازطریق API ممکن نیست؛ کار کاربر در پنل |
| ثبت دامنه در ایرنیک | — | ❌ خارج از لیارا؛ فقط راهنما |

پلن‌های پروژه‌ای که در همین پاسخ زنده از Liara با `available: true` برگشتند: `ir-small`, `ir-medium`, `standard-base`, `standard-plus`, `pro`, `pro-plus`, `pro-max`, `small-g2`, `medium-g2`, `standard-base-g2`, `standard-plus-g2`, `pro-g2`, `pro-plus-g2`, `pro-max-g2`, `express-g2`. این شناسه‌ها پلن‌های پولی‌اند؛ پیش از انتخاب، هزینه‌ی جاری را در پنل Liara بررسی کنید. پلن `free` در پاسخ حساب `available: false` بود.

**قاعده:** ✅ یعنی تماس زنده با حساب واقعی موفق بوده است؛ ⚠️ یعنی عملیات هنوز اجرا نشده، نه اینکه API پشتیبانی نمی‌کند. ساخت اپ به پلن انتخابی نیاز دارد و ممکن است هزینه ایجاد کند. ردیف‌های باقی‌مانده پس از تست با اپ آزمایشی به ✅ یا ❌ تغییر می‌کنند. ❌ ها در UI به‌صورت «محدودیت» نمایش داده می‌شوند.

## ۳. قراردادهای معماری

1. **هر عملیات لیارا = یک Tool** با ورودی/خروجی typed، سطح ریسک (`green|red`) و تابع `describe()` برای متن کارت تأیید.
2. **عامل مستقیماً API نمی‌زند**؛ فقط از Tool Registry. دروازه‌ی تأیید (Approval Gate) قبل از اجرای Tool‌های 🔴 قرار دارد و قابل‌دورزدن نیست.
3. **خروجی عامل به UI = کارت‌های typed، نه متن آزاد.** کارت‌های توصیفی (`ProjectCard`, `QuestionCard`, `PlanCard`, `RecommendationCard`, `FindingCard`) با **OpenUI** تولید و رندر می‌شوند؛ کتابخانه‌ی کامپوننت‌ها تنها مجموعه‌ی مجاز است و props با Zod اعتبارسنجی می‌شود.
   - **استثنا (امنیتی):** `ApprovalCard`، `ProgressCard` و `LimitationNotice` **دست‌ساز و سمت سرور**اند و از متادیتای Tool و نتیجه‌ی واقعی اجرا پر می‌شوند، نه از متن مدل. سطح ریسک، هزینه و پیامد هرگز توسط LLM تولید نمی‌شود.
   - **اعداد حساس** (قیمت پلن، موجودی، مصرف منابع) در همه‌ی کارت‌ها از API لیارا می‌آیند و به‌صورت داده به کارت داده می‌شوند؛ مدل فقط قالب و متن توضیحی را می‌نویسد.
   - **جایگزین ساده:** اگر OpenUI در فاز ۰ مشکل RTL/فارسی یا ناپایداری استریم نشان داد، کارت‌ها با JSON تایپ‌شده و همان کامپوننت‌های React رندر می‌شوند (قرارداد کارت‌ها تغییر نمی‌کند).
4. **هر Tool خطای قابل‌فهم برمی‌گرداند** (`code`, `userMessage`, `retryable`)؛ خطای API لیارا ماسک و ترجمه می‌شود.
5. **idempotency:** دیپلوی/ری‌استارت دوباره‌زدن نباید خرابی ایجاد کند.

## ۴. امنیت (الزامی)

- `.env` کاربر فقط پس از اجازه‌ی صریح خوانده می‌شود (یک‌بار / این پروژه / نه).
- مقادیر محرمانه: **ماسک** در UI و لاگ، **حذف** از پرامپت LLM (فقط نام کلید و نوع به LLM می‌رسد).
- مقدار env توسط Tool مستقیم به API لیارا فرستاده می‌شود، بدون عبور از LLM.
- کلیدهای تولیدشده (مثل `SECRET_KEY`) سمت سرور ساخته و مستقیم روی لیارا ست می‌شوند.
- Audit log: هر اقدام (🟢 و 🔴) با زمان، کاربر، پارامترهای ماسک‌شده، نتیجه و امکان برگشت.
- توکن لیارا هرگز در لاگ چاپ نمی‌شود.

## ۵. کیفیت و تست

- هر Tool با mock تست واحد دارد و یک تست واقعی (در محیط تست لیارا) برای مسیر اصلی.
- **اپ نمونه‌ی خراب‌شدنی** (Demo Broken App): یک اپ کوچک با کلیدهای فعال‌سازی نشتی حافظه و خطای ۵۰۰؛ برای تکرارپذیری دمو.
- لاگ ساخت‌یافته (JSON) برای خود عامل، جدا از لاگ اپ کاربر.

## ۶. نسخه‌ها و ابزارها

نسخه‌ها در `package.json` قفل شوند؛ وابستگی‌های جدید باید در همین فایل با دلیل ثبت شوند.



## Phase 0 Live Verification (2026-10-23)

The live results below supersede the earlier note that no authenticated check was run. The Liara token stayed in the server environment and was never printed.

| Capability | Path | Result | Note |
|---|---|---|---|
| List apps | `GET /v1/projects` | ✅ HTTP 200 | Authenticated request succeeded. |
| List plans | `GET /v1/me` | ✅ HTTP 200 | Authenticated request succeeded; no free plan was available. |
| Create test app | `POST /v1/projects` | ⚠️ Blocked by account | 2026-10-23 live attempt: `small-g2`+`basic` → HTTP 400 `g2_plan_unavailable`; `ir-small` → HTTP 402 (no balance). Nothing created. |
| Upload source | `POST /v2/projects/{name}/sources` | ⚠️ Skipped | Plan was not validated and no test app was created. |
| Deploy release | `POST /v2/projects/{name}/releases` | ⚠️ Skipped | Plan was not validated and no test app was created. |
| Set env | `POST /v1/projects/update-envs` | ⚠️ Skipped | Plan was not validated and no test app was created. |
| Read logs | `GET /v1/projects/{name}/logs` | ⚠️ Skipped | Plan was not validated and no test app was created. |
| Read metrics | `GET /v1/projects/{name}/metrics/summary` | ⚠️ Skipped | Plan was not validated and no test app was created. |
| Restart | `POST /v1/projects/{name}/actions/restart` | ⚠️ Skipped | Plan was not validated and no test app was created. |
| Delete test app | `DELETE /v1/projects/{name}` | ⚠️ Skipped | Plan was not validated and no test app was created. |

| List DBaaS services | [`GET /v1/databases`](https://github.com/liara-cloud/openapi/blob/main/spec/dbaas.yaml) (documented) | ✅ HTTP 200 (2026-10-23, `npm run probe:liara`) | Read-only listing works; account returned `{databases: []}`. Creation stays manual. |
| Create DBaaS service | [`POST /v1/databases`](https://github.com/liara-cloud/openapi/blob/main/spec/dbaas.yaml) (documented) | ⚠️ Not live-verified | No write request was sent; F05 only shows manual setup instructions and live catalog price if available. |

OpenUI: the official CLI `@openuidev/cli@0.6.0` successfully scaffolded `openui-cli-spike/` with its Vercel AI SDK example. Its generated project requires a Thesys API key for model backed responses. The root project separately exercises the OpenUI Lang renderer with a typed Persian RTL QuestionCard and deterministic streamed fixture, so no model key is needed for the rendering spike. The CLI scaffold itself is not the implementation used by the root app.
