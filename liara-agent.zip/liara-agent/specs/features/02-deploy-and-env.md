﻿# F02 — دیپلوی و مدیریت متغیرهای محیطی

**وضعیت:** Draft · **وابستگی:** F01، F04 · **ریسک:** 🔴 فقط تأیید هزینه/پلن و خواندن `.env`؛ بقیه‌ی مراحل (ساخت اپ، ست env، آپلود، دیپلوی) 🟢 و خودکار داخل چارچوب تأییدشده

---

## Plan

### هدف
پس از تأیید پلن، عامل اپ را روی لیارا می‌سازد، env را امن ست می‌کند، دیپلوی می‌کند و آنلاین‌شدن را تأیید می‌کند.

### مراحل
1. **کارت تجمیعی هزینه و پلن (🔴، تنها تأیید اصلی):** «اپ روی پلن X + اقلام لازم، جمعاً Y تومان در ماه. تأیید؟» با تأیید آن، «چارچوب تأییدشده» (F04) ساخته می‌شود و بقیه‌ی مراحل بدون پرسش پیش می‌روند.
2. **Tool `create_app`** (🟢 در چارچوب): نام اپ، پلتفرم (مثلاً Node/Django/Docker)، پلن از F01.
3. **مدیریت env:**
   - کارت اجازه: «۸ متغیر لازم پیدا کردم. اجازه‌ی خواندن `.env` را می‌دهی؟» → **یک‌بار / برای این پروژه / نه** (🔴).
   - اگر اجازه: مقادیر خوانده و **ماسک‌شده** نمایش (`sk-••••3f2a`)، بدون ارسال به LLM.
   - اگر «نه»: فقط نام کلیدها؛ مقدارها را کاربر در فرم امن وارد می‌کند (فیلد password-masked).
   - کلیدهای تولیدشدنی (`SECRET_KEY` و مشابه): «بسازم؟» ← تولید امن سمت سرور.
   - **Tool `set_env`** (🟢): ارسال مستقیم به API لیارا؛ فقط یک پیام کوتاه «✓ N متغیر ست شد».
4. **Tool `upload_source`** (🟢): بسته‌بندی ریپو و آپلود. ⚠️ فرمت دقیق (`.tar.gz`) تأیید شود.
5. **Tool `deploy_release`** (🟢) + استریم پیشرفت: کلون ← بیلد ← پوش ← اجرا ← health check.
6. **Health check نهایی:** درخواست HTTP به آدرس اپ؛ اعلام «آنلاین ✅» با لینک.
7. **شکست در هر مرحله:** عامل خودکار وارد جریان F03 (حالت «خطای دیپلوی») می‌شود، بدون اینکه کاربر چیزی بپرسد.

### نوار پیشرفت (`ProgressCard`)
مراحل زنده با وضعیت (در انتظار / در حال اجرا / موفق / ناموفق)، زمان سپری‌شده، و دکمه‌ی «جزئیات» برای لاگ ساخت (پیش‌فرض بسته).

---

## Requirements

| شناسه | نیازمندی |
|---|---|
| R1 | کاربر برای کل مسیر ساخت+env+دیپلوی فقط **دو** تأیید می‌دهد: کارت تجمیعی هزینه/پلن و اجازه‌ی خواندن `.env`. ساخت اپ، ست env، آپلود و دیپلوی بدون کارت تأیید اجرا می‌شوند. |
| R2 | هیچ مقدار env در UI، audit log، لاگ سرور یا پرامپت LLM به‌صورت خام ظاهر نمی‌شود. |
| R3 | خواندن `.env` بدون اجازه‌ی صریح ممکن نیست؛ انتخاب «نه» مسیر جایگزین (ورود دستی ماسک‌شده) را باز می‌کند. |
| R4 | اجازه‌ی «برای این پروژه» قابل‌لغو است و در تنظیمات دیده می‌شود. |
| R5 | پیشرفت دیپلوی زنده و با مراحل نام‌دار نمایش داده می‌شود. |
| R6 | موفقیت دیپلوی فقط با health check HTTP واقعی اعلام می‌شود، نه صرفاً «بیلد تمام شد». |
| R7 | خطا در هر مرحله پیام قابل‌فهم + اقدام بعدی پیشنهادی دارد و به F03 تحویل می‌شود. |
| R8 | اگر مرحله‌ای ازطریق API ممکن نیست (مثلاً شارژ)، `LimitationNotice` با راه‌حل دستی نمایش داده می‌شود. |
| R9 | تکرار دیپلوی (اجرای دوباره) بدون ساخت اپ تکراری کار می‌کند (idempotent). |

---

## Validation

- [x] **V1 (R1):** سناریوی کامل با شمارش تأییدها؛ تعداد کارت‌های تأیید ≤ ۲ و هیچ‌کدام برای ساخت اپ/env/دیپلوی نیست.
- [x] **V2 (R2):** جست‌وجوی خودکار (grep) در audit log، لاگ سرور و payload ارسالی به LLM با یک مقدار env تستی؛ نتیجه صفر.
- [x] **V3 (R3/R4):** انتخاب «نه» ← مسیر ورود دستی؛ لغو اجازه‌ی پروژه ← خواندن بعدی دوباره سؤال می‌کند.
- [ ] **V4 (R5/R6):** یک دیپلوی واقعی روی لیارا؛ آدرس اپ پاسخ ۲۰۰ می‌دهد و عامل همان را گزارش می‌کند.
- [x] **V5 (R7):** یک بیلد عمداً خراب؛ عامل بدون پرسش وارد عیب‌یابی می‌شود و علت را نشان می‌دهد.
- [x] **V6 (R9):** دو بار اجرای پشت‌سرهم؛ اپ تکراری ساخته نمی‌شود.
- [ ] **V7 (UX):** از لینک گیت‌هاب تا آدرس زنده بدون تایپ‌کردن چیزی جز لینک و (در صورت نیاز) مقادیر env.

## Implementation validation (2026-10-23)

- Automated F02 V1-V7 suite: passed (mock Liara API; 7 tests).
- V2 sentinel check: passed across SQLite audit entries, emitted/server-visible events, captured console output, LLM payload fixture, and uploaded source archive; the mocked Liara `set_env` payload receives the value directly.
- V4 exercises HTTP 503 then 200 and verifies that 503-only never emits success. No live Liara app was created or billed, so the real-account deployment portion of V4 remains unverified.
- F02 currently provisions only the selected app plan and required app bundle. Suggested database/Redis services are not included in this deployment approval or provisioned by this flow.
- Project checks: `npm test -- --reporter=dot` (25 passed), `npx tsc --noEmit` (passed), `npm run lint` (passed); production build passed (`npm run build`).


## Validation run (2026-10-23, deploy handoff)

- V1, V2, V3, V5, V6 ticked on the **mocked Liara API** suite (`src/lib/deploy/pipeline.test.ts`, re-run: 38/38 tests passing). They prove the app logic, not live Liara behavior.
- V4 stays open: the account has no apps and a live create/deploy is billable (cheapest available plan: `small-g2`, about 750,000 Toman/month with the `basic` bundle, billed by usage). It needs the owner's explicit approval.
- V7 stays open: needs a browser E2E run from a GitHub link to a live URL, which depends on V4.
