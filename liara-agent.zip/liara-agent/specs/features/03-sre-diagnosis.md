﻿# F03 — عیب‌یابی هوشمند (نقش SRE) و بررسی نتیجه

**وضعیت:** Draft · **وابستگی:** F02، F04 · **ریسک:** 🟢 جمع‌آوری شواهد، ری‌استارت، ست env، redeploy / 🔴 تغییر پلن (هزینه)، rollback

---

## Plan

### هدف
وقتی سایت کند شد، خطا داد یا دیپلوی شکست خورد، **خود عامل** لاگ و وضعیت را می‌خواند، علت را پیدا و رتبه‌بندی می‌کند، یافته را در یک کارت ساده نشان می‌دهد، با تأیید کاربر اصلاح می‌کند و نتیجه را اندازه می‌گیرد. کاربر فقط اگر بخواهد لاگ خام را می‌بیند.

### محرک‌ها (بدون پایش ۲۴ ساعته‌ی سنگین)
1. پیام کاربر: «سایت کنده» / «ارور ۵۰۰ می‌گیرم» / دکمه‌ی «بررسی سلامت».
2. شکست دیپلوی (از F02).
3. *(Stretch)* health check زمان‌بندی‌شده‌ی سبک که فقط هنگام خطا عامل را بیدار می‌کند.

### جریان

```
محرک
 → Tool های جمع‌آوری شواهد (موازی، 🟢):
     get_app_status · get_logs · get_metrics · get_release_history · http_probe
 → تشخیص الگو (قواعد + LLM)
 → رتبه‌بندی علت‌ها با درصد اطمینان
 → FindingCard (شدت + علت + شواهد + راه‌حل‌ها)
 → تأیید کاربر (F04)
 → اجرای اصلاح
 → verify_fix: اندازه‌گیری قبل/بعد
 → گزارش (موفق ✅ یا پیشنهاد rollback)
```

### الگوهای تشخیص اولیه

| الگو | نشانه‌ها (شواهد) | شدت پیش‌فرض | اصلاح‌های ممکن |
|---|---|---|---|
| کمبود حافظه / OOM | RAM نزدیک سقف، ری‌استارت‌های پیاپی، لاگ `Killed`/`OOM`/heap | 🔴 بحرانی | ارتقای RAM (🔴)، بهینه‌سازی کد، ری‌استارت موقت (🟢) |
| Crash loop | ری‌استارت مکرر، exit code غیرصفر پس از استارت | 🔴 بحرانی | بررسی آخرین release، rollback (🔴)، تصحیح env |
| متغیر محیطی ناقص/غلط | `KeyError`/`undefined`/اتصال رد شده، شروع‌نشدن اپ | 🟠 مهم | `set_env` (🟢) + redeploy |
| خطای ۵۰۰ برنامه | stack trace در لاگ، مسیر مشخص | 🟠 مهم | پرامپت/Issue برای عامل کدنویس؛ rollback |
| اتصال دیتابیس | timeout/refused/too many connections | 🟠 مهم | بررسی env دیتابیس، pool، پلن دیتابیس |
| CPU محدود / کندی | زمان پاسخ بالا، CPU بالا، بدون خطای برنامه | 🟡 هشدار | ارتقای پلن (🔴)، کش، بهینه‌سازی |
| شکست بیلد | خطای `npm`/`pip`، نبود وابستگی، Dockerfile | 🟠 مهم | اصلاح وابستگی/فایل ← redeploy |

### FindingCard (ساختار)
- **شدت:** بحرانی / مهم / هشدار (رنگ + آیکن)
- **چه شد؟** یک جمله ساده برای غیرفنی.
- **شواهد:** ۲–۳ خط لاگ مرتبط + نمودار کوچک منابع (باز/بسته). ⚠️ فقط اگر متریک API موجود است.
- **علت‌ها:** فهرست با درصد اطمینان (مثلاً کمبود RAM ۸۵٪، نشتی حافظه ۱۰٪).
- **راه‌حل‌ها:** ⭐ پیشنهاد من + حداقل یک جایگزین؛ هرکدام با هزینه، downtime، و قابل‌برگشت‌بودن.
- **دکمه‌ها:** «درستش کن» · «فقط توضیح بده» · «لاگ‌ها را نشان بده».

### اتصال به عامل کدنویس
اگر علت در کد است (نه زیرساخت)، عامل یک **Issue/پرامپت ساخت‌یافته** می‌سازد: stack trace، فایل/خط مشکوک، فرضیه، گام‌های بازتولید. خروجی: «کپی کن» یا ساخت Issue در گیت‌هاب. *(Stretch: پیشنهاد patch و اعمال پس از تأیید.)*

---

## Requirements

| شناسه | نیازمندی |
|---|---|
| R1 | عامل لاگ و وضعیت را خودش می‌خواند؛ کاربر مجبور نیست چیزی کپی/پیست کند. |
| R2 | حداقل ۳ منبع شواهد (وضعیت، لاگ، تاریخچه‌ی release یا متریک) بررسی و گزارش می‌شود. |
| R3 | علت‌ها با درصد اطمینان رتبه‌بندی می‌شوند و عدم‌قطعیت صادقانه بیان می‌شود. |
| R4 | هر یافته شدت (بحرانی/مهم/هشدار) دارد. |
| R5 | `FindingCard` برای غیرفنی قابل‌فهم است: توضیح ساده بالا، جزئیات فنی پایین (باز/بسته). |
| R6 | اقدام‌های 🔴 (تغییر پلن/هزینه، rollback، حذف) بدون تأیید (F04) اجرا نمی‌شوند؛ اقدام‌های 🟢 (ری‌استارت، ست env، redeploy) خودکار انجام و با نتیجه گزارش می‌شوند. |
| R7 | پس از اصلاح، `verify_fix` حداقل وضعیت HTTP و یک شاخص منابع/خطا را قبل و بعد مقایسه می‌کند. |
| R8 | اگر verify شکست خورد، عامل خودکار پیشنهاد رولبک می‌دهد (با تأیید). |
| R9 | هرجا داده‌ای از API در دسترس نیست (مثلاً CPU لحظه‌ای)، `LimitationNotice` نمایش داده شده و تحلیل به شواهد موجود محدود می‌شود؛ عامل عدد جعل نمی‌کند. |
| R10 | لاگ‌ها قبل از ارسال به LLM از اسرار (توکن، رمز، کلید) پاک‌سازی می‌شوند. |
| R11 | زمان از محرک تا نمایش `FindingCard` در سناریوی دمو کمتر از ۳۰ ثانیه است. |

---

## Validation

با **اپ نمونه‌ی خراب‌شدنی**، سه سناریوی قابل‌تکرار:

- [x] **V1 — OOM:** فعال‌سازی نشتی حافظه ← «سایت کنده» ← یافته: کمبود حافظه، شدت بحرانی، ⭐ ارتقای RAM یا ری‌استارت ← تأیید ← verify: RAM و خطا قبل/بعد گزارش می‌شود. (R1–R7, R11)
- [x] **V2 — env ناقص:** حذف یک env حیاتی ← دیپلوی/اجرا خطا ← عامل کلید گم‌شده را نام می‌برد و `set_env` را پیشنهاد می‌دهد ← redeploy ← آنلاین. (R2, R6)
- [x] **V3 — ۵۰۰ برنامه:** فعال‌سازی endpoint خراب ← یافته با stack trace و مسیر ← کارت «Issue برای عامل کدنویس» ساخته می‌شود. (R3, R4)
- [x] **V4 (R8):** verify عمداً شکست بخورد (اصلاح بی‌اثر) ← عامل رولبک پیشنهاد می‌کند.
- [x] **V5 (R9):** با خاموش‌کردن متریک در mock، کارت صراحتاً می‌گوید «CPU/RAM در دسترس نیست» و عدد نمی‌سازد.
- [x] **V6 (R10):** لاگ تستی با توکن جعلی ← در payload ارسالی به LLM وجود ندارد.
- [ ] **V7 (UX):** نفر ناآشنا یافته را بدون دانش فنی توضیح می‌دهد.


## Implementation validation (2026-10-23)

- V1-V3 passed using the local `demo-broken-app`. Repeat with `npm run validate:f03`; the script writes a replayable transcript and measured before/after values to `artifacts/f03-validation.json`.
- Trigger-to-finding payload timings in the latest run: V1 70 ms, V2 173 ms, V3 41 ms; each is below 30 seconds. These timings end at the Finding payload, not browser paint.
- V1 restarted the local process and verified HTTP plus the same measured RSS metric before and after. V2 restarted the local process after providing `DATABASE_URL`; it did not call Liara `set_env` or deploy. V3 captured the actual 500 response and stack trace into an issue prompt.
- Diagnosis rules and secret redaction ran locally. No LLM provider is configured, so no model payload was sent. Redaction is tested before any future model use.
- Liara logs/releases use the routes implemented in the official CLI. Resource metrics are shown only when the API returns numeric fields; otherwise the card carries a LimitationNotice. The `metrics/summary` route remains unverified against the official CLI and may return that notice.
- Rollback creates a new release from a prior release source when Liara returns a READY release with `sourceAvailable`, `sourceID`, platform, and port. It does not roll back database state. If those fields are absent, no rollback request is sent and the UI explains the limitation.
- Demo recording scenario B uses a separate loopback adapter: it measures `/slow`, renders FindingCard/RecommendationCard, runs `disable_demo_failure` and verifies HTTP 200 plus `slowResponseMs` (2500 → 0). `npm run demo:validate` passed in about 3 seconds. It does not prove any Liara metrics or restart endpoint.


## Validation run (2026-10-23, deploy handoff)

- V4–V6 added as automated tests in `src/lib/diagnosis/validation.test.ts`:
  - V4: an ineffective fix (500 → 500, errors rising) gives `verified: false, rollbackSuggested: true`, and the finding offers a red rollback to the prior READY release with an available source.
  - V5: when the metrics tool fails, `collectDiagnosis` returns `metrics: null` with "Resource metrics unavailable", and the finding has no CPU/RAM values.
  - V6: a fake token in Liara logs, release `failReason` and auth headers is absent from the collected evidence, the analysis payload and the SQLite audit rows.
- V7 is a human UX check and stays open.
