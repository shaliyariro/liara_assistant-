#!/usr/bin/env bash
# Liara Agent — one-command deploy for Ubuntu/Debian servers.
#
#   sudo bash deploy/deploy.sh            # install or update (default)
#   sudo bash deploy/deploy.sh status     # service + health summary
#   sudo bash deploy/deploy.sh logs       # follow application logs
#   sudo bash deploy/deploy.sh restart    # restart services
#   sudo bash deploy/deploy.sh rollback   # switch back to the previous release
#
# Run it from the project root you copied to the server. Settings come from
# deploy/deploy.conf (optional) and secrets from .env.local in the project root.
set -Eeuo pipefail

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
[[ -f "$SRC_DIR/deploy/deploy.conf" ]] && source <(tr -d '\r' < "$SRC_DIR/deploy/deploy.conf")

APP_NAME="${APP_NAME:-liara-agent}"
APP_USER="${APP_USER:-liara-agent}"
APP_PORT="${APP_PORT:-3000}"
DEMO_PORT="${DEMO_PORT:-3001}"
ENABLE_DEMO="${ENABLE_DEMO:-1}"
DOMAIN="${DOMAIN:-}"
LETSENCRYPT_EMAIL="${LETSENCRYPT_EMAIL:-}"
BASIC_AUTH_USER="${BASIC_AUTH_USER:-admin}"
BASIC_AUTH_PASSWORD="${BASIC_AUTH_PASSWORD:-}"
NODE_MAJOR="${NODE_MAJOR:-22}"
NPM_REGISTRY="${NPM_REGISTRY:-}"
KEEP_RELEASES="${KEEP_RELEASES:-3}"

BASE_DIR="/opt/$APP_NAME"
RELEASES_DIR="$BASE_DIR/releases"
CURRENT_LINK="$BASE_DIR/current"
DATA_DIR="/var/lib/$APP_NAME"
ETC_DIR="/etc/$APP_NAME"
ENV_FILE="$ETC_DIR/app.env"
HTPASSWD_FILE="/etc/nginx/$APP_NAME.htpasswd"

c_blue=$'\e[34m'; c_green=$'\e[32m'; c_yellow=$'\e[33m'; c_red=$'\e[31m'; c_off=$'\e[0m'
step() { echo; echo "${c_blue}==> $*${c_off}"; }
ok()   { echo "${c_green}✔ $*${c_off}"; }
warn() { echo "${c_yellow}⚠ $*${c_off}"; }
die()  { echo "${c_red}✘ $*${c_off}" >&2; exit 1; }
trap 'die "Deploy failed at line $LINENO. Nothing was switched unless noted above."' ERR

require_root() { [[ $EUID -eq 0 ]] || die "Run with sudo: sudo bash deploy/deploy.sh $*"; }

# ---------------------------------------------------------------- helpers ----
env_get() { # env_get KEY FILE -> value (quotes stripped)
  [[ -f "$2" ]] || return 0
  tr -d '\r' < "$2" | grep -E "^[[:space:]]*$1=" | tail -n1 | cut -d= -f2- | sed -E "s/^['\"]//; s/['\"]$//" || true
}

health_check() { # retries for ~60s
  local url="http://127.0.0.1:$APP_PORT/" code
  for _ in $(seq 1 30); do
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "$url" || true)
    [[ "$code" =~ ^(2|3) ]] && { ok "App answered HTTP $code on $url"; return 0; }
    sleep 2
  done
  warn "App did not become healthy (last HTTP code: ${code:-none})"
  return 1
}

# ------------------------------------------------------------- 1. system ----
install_system_packages() {
  step "Installing system packages"
  command -v apt-get >/dev/null || die "This script supports Ubuntu/Debian (apt) only."
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq
  apt-get install -y -qq curl ca-certificates gnupg rsync nginx apache2-utils build-essential python3 openssl >/dev/null
  ok "System packages ready"
}

install_node() {
  step "Checking Node.js (need >= 20)"
  local major=0
  command -v node >/dev/null && major=$(node -p 'process.versions.node.split(".")[0]')
  if (( major < 20 )); then
    echo "Installing Node.js $NODE_MAJOR from NodeSource..."
    curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash - >/dev/null \
      || die "Could not reach NodeSource. Install Node.js >= 20 manually, then re-run."
    apt-get install -y -qq nodejs >/dev/null
  fi
  ok "Node $(node -v), npm $(npm -v)"
}

create_user_and_dirs() {
  step "Preparing user and directories"
  id "$APP_USER" >/dev/null 2>&1 || useradd --system --home-dir "$DATA_DIR" --shell /usr/sbin/nologin "$APP_USER"
  mkdir -p "$RELEASES_DIR" "$DATA_DIR" "$ETC_DIR"
  chown "$APP_USER:$APP_USER" "$DATA_DIR" "$RELEASES_DIR"
  chmod 750 "$DATA_DIR" "$ETC_DIR"
  ok "User '$APP_USER', data in $DATA_DIR"
}

# ---------------------------------------------------------------- 2. env ----
write_env_file() {
  step "Writing server environment ($ENV_FILE)"
  local src="$SRC_DIR/.env.local"
  [[ -f "$src" ]] || src="$SRC_DIR/.env"
  [[ -f "$src" ]] || die "No .env.local found in $SRC_DIR. Copy .env.example to .env.local and set LIARA_API_TOKEN."

  [[ -n "$(env_get LIARA_API_TOKEN "$src")" ]] || die "LIARA_API_TOKEN is empty in $(basename "$src")."

  # Keep the approval secret stable across deploys so pending approvals stay valid.
  local secret; secret="$(env_get APPROVAL_SIGNING_SECRET "$src")"
  [[ -n "$secret" ]] || secret="$(env_get APPROVAL_SIGNING_SECRET "$ENV_FILE")"
  [[ -n "$secret" ]] || { secret="$(openssl rand -hex 32)"; warn "APPROVAL_SIGNING_SECRET was empty — generated a new one."; }

  local tmp; tmp="$(mktemp)"
  # Drop CRLF, comments, blanks and the keys this script owns.
  tr -d '\r' < "$src" | grep -Ev '^[[:space:]]*(#|$)' \
    | grep -Ev '^(APPROVAL_SIGNING_SECRET|AUDIT_DB_PATH|LIARA_PLAN_CACHE_PATH|NODE_ENV|PORT|HOSTNAME|DEMO_BROKEN_APP_URL)=' > "$tmp" || true
  {
    echo "NODE_ENV=production"
    echo "APPROVAL_SIGNING_SECRET=$secret"
    echo "AUDIT_DB_PATH=$DATA_DIR/audit.sqlite"
    echo "LIARA_PLAN_CACHE_PATH=$DATA_DIR/liara-plans-cache.json"
    echo "DEMO_BROKEN_APP_URL=http://127.0.0.1:$DEMO_PORT"
  } >> "$tmp"
  install -m 640 -o root -g "$APP_USER" "$tmp" "$ENV_FILE"
  rm -f "$tmp"
  ok "Environment saved (token not printed)"
}

# ------------------------------------------------------------ 3. release ----
build_release() {
  RELEASE="$RELEASES_DIR/$(date +%Y%m%d-%H%M%S)"
  step "Building release $(basename "$RELEASE")"
  mkdir -p "$RELEASE"
  rsync -a --delete \
    --exclude node_modules --exclude .next --exclude .git --exclude data \
    --exclude '.env' --exclude '.env.local' --exclude '.env.*.local' \
    --exclude 'deploy/deploy.conf' --exclude '*.tar.gz' \
    "$SRC_DIR/" "$RELEASE/"
  mkdir -p "$RELEASE/data"
  chown -R "$APP_USER:$APP_USER" "$RELEASE"

  local npm_flags="--no-audit --no-fund"
  [[ -n "$NPM_REGISTRY" ]] && npm_flags+=" --registry=$NPM_REGISTRY"
  # Build as the app user with the production env so NEXT_* values match runtime.
  runuser -u "$APP_USER" -- env HOME="$DATA_DIR" bash -c "
    set -e; cd '$RELEASE'
    while IFS='=' read -r k v; do [[ -n \$k ]] && export \"\$k=\$v\"; done < '$ENV_FILE'
    echo 'npm ci ...'; npm ci $npm_flags --loglevel=error
    echo 'next build ...'; npx next build
  " || die "Build failed — the running version was NOT changed."
  ok "Build finished"
}

install_systemd_units() {
  step "Installing systemd services"
  local node_bin; node_bin="$(command -v node)"
  cat > "/etc/systemd/system/$APP_NAME.service" <<EOF
[Unit]
Description=Liara Agent (Next.js)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$CURRENT_LINK
EnvironmentFile=$ENV_FILE
ExecStart=$node_bin $CURRENT_LINK/node_modules/next/dist/bin/next start -H 127.0.0.1 -p $APP_PORT
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true
ReadWritePaths=$DATA_DIR $RELEASES_DIR

[Install]
WantedBy=multi-user.target
EOF

  cat > "/etc/systemd/system/$APP_NAME-demo.service" <<EOF
[Unit]
Description=Liara Agent demo broken app (loopback only)
After=network.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$CURRENT_LINK/demo-broken-app
Environment=PORT=$DEMO_PORT
ExecStart=$node_bin start-local-demo.js
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable "$APP_NAME.service" >/dev/null 2>&1
  if [[ "$ENABLE_DEMO" == "1" ]]; then
    systemctl enable "$APP_NAME-demo.service" >/dev/null 2>&1
  else
    systemctl disable --now "$APP_NAME-demo.service" >/dev/null 2>&1 || true
  fi
  ok "Services installed"
}

activate_release() {
  step "Switching to the new release"
  PREVIOUS="$(readlink -f "$CURRENT_LINK" 2>/dev/null || true)"
  ln -sfn "$RELEASE" "$CURRENT_LINK"
  systemctl restart "$APP_NAME.service"
  [[ "$ENABLE_DEMO" == "1" ]] && systemctl restart "$APP_NAME-demo.service"
  if ! health_check; then
    journalctl -u "$APP_NAME" -n 40 --no-pager || true
    if [[ -n "$PREVIOUS" && -d "$PREVIOUS" ]]; then
      warn "Rolling back to $(basename "$PREVIOUS")"
      ln -sfn "$PREVIOUS" "$CURRENT_LINK"
      systemctl restart "$APP_NAME.service"
      health_check || true
    fi
    die "New release is unhealthy. See the logs above."
  fi
}

prune_releases() {
  local old
  old=$(ls -1dt "$RELEASES_DIR"/*/ 2>/dev/null | tail -n +"$((KEEP_RELEASES + 1))" || true)
  [[ -n "$old" ]] && echo "$old" | xargs -r rm -rf && ok "Pruned old releases (keeping $KEEP_RELEASES)"
  return 0
}

# -------------------------------------------------------------- 4. nginx ----
configure_nginx() {
  step "Configuring nginx (reverse proxy + password protection)"
  if [[ ! -f "$HTPASSWD_FILE" || -n "$BASIC_AUTH_PASSWORD" ]]; then
    if [[ -z "$BASIC_AUTH_PASSWORD" ]]; then
      echo "This panel can spend money on your Liara account, so it must be password protected."
      read -rsp "Choose a password for user '$BASIC_AUTH_USER': " BASIC_AUTH_PASSWORD; echo
      [[ ${#BASIC_AUTH_PASSWORD} -ge 8 ]] || die "Password must be at least 8 characters."
    fi
    htpasswd -bcB "$HTPASSWD_FILE" "$BASIC_AUTH_USER" "$BASIC_AUTH_PASSWORD" >/dev/null 2>&1
    chown root:www-data "$HTPASSWD_FILE"; chmod 640 "$HTPASSWD_FILE"
    ok "Login user: $BASIC_AUTH_USER"
  fi

  cat > "/etc/nginx/sites-available/$APP_NAME" <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN:-_};

    client_max_body_size 100m;

    auth_basic "Liara Agent";
    auth_basic_user_file $HTPASSWD_FILE;

    location / {
        proxy_pass http://127.0.0.1:$APP_PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        # Streaming chat / GenUI responses
        proxy_buffering off;
        proxy_read_timeout 300s;
    }
}
EOF
  ln -sfn "/etc/nginx/sites-available/$APP_NAME" "/etc/nginx/sites-enabled/$APP_NAME"
  rm -f /etc/nginx/sites-enabled/default
  nginx -t >/dev/null 2>&1 || { nginx -t; die "nginx config test failed."; }
  systemctl enable nginx >/dev/null 2>&1
  systemctl reload nginx || systemctl restart nginx

  if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
    ufw allow 'Nginx Full' >/dev/null && ok "Firewall: opened HTTP/HTTPS"
  fi

  if [[ -n "$DOMAIN" && -n "$LETSENCRYPT_EMAIL" ]]; then
    step "Requesting HTTPS certificate for $DOMAIN"
    apt-get install -y -qq certbot python3-certbot-nginx >/dev/null
    certbot --nginx -d "$DOMAIN" -m "$LETSENCRYPT_EMAIL" --agree-tos --non-interactive --redirect \
      && ok "HTTPS enabled" \
      || warn "certbot failed — check that $DOMAIN points to this server, then re-run."
  fi
  ok "nginx ready"
}

# ------------------------------------------------------------- commands ----
cmd_deploy() {
  require_root deploy
  echo "Deploying from $SRC_DIR"
  install_system_packages
  install_node
  create_user_and_dirs
  write_env_file
  build_release
  install_systemd_units
  activate_release
  configure_nginx
  prune_releases
  local ip; ip="$(curl -s --max-time 4 https://api.ipify.org || hostname -I | awk '{print $1}')"
  echo
  ok "Deploy complete: $(basename "$RELEASE")"
  echo "   Open:  http://${DOMAIN:-$ip}/   (user: $BASIC_AUTH_USER)"
  echo "   Status: sudo bash deploy/deploy.sh status"
}

cmd_status() {
  for svc in "$APP_NAME" "$APP_NAME-demo" nginx; do
    printf '%-22s %s\n' "$svc" "$(systemctl is-active "$svc" 2>/dev/null || true)"
  done
  echo "release: $(basename "$(readlink -f "$CURRENT_LINK" 2>/dev/null || echo none)")"
  health_check || true
  echo; echo "Releases:"; ls -1t "$RELEASES_DIR" 2>/dev/null | sed 's/^/  /'
}

cmd_rollback() {
  require_root rollback
  local cur prev
  cur="$(readlink -f "$CURRENT_LINK")"
  prev="$(ls -1dt "$RELEASES_DIR"/*/ | sed 's:/$::' | grep -vx "$cur" | head -n1 || true)"
  [[ -n "$prev" ]] || die "No previous release to roll back to."
  ln -sfn "$prev" "$CURRENT_LINK"
  systemctl restart "$APP_NAME.service"
  [[ "$ENABLE_DEMO" == "1" ]] && systemctl restart "$APP_NAME-demo.service"
  health_check && ok "Rolled back to $(basename "$prev")"
}

case "${1:-deploy}" in
  deploy)   cmd_deploy ;;
  status)   cmd_status ;;
  logs)     journalctl -u "$APP_NAME" -u "$APP_NAME-demo" -f -n 100 ;;
  restart)  require_root restart; systemctl restart "$APP_NAME" "$APP_NAME-demo"; health_check ;;
  rollback) cmd_rollback ;;
  *) echo "Usage: sudo bash deploy/deploy.sh [deploy|status|logs|restart|rollback]"; exit 1 ;;
esac
