# راهنمای دیپلوی روی سرور لینوکس

این راهنما پنل «دستیار لیارا» را روی یک سرور Ubuntu/Debian بالا می‌آورد. بیشتر کار را یک دستور انجام می‌دهد.

## اسکریپت چه کار می‌کند؟

`deploy/deploy.sh` این کارها را به ترتیب انجام می‌دهد:

1. بسته‌های لازم را نصب می‌کند: nginx، build-essential، rsync و certbot (فقط اگر دامنه داده باشید).
2. اگر Node.js 20 یا بالاتر نصب نباشد، Node 22 را نصب می‌کند.
3. کاربر سیستمیِ `liara-agent` را می‌سازد. برنامه با این کاربر و بدون دسترسی root اجرا می‌شود.
4. مقدارهای `.env.local` را در `/etc/liara-agent/app.env` ذخیره می‌کند. دسترسی این فایل محدود است و توکن هیچ‌وقت چاپ نمی‌شود.
5. هر نسخه را در پوشه‌ای جدا در `/opt/liara-agent/releases/<تاریخ>` بیلد می‌کند. اگر بیلد خطا بدهد، نسخه‌ای که در حال اجراست دست نمی‌خورد.
6. دو سرویس systemd می‌سازد: `liara-agent` روی پورت ۳۰۰۰ و اپ دمو روی پورت ۳۰۰۱. هر دو فقط روی 127.0.0.1 در دسترس‌اند.
7. نسخه‌ی جدید را فعال و سلامتش را بررسی می‌کند. اگر بالا نیاید، **خودکار به نسخه‌ی قبلی برمی‌گردد**.
8. nginx را روی پورت 80 تنظیم می‌کند و برای ورود به پنل **رمز عبور** می‌گذارد. این رمز لازم است، چون پنل می‌تواند در حساب لیارای شما هزینه ایجاد کند.
9. اگر `DOMAIN` و `LETSENCRYPT_EMAIL` را تنظیم کرده باشید، گواهی HTTPS رایگان می‌گیرد.

داده‌های پایدار، یعنی audit log و کش پلن‌ها، در `/var/lib/liara-agent` می‌مانند و با دیپلوی بعدی پاک نمی‌شوند.

---

## مرحله‌ی ۱ — آماده‌سازی روی ویندوز (یک‌بار)

1. فایل `.env.local` در ریشه‌ی پروژه ساخته شده است. مطمئن شوید `LIARA_API_TOKEN` در آن مقدار دارد. مقدار `APPROVAL_SIGNING_SECRET` هم از قبل ساخته شده است. برای فعال شدن دستیار گفت‌وگو، `LIARA_AI_BASE_URL` (به شکل `https://ai.liara.ir/api/v1/<شناسه>`)، `LIARA_AI_API_KEY` و `LIARA_AI_MODEL` را هم پر کنید.
2. (اختیاری) فایل `deploy/deploy.conf.example` را با نام `deploy/deploy.conf` کپی کنید و دامنه، رمز پنل و بقیه‌ی تنظیمات را در آن بنویسید. اگر این فایل را نسازید، همه‌چیز با مقدار پیش‌فرض کار می‌کند و رمز پنل در اولین اجرا پرسیده می‌شود.

## مرحله‌ی ۲ — بسته‌بندی و انتقال به سرور

در PowerShell و در پوشه‌ی پروژه:

```powershell
powershell -ExecutionPolicy Bypass -File deploy\pack.ps1
```

خروجی این دستور فایل `D:\Learning\Liara\liara-agent.tar.gz` است. پوشه‌های `node_modules`، `.next` و `.git` در این فایل نیستند و روی سرور از نو ساخته می‌شوند.

انتقال فایل به سرور (به‌جای `SERVER_IP` آی‌پی سرور خودتان را بگذارید):

```powershell
scp D:\Learning\Liara\liara-agent.tar.gz root@SERVER_IP:/root/
```

## مرحله‌ی ۳ — دیپلوی روی سرور (همان «یک دستور»)

```bash
ssh root@SERVER_IP
mkdir -p ~/liara-agent && tar -xzf ~/liara-agent.tar.gz -C ~/liara-agent
cd ~/liara-agent && sudo bash deploy/deploy.sh
```

در اولین اجرا رمز ورود پنل پرسیده می‌شود (حداقل ۸ کاراکتر). در پایان آدرس پنل نمایش داده می‌شود، مثلاً `http://1.2.3.4/`. با کاربر `admin` و همان رمز وارد شوید.

> اگر در سرور ایران دسترسی به npm کند یا مسدود است، در `deploy.conf` یک mirror بگذارید، مثلاً `NPM_REGISTRY=https://registry.npmmirror.com`.

---

## انتشار نسخه‌ی جدید

بعد از هر تغییر در کد، مرحله‌ی ۲ را دوباره انجام دهید. سپس روی سرور:

```bash
rm -rf ~/liara-agent && mkdir ~/liara-agent && tar -xzf ~/liara-agent.tar.gz -C ~/liara-agent
cd ~/liara-agent && sudo bash deploy/deploy.sh
```

در این حالت رمز پنل و `APPROVAL_SIGNING_SECRET` حفظ می‌شوند. سه نسخه‌ی آخر هم برای بازگشت نگه داشته می‌شوند.

## دستورهای نگهداری

| دستور | کار |
|---|---|
| `sudo bash deploy/deploy.sh status` | وضعیت سرویس‌ها، نسخه‌ی فعال و health check |
| `sudo bash deploy/deploy.sh logs` | دیدن زنده‌ی لاگ‌ها (برای خروج Ctrl+C) |
| `sudo bash deploy/deploy.sh restart` | ری‌استارت سرویس‌ها |
| `sudo bash deploy/deploy.sh rollback` | برگشت به نسخه‌ی قبلی |

## تنظیم دامنه (اختیاری)

1. در پنل DNS دامنه‌تان، مثلاً پنل لیارا یا ابرآروان (یا در پنل ایرنیک، اگر NS را آنجا تنظیم کرده‌اید)، یک رکورد `A` بسازید که به آی‌پی سرور اشاره کند.
2. در `deploy/deploy.conf` این دو مقدار را بنویسید: `DOMAIN=agent.example.ir` و `LETSENCRYPT_EMAIL=you@example.com`.
3. دیپلوی را دوباره اجرا کنید. HTTPS خودکار فعال می‌شود و درخواست‌های HTTP به HTTPS هدایت می‌شوند.

## عیب‌یابی

| مشکل | راه‌حل |
|---|---|
| `LIARA_API_TOKEN is empty` | توکن را در `.env.local` بنویسید و دوباره بسته‌بندی کنید |
| `Build failed` | معمولاً اینترنت سرور به npm نمی‌رسد؛ `NPM_REGISTRY` را تنظیم کنید |
| `Could not reach NodeSource` | Node 20 یا بالاتر را دستی نصب کنید و دوباره اجرا کنید |
| پنل باز نمی‌شود | پورت 80/443 را در فایروال پنل ابری باز کنید؛ خروجی `deploy.sh status` را ببینید |
| `$'\r': command not found` | فایل با خط‌پایان ویندوزی ذخیره شده؛ روی سرور `sed -i 's/\r$//' deploy/deploy.sh` را اجرا کنید |

## بررسی بعد از دیپلوی (روی سرور)

```bash
cd /opt/liara-agent/current
sudo -u liara-agent bash -c 'set -a; . /etc/liara-agent/app.env; set +a; npm run probe:liara'
```
این دستور فقط خواندنی است و نشان می‌دهد سرور به API لیارا دسترسی دارد.
