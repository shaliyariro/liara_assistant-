# Builds a clean archive of the project for copying to the server.
#   powershell -ExecutionPolicy Bypass -File deploy\pack.ps1
# Output: ..\liara-agent.tar.gz (next to the project folder)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$out = Join-Path (Split-Path -Parent $root) "liara-agent.tar.gz"

if (-not (Test-Path (Join-Path $root ".env.local"))) {
    Write-Warning ".env.local not found - the server deploy will stop until you add it."
}

Push-Location $root
try {
    tar -czf $out `
        --exclude=node_modules --exclude=.next --exclude=.git `
        --exclude=data/*.sqlite --exclude=data/*.sqlite-* --exclude=*.tar.gz `
        .
} finally { Pop-Location }

$size = "{0:N1} MB" -f ((Get-Item $out).Length / 1MB)
Write-Host "Created $out ($size)" -ForegroundColor Green
Write-Host "Next: scp `"$out`" root@SERVER_IP:/root/"
